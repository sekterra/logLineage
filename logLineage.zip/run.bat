@echo off
setlocal
cd /d "%~dp0"
if not exist dist\loglineage.jar (
  call build.bat
)
REM OOM mitigation: -Xmx is optional headroom. 2-Pass streaming is the real fix.
REM Usage: run.bat LOG_DIR [CONFIG_DIR] [RESULT_SPLIT_MB]
REM        run.bat LOG_DIR [RESULT_SPLIT_MB]
REM Default result split: 200 MB
java -Xmx4g -jar dist\loglineage.jar %*
endlocal
