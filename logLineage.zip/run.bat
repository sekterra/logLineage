@echo off
setlocal
cd /d "%~dp0"
if not exist dist\loglineage.jar (
  call build.bat
)
REM OOM 근본 대책은 2-Pass 스트리밍이다. -Xmx 는 여유분 확보용 임시 완화책일 뿐.
REM 서버 RAM 16GB 기준 예시: 타 프로세스 여유를 두고 4g 지정.
java -Xmx4g -jar dist\loglineage.jar %*
endlocal
