# LogLineage 클래스 구조 설계

## 개요

JDK 표준 라이브러리만 사용하는 스트리밍 비즈니스 라인리지 추적기.
로그 파일을 물리적으로 합치지 않고, 파일별 `BufferedReader` + 타임스탬프 K-way merge로 처리한다.

## 패키지 구조

```
com.loglineage
├── LogLineageApp              # CLI 진입점, 파이프라인 오케스트레이션
├── config
│   ├── AppConfig              # app.properties (확장자, charset, 메시지 한도 등)
│   ├── RuntimeYamlConfig      # loglineage.yaml (분할MB, 헤더/파일명 패턴)
│   ├── SimpleYaml             # JDK-only 최소 YAML 파서
│   ├── ClassifyConfig         # classify.properties (logger 패턴, 컴파일 실패 시 비활성)
│   ├── ErrorSignatureConfig   # error-signature.properties
│   ├── SystemClassifier       # 파일명 토큰 → WEB/MOBILE/MWEB/LOGIN
│   ├── SystemId               # 시스템 코드 상수
│   └── MybatisTypeConfig       # mybatis-type.properties (타입 인용 규칙)
├── io
│   ├── LogFileScanner         # 로그 폴더 스캔 (확장자 필터)
│   ├── LogFileReader          # 파일 단위 스트리밍 이벤트 조립 (메시지/continuation 한도)
│   └── KWayMergeReader        # 타임스탬프 오름차순 K-way merge
├── parse
│   ├── LogLineParser          # WEB/MOBILE 헤더 분기 (모바일은 [pod:] 포함)
│   └── MybatisParameterParser  # Parameters 값/타입 선형 스캔 파싱
├── model
│   ├── LogEvent               # 파싱된 로그 이벤트
│   ├── TraceGroup             # traceId 단위 이벤트 그룹
│   ├── SqlPair                # SQL_TEMPLATE + SQL_EXECUTABLE
│   ├── LineageRecord          # TSV 출력 레코드
│   └── EventType              # CONTROLLER / SERVICE / MYBATIS / UNCLASSIFIED
├── lineage
│   ├── TraceGroupBuilder      # 시간 순서 유지하며 traceId 그룹화
│   ├── ThreadTracePropagator  # 동일 스레드 직전 traceId 전파
│   ├── ContextRuleEngine      # 규칙 A(backfill) / B(미인증) / C(충돌)
│   ├── MybatisPairer           # Preparing/Parameters/Total 3줄 페어링
│   ├── EventClassifier        # properties 기반 이벤트 분류
│   └── LineageRecordFactory   # LineageRecord 변환·URI_SOURCE
├── sql
│   └── SqlBinder              # ? 바인딩 + 타입별 인용
├── output
│   ├── TsvWriter              # {runId}.tsv / unresolved / inconsistent
│   ├── QuarantineWriter       # {runId}-quarantine.tsv
│   ├── RunSummaryWriter       # {runId}-run-summary.log
│   ├── ExecutionErrorLogger   # {runId}-execution-error.log
│   └── OutputFilePermissionHardener  # Windows ACL로 실행 계정 읽기/쓰기만 허용
└── util
    ├── TsvUtil                # TSV 이스케이프 (+ 수식 인젝션 선두 문자 무력화)
    └── TimeUtil               # 타임스탬프 파싱/비교
```

AppSec 관련 동작 요약:
- TSV 셀 선두 `= + - @` 는 `'` 접두로 수식 해석을 막는다 (`TsvUtil`).
- MyBatis Parameters는 정규식 대신 선형 스캔으로 `(Type)` 세그먼트를 파싱한다.
- `event.message.max.bytes` / `event.continuation.max.lines` 초과 continuation·헤더는 truncate/quarantine.
- classify 패턴 `PatternSyntaxException`·과도한 길이는 해당 규칙만 비활성 + execution-error 기록.
- `TsvWriter.close`는 writer별 close로 한 실패가 나머지를 건너뛰지 않는다.
- 기동 실패는 가능하면 파일 로그 우선, close 실패는 errorCount에 남기고 배치는 계속.

출력 디렉터리는 CLI 인자가 아니라 `<로그폴더>/output` 고정이다.
실행 시작 시 `yyyy-MM-dd-HHmmss` runId를 한 번 생성해 모든 산출물에 동일 접두사로 사용한다.

### 런타임 YAML (`loglineage.yaml`)

설정 폴더 또는 JAR classpath에서 로드. 없거나 속성 누락 시 코드/`app.properties` 기본값.

| 키 | 용도 |
|----|------|
| `result_split_mb` | result TSV 분할 크기(MB). CLI MB 인자가 최우선 |
| `header_patterns` | 로그 헤더 정규식 목록(WEB → MOBILE 등). named group 사용 |
| `filename_patterns` | 시스템 판별용 파일명 토큰 (`web`/`mobile`/`mweb`/`login`) |

출력 파일 생성 직후 `OutputFilePermissionHardener`가 `AclFileAttributeView`로
현재 실행 계정만 읽기/쓰기를 갖도록 ACL을 재구성하고, Users/Everyone 등 기본 그룹 권한 제거를 시도한다.
(`Files.setPosixFilePermissions`/POSIX 0600은 Windows에서 사용하지 않음.)
ACL 강화 실패 시 배치는 중단하지 않고 `run-summary.log`에
`출력 파일 접근 권한 강화 실패: <사유>` 를 기록한다.
## 처리 파이프라인

```
LogFileScanner
    → LogFileReader(파일별)
    → KWayMergeReader (timestamp ASC)
    → ThreadTracePropagator (파일+스레드 직전 traceId 전파)
    → TraceGroupBuilder ((원본파일,traceId) 그룹 — backfill 보조)
    → ContextRuleEngine (A backfill / C 충돌표시; B 미인증은 RCA 제외)
    → ErrorEventDetector (LEVEL=ERROR 또는 error-signature.properties)
    → 대상 사용자 = IS_ERROR_EVENT=Y 가 있는 (cmp,user)
    → MybatisPairer + SqlBinder
    → EventClassifier + RCA 레코드 변환
    → 대상 사용자만 필터 → 사번 ASC, 이벤트시각 ASC
    → {runId}-rca-timeline.tsv / context-inconsistent.tsv / quarantine / run-summary
```

`ThreadTracePropagator`는 컨텍스트 태그가 없는 MyBatis 라인이 동일 요청 그룹에 들어가
thread+traceId 페어링과 규칙 A backfill이 가능하도록 한다.

## 규칙 요약

| 규칙 | 조건 | 결과 |
|------|------|------|
| A | 동일 traceId 내 일부 cmp/user만 존재 | 빈 값 backfill |
| B | 그룹 전체에 cmp/user 모두 없음 | {runId}-unauthenticated-or-unresolved.tsv |
| C | 그룹 내 cmp/user 값 충돌 | {runId}-context-inconsistent.tsv (+ CONFLICTING_VALUES) |

## 미확정(placeholder) 항목

하드코딩하지 않음. 아래 properties 키를 빈 값으로 두고 외부에서 채운다.

- `classify.controller.logger.pattern`
- `classify.service.logger.pattern`
- `mybatis.type.numeric`
- `mybatis.type.string`
- `log.file.extensions` (기본 동작용으로 `.log` 예시만 문서화, 실제 값은 properties)

보안 한도(미확정 비즈니스 규칙 아님, 기본값 문서화):

- `event.message.max.bytes` 기본 `1048576`
- `event.continuation.max.lines` 기본 `10000`
