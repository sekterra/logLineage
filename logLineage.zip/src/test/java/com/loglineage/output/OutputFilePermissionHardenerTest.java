package com.loglineage.output;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.attribute.AclEntry;
import java.nio.file.attribute.AclEntryPermission;
import java.nio.file.attribute.AclEntryType;
import java.nio.file.attribute.AclFileAttributeView;
import java.nio.file.attribute.UserPrincipal;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * JDK-only 스모크/단위 검증 (JUnit 없음).
 * <pre>
 * javac -encoding UTF-8 -cp build/classes -d build/test-classes src/test/java/com/loglineage/output/*.java
 * java -cp build/classes;build/test-classes com.loglineage.output.OutputFilePermissionHardenerTest
 * </pre>
 */
public final class OutputFilePermissionHardenerTest {
    private static int passed;
    private static int failed;

    private OutputFilePermissionHardenerTest() {
    }

    public static void main(String[] args) throws Exception {
        testHardenSucceedsOnTempFile();
        testHardenMissingPathRecordsFailureAndContinues();
        testHardenNullPathRecordsFailure();
        testForcedAclFailureIsRecordedWithPrefix();
        testGroupLikePrincipalDetection();
        testRunSummaryContainsPermissionFailureLines();
        testFailureDoesNotAbortBatchFlow();

        System.out.println();
        System.out.println("passed=" + passed + " failed=" + failed);
        if (failed > 0) {
            System.exit(1);
        }
    }

    private static void testHardenSucceedsOnTempFile() throws Exception {
        Path dir = Files.createTempDirectory("ll-acl-ok");
        Path file = dir.resolve("sample.tsv");
        Files.writeString(file, "x\n", StandardCharsets.UTF_8);
        OutputFilePermissionHardener hardener = new OutputFilePermissionHardener();
        hardener.harden(file);
        assertTrue("success path should not record failure", !hardener.hasFailures());

        AclFileAttributeView view = Files.getFileAttributeView(
                file, AclFileAttributeView.class, LinkOption.NOFOLLOW_LINKS);
        assertTrue("ACL view available on Windows", view != null);
        List<AclEntry> acl = view.getAcl();
        assertTrue("ACL not empty after harden", !acl.isEmpty());
        for (AclEntry entry : acl) {
            assertTrue("group-like ACE should be removed: " + entry.principal(),
                    !OutputFilePermissionHardener.isGroupLikePrincipal(entry.principal())
                            || entry.type() != AclEntryType.ALLOW);
        }
        boolean hasReadWrite = false;
        UserPrincipal owner = view.getOwner();
        for (AclEntry entry : acl) {
            if (entry.type() == AclEntryType.ALLOW && entry.permissions().contains(AclEntryPermission.READ_DATA)
                    && entry.permissions().contains(AclEntryPermission.WRITE_DATA)) {
                hasReadWrite = true;
            }
        }
        assertTrue("owner/current should have read+write", hasReadWrite);
        assertTrue("owner present", owner != null);
        pass("hardenSucceedsOnTempFile");
    }

    private static void testHardenMissingPathRecordsFailureAndContinues() {
        OutputFilePermissionHardener hardener = new OutputFilePermissionHardener();
        Path missing = Path.of("D:/_project/logLineage/_no_such_dir_/missing-acl.tsv");
        hardener.harden(missing);
        assertTrue("missing path must record failure", hardener.hasFailures());
        String msg = hardener.getFailures().get(0);
        assertTrue("prefix required: " + msg, msg.startsWith(OutputFilePermissionHardener.FAILURE_PREFIX));
        // continue: second call still works
        hardener.harden(missing);
        assertTrue("second failure also recorded", hardener.getFailures().size() >= 2);
        pass("hardenMissingPathRecordsFailureAndContinues");
    }

    private static void testHardenNullPathRecordsFailure() {
        OutputFilePermissionHardener hardener = new OutputFilePermissionHardener();
        hardener.harden(null);
        assertTrue(hardener.hasFailures());
        assertTrue(hardener.getFailures().get(0).startsWith(OutputFilePermissionHardener.FAILURE_PREFIX));
        pass("hardenNullPathRecordsFailure");
    }

    private static void testForcedAclFailureIsRecordedWithPrefix() throws Exception {
        Path dir = Files.createTempDirectory("ll-acl-fail");
        Path file = dir.resolve("locked.tsv");
        Files.writeString(file, "y\n", StandardCharsets.UTF_8);

        AtomicBoolean threw = new AtomicBoolean(false);
        OutputFilePermissionHardener hardener = new OutputFilePermissionHardener() {
            @Override
            void applyOwnerOnlyAcl(Path path, AclFileAttributeView view) throws java.io.IOException {
                threw.set(true);
                throw new java.nio.file.AccessDeniedException(path.toString(), null, "simulated domain policy");
            }
        };
        hardener.harden(file);
        assertTrue("applyOwnerOnlyAcl should have run", threw.get());
        assertTrue("failure recorded", hardener.hasFailures());
        String msg = hardener.getFailures().get(0);
        assertTrue("prefix: " + msg, msg.startsWith(OutputFilePermissionHardener.FAILURE_PREFIX));
        assertTrue("reason included: " + msg, msg.contains("AccessDeniedException") || msg.contains("simulated"));
        pass("forcedAclFailureIsRecordedWithPrefix");
    }

    private static void testGroupLikePrincipalDetection() {
        assertTrue(OutputFilePermissionHardener.isGroupLikePrincipal(named("Everyone")));
        assertTrue(OutputFilePermissionHardener.isGroupLikePrincipal(named("BUILTIN\\Users")));
        assertTrue(OutputFilePermissionHardener.isGroupLikePrincipal(named("NT AUTHORITY\\Authenticated Users")));
        assertTrue(!OutputFilePermissionHardener.isGroupLikePrincipal(named("Tommy")));
        assertTrue(!OutputFilePermissionHardener.isGroupLikePrincipal(null));
        pass("groupLikePrincipalDetection");
    }

    private static void testRunSummaryContainsPermissionFailureLines() throws Exception {
        Path dir = Files.createTempDirectory("ll-summary-acl");
        OutputFilePermissionHardener hardener = new OutputFilePermissionHardener();
        hardener.recordFailureMessage("unit-test-reason");
        List<String> prior = new ArrayList<String>(hardener.getFailures());

        new RunSummaryWriter().write(
                dir,
                "2026-01-01-000000",
                StandardCharsets.UTF_8,
                Collections.singletonList("a.log"),
                Collections.singletonList("a.log => 미식별"),
                1L,
                1L, 0L, 0L, 0L, 0L, 0L, 0L, 1, 0,
                Duration.ofMillis(5),
                prior,
                hardener
        );

        Path summary = dir.resolve("2026-01-01-000000-run-summary.log");
        String text = Files.readString(summary, StandardCharsets.UTF_8);
        assertTrue("summary must contain failure line",
                text.contains(OutputFilePermissionHardener.FAILURE_PREFIX + "unit-test-reason"));
        pass("runSummaryContainsPermissionFailureLines");
    }

    private static void testFailureDoesNotAbortBatchFlow() throws Exception {
        Path dir = Files.createTempDirectory("ll-batch-acl");
        OutputFilePermissionHardener hardener = new OutputFilePermissionHardener() {
            @Override
            void applyOwnerOnlyAcl(Path path, AclFileAttributeView view) throws java.io.IOException {
                throw new java.io.IOException("insufficient privileges");
            }
        };

        try (ExecutionErrorLogger err = new ExecutionErrorLogger(dir, "r1", StandardCharsets.UTF_8, hardener);
             QuarantineWriter q = new QuarantineWriter(dir, "r1", StandardCharsets.UTF_8, hardener);
             TsvWriter tsv = new TsvWriter(dir, "r1", StandardCharsets.UTF_8, hardener)) {
            q.write("a.log", 1, "raw");
            assertTrue("writers created despite ACL failures", true);
        }

        assertTrue("ACL failures recorded for output artifacts", hardener.getFailures().size() >= 4);
        for (String f : hardener.getFailures()) {
            assertTrue(f.startsWith(OutputFilePermissionHardener.FAILURE_PREFIX));
        }

        new RunSummaryWriter().write(
                dir, "r1", StandardCharsets.UTF_8,
                Collections.singletonList("a.log"),
                Collections.singletonList("a.log => 미식별"),
                1,
                1, 1, 0, 0, 0, 0, 0, 1, 0,
                Duration.ZERO,
                hardener.getFailures(),
                hardener
        );
        String summary = Files.readString(dir.resolve("r1-run-summary.log"), StandardCharsets.UTF_8);
        assertTrue(summary.contains(OutputFilePermissionHardener.FAILURE_PREFIX));
        pass("failureDoesNotAbortBatchFlow");
    }

    private static UserPrincipal named(String name) {
        return () -> name;
    }

    private static void assertTrue(String message, boolean condition) {
        if (!condition) {
            failed++;
            System.err.println("FAIL: " + message);
            throw new AssertionError(message);
        }
    }

    private static void assertTrue(boolean condition) {
        assertTrue("assertion failed", condition);
    }

    private static void pass(String name) {
        passed++;
        System.out.println("OK: " + name);
    }
}
