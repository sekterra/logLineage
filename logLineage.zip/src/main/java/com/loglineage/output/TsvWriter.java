package com.loglineage.output;

import com.loglineage.model.LineageRecord;
import com.loglineage.util.TimeUtil;
import com.loglineage.util.TsvUtil;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * RCA 결과 / context-inconsistent TSV 작성기.
 * 메인 파일명: {runId}-result.tsv (runId = yyyy-MM-dd-HHmmss)
 * result는 result.split.max.bytes(기본 500MB) 초과 시
 * {runId}-result-002.tsv … 로 분할하며, 분할된 파일의 마지막 줄에 안내 메시지를 남긴다.
 */
public class TsvWriter implements AutoCloseable {
    /** 한글 헤더. EVENT_TYPE / SQL_TEMPLATE 제외. */
    public static final String RESULT_HEADER =
            "시스템\t회사코드\t사번\t이벤트시각\t에러여부\t트레이스ID\t레벨\tURI\t로거\t"
                    + "실행SQL\t메시지\t원본파일명\t원본라인번호\t컨텍스트불일치";

    public static final String INCONSISTENT_HEADER = RESULT_HEADER + "\t충돌값";

    /** 기본 분할 한도: 500 MiB. */
    public static final long DEFAULT_RESULT_SPLIT_MAX_BYTES = 500L * 1024L * 1024L;

    private final OutputFilePermissionHardener permissionHardener;
    private final Path outputDir;
    private final String runId;
    private final Charset charset;
    private final long resultSplitMaxBytes;
    private final String lineSeparator;
    private final long lineSeparatorBytes;
    private final List<String> resultFileNames = new ArrayList<>();

    /** 현재 result part writer (테스트에서 교체 가능). */
    private BufferedWriter timelineWriter;
    private final BufferedWriter inconsistentWriter;

    private int resultPartIndex = 1;
    private long resultPartBytes;
    private long resultHeaderBytes;
    private long timelineCount;
    private long inconsistentCount;

    public TsvWriter(Path outputDir, String runId, Charset charset,
                     OutputFilePermissionHardener permissionHardener) throws IOException {
        this(outputDir, runId, charset, permissionHardener, DEFAULT_RESULT_SPLIT_MAX_BYTES);
    }

    public TsvWriter(Path outputDir, String runId, Charset charset,
                     OutputFilePermissionHardener permissionHardener,
                     long resultSplitMaxBytes) throws IOException {
        Files.createDirectories(outputDir);
        this.outputDir = outputDir;
        this.runId = runId;
        this.charset = charset;
        this.permissionHardener = permissionHardener == null
                ? new OutputFilePermissionHardener()
                : permissionHardener;
        this.resultSplitMaxBytes = resultSplitMaxBytes > 0
                ? resultSplitMaxBytes
                : DEFAULT_RESULT_SPLIT_MAX_BYTES;
        this.lineSeparator = System.lineSeparator();
        this.lineSeparatorBytes = encodedLength(this.lineSeparator);
        this.timelineWriter = openResultPart(1);
        this.inconsistentWriter = open(outputDir.resolve(runId + "-context-inconsistent.tsv"),
                INCONSISTENT_HEADER);
    }

    private BufferedWriter open(Path path, String header) throws IOException {
        BufferedWriter writer = Files.newBufferedWriter(path, charset,
                StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);
        permissionHardener.harden(path);
        writeRawLine(writer, header);
        return writer;
    }

    private BufferedWriter openResultPart(int partIndex) throws IOException {
        String fileName = resultFileName(partIndex);
        Path path = outputDir.resolve(fileName);
        BufferedWriter writer = Files.newBufferedWriter(path, charset,
                StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);
        permissionHardener.harden(path);
        resultFileNames.add(fileName);
        resultPartIndex = partIndex;
        resultPartBytes = 0;
        resultHeaderBytes = writeRawLine(writer, RESULT_HEADER);
        resultPartBytes = resultHeaderBytes;
        return writer;
    }

    private static String resultFileName(String runId, int partIndex) {
        if (partIndex <= 1) {
            return runId + "-result.tsv";
        }
        return runId + "-result-" + String.format("%03d", partIndex) + ".tsv";
    }

    private String resultFileName(int partIndex) {
        return resultFileName(runId, partIndex);
    }

    public void writeTimeline(LineageRecord record) throws IOException {
        String line = formatTimelineLine(record, false);
        long lineBytes = encodedLength(line) + lineSeparatorBytes;
        // 헤더만 있는 상태에서는 한 줄이 한도를 넘어도 먼저 기록한 뒤, 다음 줄부터 새 파일로 분할한다.
        if (resultPartBytes > resultHeaderBytes && resultPartBytes + lineBytes > resultSplitMaxBytes) {
            rotateResultPart();
        }
        resultPartBytes += writeRawLine(timelineWriter, line);
        timelineCount++;
    }

    public void writeInconsistent(LineageRecord record) throws IOException {
        writeRawLine(inconsistentWriter, formatTimelineLine(record, true));
        inconsistentCount++;
    }

    private void rotateResultPart() throws IOException {
        int nextPart = resultPartIndex + 1;
        String nextName = resultFileName(nextPart);
        String limitLabel = formatByteLimit(resultSplitMaxBytes);
        String footer = "##### [파일분할] 결과 파일이 크기 한도(" + limitLabel
                + ")에 도달하여 여기서 분할됩니다. 이어서: " + nextName + " #####";
        writeRawLine(timelineWriter, footer);
        timelineWriter.close();
        System.out.println("result 파일 분할: " + resultFileName(resultPartIndex)
                + " → " + nextName + " (한도 " + limitLabel + ")");
        timelineWriter = openResultPart(nextPart);
    }

    private static String formatByteLimit(long bytes) {
        if (bytes % (1024L * 1024L) == 0) {
            return (bytes / (1024L * 1024L)) + "MB";
        }
        return bytes + " bytes";
    }

    private String formatTimelineLine(LineageRecord record, boolean withConflict) {
        String base = TsvUtil.join(
                TsvUtil.nullToEmpty(record.getSystemId()),
                TsvUtil.nullToEmpty(record.getCompanyCode()),
                TsvUtil.nullToEmpty(record.getEmployeeId()),
                TimeUtil.format(record.getEventTime()),
                record.isErrorEvent() ? "Y" : "N",
                TsvUtil.nullToEmpty(record.getTraceId()),
                TsvUtil.nullToEmpty(record.getLevel()),
                TsvUtil.nullToEmpty(record.getUri()),
                TsvUtil.nullToEmpty(record.getLogger()),
                TsvUtil.nullToEmpty(record.getSqlExecutable()),
                TsvUtil.nullToEmpty(record.getMessage()),
                TsvUtil.nullToEmpty(record.getSourceFile()),
                Long.toString(record.getSourceLine()),
                record.isContextInconsistent() ? "Y" : "N"
        );
        if (withConflict) {
            return base + "\t" + TsvUtil.escape(TsvUtil.nullToEmpty(record.getConflictingValues()));
        }
        return base;
    }

    private long writeRawLine(BufferedWriter writer, String line) throws IOException {
        writer.write(line);
        writer.write(lineSeparator);
        return encodedLength(line) + lineSeparatorBytes;
    }

    private long encodedLength(String text) {
        if (text == null || text.isEmpty()) {
            return 0;
        }
        return text.getBytes(charset).length;
    }

    public long getTimelineCount() {
        return timelineCount;
    }

    public long getInconsistentCount() {
        return inconsistentCount;
    }

    public int getResultPartCount() {
        return resultFileNames.size();
    }

    public List<String> getResultFileNames() {
        return Collections.unmodifiableList(resultFileNames);
    }

    @Override
    public void close() throws IOException {
        IOException first = null;
        first = closeOne(timelineWriter, first);
        first = closeOne(inconsistentWriter, first);
        if (first != null) {
            throw first;
        }
    }

    private static IOException closeOne(BufferedWriter writer, IOException first) {
        if (writer == null) {
            return first;
        }
        try {
            writer.close();
        } catch (IOException e) {
            if (first == null) {
                return e;
            }
            first.addSuppressed(e);
        }
        return first;
    }
}
