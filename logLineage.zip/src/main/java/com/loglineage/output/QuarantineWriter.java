package com.loglineage.output;

import com.loglineage.util.TsvUtil;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

/**
 * {runId}-quarantine.tsv 작성기.
 */
public class QuarantineWriter implements AutoCloseable {
    public static final String HEADER = "원본파일명\t원본라인번호\t원본라인";

    private final BufferedWriter writer;
    private final boolean suppressWrite;
    private long count;

    public QuarantineWriter(Path outputDir, String runId, Charset charset,
                            OutputFilePermissionHardener permissionHardener) throws IOException {
        this(outputDir, runId, charset, permissionHardener, false);
    }

    /**
     * @param suppressWrite true 이면 파일에 쓰지 않고 카운트만 (Pass1 재스캔용)
     */
    public QuarantineWriter(Path outputDir, String runId, Charset charset,
                            OutputFilePermissionHardener permissionHardener,
                            boolean suppressWrite) throws IOException {
        this.suppressWrite = suppressWrite;
        if (suppressWrite) {
            this.writer = null;
            return;
        }
        Files.createDirectories(outputDir);
        Path file = outputDir.resolve(runId + "-quarantine.tsv");
        this.writer = Files.newBufferedWriter(file, charset,
                StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);
        OutputFilePermissionHardener hardener = permissionHardener == null
                ? new OutputFilePermissionHardener()
                : permissionHardener;
        hardener.harden(file);
        writer.write(HEADER);
        writer.newLine();
    }

    public synchronized void write(String sourceFile, long sourceLine, String rawLine) throws IOException {
        count++;
        if (suppressWrite || writer == null) {
            return;
        }
        writer.write(TsvUtil.join(
                TsvUtil.nullToEmpty(sourceFile),
                Long.toString(sourceLine),
                TsvUtil.nullToEmpty(rawLine)
        ));
        writer.newLine();
    }

    public long getCount() {
        return count;
    }

    @Override
    public void close() throws IOException {
        if (writer != null) {
            writer.close();
        }
    }
}
