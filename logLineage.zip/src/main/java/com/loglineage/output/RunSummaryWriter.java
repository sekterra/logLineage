package com.loglineage.output;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.List;

/**
 * {runId}-run-summary.log 작성기 (RCA 타임라인 메트릭).
 */
public class RunSummaryWriter {
    public void write(Path outputDir,
                      String runId,
                      Charset charset,
                      List<String> inputFiles,
                      List<String> fileSystemLabels,
                      long unidentifiedFileCount,
                      long lineCount,
                      long quarantineCount,
                      long traceGroupCount,
                      long targetUserCount,
                      long errorEventCount,
                      long timelineRecords,
                      long inconsistentRecords,
                      int resultPartCount,
                      int executionErrors,
                      Duration elapsed,
                      List<String> permissionHardeningFailures,
                      OutputFilePermissionHardener permissionHardener) throws IOException {
        Files.createDirectories(outputDir);
        Path file = outputDir.resolve(runId + "-run-summary.log");
        List<String> failures = permissionHardeningFailures == null
                ? Collections.<String>emptyList()
                : permissionHardeningFailures;
        List<String> labels = fileSystemLabels == null
                ? Collections.<String>emptyList()
                : fileSystemLabels;
        try (BufferedWriter writer = Files.newBufferedWriter(file, charset,
                StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE)) {
            writer.write("LogLineage Run Summary (RCA Timeline)");
            writer.newLine();
            writer.write("runId: " + runId);
            writer.newLine();
            writer.write("생성시각: " + LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
            writer.newLine();
            writer.write("입력파일수: " + inputFiles.size());
            writer.newLine();
            writer.write("입력파일목록:");
            writer.newLine();
            for (String name : inputFiles) {
                writer.write("  - " + name);
                writer.newLine();
            }
            writer.write("시스템분류:");
            writer.newLine();
            for (String label : labels) {
                writer.write("  - " + label);
                writer.newLine();
            }
            writer.write("미식별파일수: " + unidentifiedFileCount);
            writer.newLine();
            writer.write("총라인수: " + lineCount);
            writer.newLine();
            writer.write("quarantine건수: " + quarantineCount);
            writer.newLine();
            writer.write("trace그룹수(backfill보조): " + traceGroupCount);
            writer.newLine();
            writer.write("대상사용자수(에러보유 cmp+user): " + targetUserCount);
            writer.newLine();
            writer.write("에러이벤트수(IS_ERROR_EVENT=Y): " + errorEventCount);
            writer.newLine();
            writer.write(runId + "-result.tsv레코드수: " + timelineRecords);
            writer.newLine();
            if (resultPartCount > 1) {
                writer.write("result분할파일수: " + resultPartCount);
                writer.newLine();
            }
            writer.write(runId + "-context-inconsistent.tsv레코드수: " + inconsistentRecords);
            writer.newLine();
            writer.write("실행오류수: " + executionErrors);
            writer.newLine();
            writer.write("소요시간(ms): " + elapsed.toMillis());
            writer.newLine();
            for (String failure : failures) {
                writer.write(failure);
                writer.newLine();
            }
        }

        OutputFilePermissionHardener hardener = permissionHardener == null
                ? new OutputFilePermissionHardener()
                : permissionHardener;
        int before = hardener.getFailures().size();
        hardener.harden(file);
        List<String> all = hardener.getFailures();
        if (all.size() > before) {
            try (BufferedWriter appender = Files.newBufferedWriter(file, charset,
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND, StandardOpenOption.WRITE)) {
                for (int i = before; i < all.size(); i++) {
                    appender.write(all.get(i));
                    appender.newLine();
                }
            }
        }
    }
}
