package com.loglineage.parse;

import com.loglineage.model.LogEvent;
import com.loglineage.util.TimeUtil;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 로그 헤더 라인 파서.
 * 웹/모바일 두 패턴을 순서대로 시도한다.
 * <ul>
 *   <li>WEB: TIMESTAMP LEVEL [trace:] [cmp:] [user:] [uri:] [THREAD] LOGGER - MESSAGE</li>
 *   <li>MOBILE: TIMESTAMP LEVEL [trace:] [pod:] [cmp:] [user:] [uri:] [THREAD] LOGGER - MESSAGE</li>
 * </ul>
 */
public class LogLineParser {
    /** 웹(기존) 헤더. */
    public static final Pattern HEADER_PATTERN_WEB = Pattern.compile(
            "^(\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}\\.\\d{3})\\s+(\\S+)\\s+"
                    + "\\[trace:\\s*([^\\]]*)\\]\\s*"
                    + "\\[cmp:\\s*([^\\]]*)\\]\\s*"
                    + "\\[user:\\s*([^\\]]*)\\]\\s*"
                    + "\\[uri:\\s*([^\\]]*)\\]\\s*"
                    + "\\[([^\\]]*)\\]\\s+(\\S+)\\s+-\\s(.*)$"
    );

    /** 모바일: trace 다음에 [pod:] 가 추가된 헤더. */
    public static final Pattern HEADER_PATTERN_MOBILE = Pattern.compile(
            "^(\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}\\.\\d{3})\\s+(\\S+)\\s+"
                    + "\\[trace:\\s*([^\\]]*)\\]\\s*"
                    + "\\[pod:\\s*([^\\]]*)\\]\\s*"
                    + "\\[cmp:\\s*([^\\]]*)\\]\\s*"
                    + "\\[user:\\s*([^\\]]*)\\]\\s*"
                    + "\\[uri:\\s*([^\\]]*)\\]\\s*"
                    + "\\[([^\\]]*)\\]\\s+(\\S+)\\s+-\\s(.*)$"
    );

    /** @deprecated {@link #HEADER_PATTERN_WEB} 사용. 하위 호환용 별칭. */
    @Deprecated
    public static final Pattern HEADER_PATTERN = HEADER_PATTERN_WEB;

    public LogEvent parseHeader(String line) {
        if (line == null) {
            return null;
        }
        LogEvent web = tryWeb(line);
        if (web != null) {
            return web;
        }
        return tryMobile(line);
    }

    private LogEvent tryWeb(String line) {
        Matcher m = HEADER_PATTERN_WEB.matcher(line);
        if (!m.matches()) {
            return null;
        }
        LogEvent event = new LogEvent();
        event.setTimestamp(TimeUtil.parse(m.group(1)));
        event.setLevel(trimOrNull(m.group(2)));
        event.setTraceId(emptyToNull(m.group(3)));
        event.setCmp(emptyToNull(m.group(4)));
        event.setUser(emptyToNull(m.group(5)));
        event.setUri(emptyToNull(m.group(6)));
        event.setThread(m.group(7));
        event.setLogger(m.group(8));
        event.setMessage(m.group(9) == null ? "" : m.group(9));
        detectMybatisFlags(event);
        return event;
    }

    private LogEvent tryMobile(String line) {
        Matcher m = HEADER_PATTERN_MOBILE.matcher(line);
        if (!m.matches()) {
            return null;
        }
        LogEvent event = new LogEvent();
        event.setTimestamp(TimeUtil.parse(m.group(1)));
        event.setLevel(trimOrNull(m.group(2)));
        event.setTraceId(emptyToNull(m.group(3)));
        event.setPod(emptyToNull(m.group(4)));
        event.setCmp(emptyToNull(m.group(5)));
        event.setUser(emptyToNull(m.group(6)));
        event.setUri(emptyToNull(m.group(7)));
        event.setThread(m.group(8));
        event.setLogger(m.group(9));
        event.setMessage(m.group(10) == null ? "" : m.group(10));
        detectMybatisFlags(event);
        return event;
    }

    public void detectMybatisFlags(LogEvent event) {
        String msg = event.getMessage();
        if (msg == null) {
            return;
        }
        if (containsToken(msg, "Preparing:")) {
            event.setMybatisPreparing(true);
        }
        if (containsToken(msg, "Parameters:")) {
            event.setMybatisParameters(true);
        }
        if (containsToken(msg, "Total:")) {
            event.setMybatisTotal(true);
        }
    }

    private static boolean containsToken(String message, String token) {
        return message.contains(token);
    }

    private static String trimOrNull(String value) {
        if (value == null) {
            return null;
        }
        return value.trim();
    }

    /**
     * 태그는 존재하나 값이 비어 있는 경우(예: {@code [cmp: ]})는 null 로 정규화한다.
     */
    private static String emptyToNull(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }
}
