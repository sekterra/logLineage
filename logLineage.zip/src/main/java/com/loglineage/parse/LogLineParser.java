package com.loglineage.parse;

import com.loglineage.config.RuntimeYamlConfig;
import com.loglineage.model.LogEvent;
import com.loglineage.util.TimeUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 로그 헤더 라인 파서.
 * 기본은 WEB → MOBILE 패턴. {@link RuntimeYamlConfig} 로 패턴을 교체할 수 있다.
 * <p>
 * 커스텀 정규식은 named group 을 사용한다:
 * {@code timestamp, level, trace, cmp, user, uri, thread, logger, message} (선택: {@code pod})
 */
public class LogLineParser {
    /** @deprecated 기본 WEB 패턴 문자열은 {@link RuntimeYamlConfig#DEFAULT_HEADER_WEB} */
    @Deprecated
    public static final Pattern HEADER_PATTERN_WEB =
            Pattern.compile(RuntimeYamlConfig.DEFAULT_HEADER_WEB);

    /** @deprecated 기본 MOBILE 패턴 문자열은 {@link RuntimeYamlConfig#DEFAULT_HEADER_MOBILE} */
    @Deprecated
    public static final Pattern HEADER_PATTERN_MOBILE =
            Pattern.compile(RuntimeYamlConfig.DEFAULT_HEADER_MOBILE);

    /** @deprecated {@link #HEADER_PATTERN_WEB} */
    @Deprecated
    public static final Pattern HEADER_PATTERN = HEADER_PATTERN_WEB;

    private final List<Pattern> headerPatterns;

    public LogLineParser() {
        this(defaultPatterns());
    }

    public LogLineParser(List<Pattern> headerPatterns) {
        List<Pattern> copy = new ArrayList<>();
        if (headerPatterns != null) {
            for (Pattern p : headerPatterns) {
                if (p != null) {
                    copy.add(p);
                }
            }
        }
        if (copy.isEmpty()) {
            copy.addAll(defaultPatterns());
        }
        this.headerPatterns = copy;
    }

    public static LogLineParser fromRuntimeConfig(RuntimeYamlConfig runtime, List<String> warningsOut) {
        if (runtime == null) {
            return new LogLineParser();
        }
        List<String> local = warningsOut == null ? new ArrayList<String>() : warningsOut;
        return new LogLineParser(runtime.compileHeaderPatterns(local));
    }

    private static List<Pattern> defaultPatterns() {
        List<Pattern> list = new ArrayList<>();
        list.add(Pattern.compile(RuntimeYamlConfig.DEFAULT_HEADER_WEB));
        list.add(Pattern.compile(RuntimeYamlConfig.DEFAULT_HEADER_MOBILE));
        return list;
    }

    public LogEvent parseHeader(String line) {
        if (line == null) {
            return null;
        }
        for (Pattern pattern : headerPatterns) {
            Matcher m = pattern.matcher(line);
            if (m.matches()) {
                return toEvent(m);
            }
        }
        return null;
    }

    private static LogEvent toEvent(Matcher m) {
        LogEvent event = new LogEvent();
        event.setTimestamp(TimeUtil.parse(named(m, "timestamp")));
        event.setLevel(trimOrNull(named(m, "level")));
        event.setTraceId(emptyToNull(named(m, "trace")));
        event.setPod(emptyToNull(named(m, "pod")));
        event.setCmp(emptyToNull(named(m, "cmp")));
        event.setUser(emptyToNull(named(m, "user")));
        event.setUri(emptyToNull(named(m, "uri")));
        event.setThread(named(m, "thread"));
        event.setLogger(named(m, "logger"));
        String message = named(m, "message");
        event.setMessage(message == null ? "" : message);
        applyMybatisFlags(event);
        return event;
    }

    private static String named(Matcher m, String name) {
        try {
            return m.group(name);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    public void detectMybatisFlags(LogEvent event) {
        applyMybatisFlags(event);
    }

    private static void applyMybatisFlags(LogEvent event) {
        String msg = event.getMessage();
        if (msg == null) {
            return;
        }
        if (containsToken(msg, "Preparing:")) {
            event.setMybatisPreparing(true);
        }
        if (containsToken(msg, "Parameters:")) {
            event.setMybatisParameters(true);
        }
        if (containsToken(msg, "Total:")) {
            event.setMybatisTotal(true);
        }
    }

    private static boolean containsToken(String message, String token) {
        return message.contains(token);
    }

    private static String trimOrNull(String value) {
        if (value == null) {
            return null;
        }
        return value.trim();
    }

    private static String emptyToNull(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }
}
