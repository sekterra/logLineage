package com.loglineage.model;

import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;

/**
 * 파싱된 단일 로그 이벤트 (멀티라인 메시지 포함).
 */
public class LogEvent {
    private LocalDateTime timestamp;
    private String thread;
    private String level;
    private String logger;
    private StringBuilder messageBuf;
    private int messageUtf8Bytes;
    private int continuationLineCount;
    private boolean messageTruncated;
    private String traceId;
    private String pod;
    private String cmp;
    private String user;
    private String uri;
    private String sourceFile;
    private long sourceLine;
    private String systemId;
    private boolean mybatisPreparing;
    private boolean mybatisParameters;
    private boolean mybatisTotal;
    private boolean errorEvent;
    private boolean contextInconsistent;

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }

    public String getThread() {
        return thread;
    }

    public void setThread(String thread) {
        this.thread = thread;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getLogger() {
        return logger;
    }

    public void setLogger(String logger) {
        this.logger = logger;
    }

    public String getMessage() {
        return messageBuf == null ? null : messageBuf.toString();
    }

    public void setMessage(String message) {
        this.messageBuf = new StringBuilder(message == null ? "" : message);
        this.messageUtf8Bytes = utf8ByteLength(message);
        this.continuationLineCount = 0;
        this.messageTruncated = false;
    }

    /**
     * 메시지 바이트 상한을 적용해 설정. 초과 시 truncate 하고 true를 반환한다.
     */
    public boolean setMessageBounded(String raw, int maxMessageBytes) {
        if (raw == null) {
            setMessage("");
            return false;
        }
        if (maxMessageBytes <= 0) {
            setMessage(raw);
            return false;
        }
        byte[] bytes = raw.getBytes(StandardCharsets.UTF_8);
        if (bytes.length <= maxMessageBytes) {
            setMessage(raw);
            return false;
        }
        setMessage(truncateUtf8(bytes, maxMessageBytes));
        this.messageTruncated = true;
        return true;
    }

    public void appendMessage(String line) {
        if (this.messageBuf == null) {
            this.messageBuf = new StringBuilder();
            if (line != null) {
                this.messageBuf.append(line);
                this.messageUtf8Bytes = utf8ByteLength(line);
            }
        } else {
            this.messageBuf.append('\n');
            if (line != null) {
                this.messageBuf.append(line);
            }
            this.messageUtf8Bytes += 1 + utf8ByteLength(line);
        }
        this.continuationLineCount++;
    }

    /**
     * continuation 한도를 검사한 뒤 가능하면 추가한다.
     * @return true if appended, false if rejected (caller should quarantine)
     */
    public boolean tryAppendContinuation(String line, int maxMessageBytes, int maxContinuationLines) {
        if (messageTruncated) {
            return false;
        }
        if (maxContinuationLines > 0 && continuationLineCount >= maxContinuationLines) {
            messageTruncated = true;
            return false;
        }
        int addBytes = 1 + utf8ByteLength(line);
        if (maxMessageBytes > 0 && messageUtf8Bytes + addBytes > maxMessageBytes) {
            messageTruncated = true;
            return false;
        }
        appendMessage(line);
        return true;
    }

    public int getMessageUtf8Bytes() {
        return messageUtf8Bytes;
    }

    public int getContinuationLineCount() {
        return continuationLineCount;
    }

    public boolean isMessageTruncated() {
        return messageTruncated;
    }

    public void markMessageTruncated() {
        this.messageTruncated = true;
    }

    public String getTraceId() {
        return traceId;
    }

    public void setTraceId(String traceId) {
        this.traceId = traceId;
    }

    public String getPod() {
        return pod;
    }

    public void setPod(String pod) {
        this.pod = pod;
    }

    public String getCmp() {
        return cmp;
    }

    public void setCmp(String cmp) {
        this.cmp = cmp;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public String getSourceFile() {
        return sourceFile;
    }

    public void setSourceFile(String sourceFile) {
        this.sourceFile = sourceFile;
    }

    public long getSourceLine() {
        return sourceLine;
    }

    public void setSourceLine(long sourceLine) {
        this.sourceLine = sourceLine;
    }

    public String getSystemId() {
        return systemId;
    }

    public void setSystemId(String systemId) {
        this.systemId = systemId;
    }

    public boolean isMybatisPreparing() {
        return mybatisPreparing;
    }

    public void setMybatisPreparing(boolean mybatisPreparing) {
        this.mybatisPreparing = mybatisPreparing;
    }

    public boolean isMybatisParameters() {
        return mybatisParameters;
    }

    public void setMybatisParameters(boolean mybatisParameters) {
        this.mybatisParameters = mybatisParameters;
    }

    public boolean isMybatisTotal() {
        return mybatisTotal;
    }

    public void setMybatisTotal(boolean mybatisTotal) {
        this.mybatisTotal = mybatisTotal;
    }

    public boolean isMybatisRelated() {
        return mybatisPreparing || mybatisParameters || mybatisTotal;
    }

    public boolean isErrorEvent() {
        return errorEvent;
    }

    public void setErrorEvent(boolean errorEvent) {
        this.errorEvent = errorEvent;
    }

    public boolean isContextInconsistent() {
        return contextInconsistent;
    }

    public void setContextInconsistent(boolean contextInconsistent) {
        this.contextInconsistent = contextInconsistent;
    }

    private static int utf8ByteLength(String s) {
        if (s == null || s.isEmpty()) {
            return 0;
        }
        return s.getBytes(StandardCharsets.UTF_8).length;
    }

    private static String truncateUtf8(byte[] bytes, int maxBytes) {
        int end = maxBytes;
        while (end > 0 && (bytes[end] & 0xC0) == 0x80) {
            end--;
        }
        return new String(bytes, 0, end, StandardCharsets.UTF_8);
    }
}
