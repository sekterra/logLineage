package com.loglineage.model;

import java.time.LocalDateTime;

/**
 * RCA 타임라인 / inconsistent TSV 출력 레코드.
 */
public class LineageRecord {
    private String companyCode;
    private String employeeId;
    private LocalDateTime eventTime;
    private boolean errorEvent;
    private String traceId;
    private String level;
    private EventType eventType;
    private String uri;
    private String logger;
    private String sqlTemplate;
    private String sqlExecutable;
    private String message;
    private String systemId;
    private String sourceFile;
    private long sourceLine;
    private boolean contextInconsistent;
    private String conflictingValues;

    public String getCompanyCode() {
        return companyCode;
    }

    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public LocalDateTime getEventTime() {
        return eventTime;
    }

    public void setEventTime(LocalDateTime eventTime) {
        this.eventTime = eventTime;
    }

    public boolean isErrorEvent() {
        return errorEvent;
    }

    public void setErrorEvent(boolean errorEvent) {
        this.errorEvent = errorEvent;
    }

    public String getTraceId() {
        return traceId;
    }

    public void setTraceId(String traceId) {
        this.traceId = traceId;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public EventType getEventType() {
        return eventType;
    }

    public void setEventType(EventType eventType) {
        this.eventType = eventType;
    }

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public String getLogger() {
        return logger;
    }

    public void setLogger(String logger) {
        this.logger = logger;
    }

    public String getSqlTemplate() {
        return sqlTemplate;
    }

    public void setSqlTemplate(String sqlTemplate) {
        this.sqlTemplate = sqlTemplate;
    }

    public String getSqlExecutable() {
        return sqlExecutable;
    }

    public void setSqlExecutable(String sqlExecutable) {
        this.sqlExecutable = sqlExecutable;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getSystemId() {
        return systemId;
    }

    public void setSystemId(String systemId) {
        this.systemId = systemId;
    }

    public String getSourceFile() {
        return sourceFile;
    }

    public void setSourceFile(String sourceFile) {
        this.sourceFile = sourceFile;
    }

    public long getSourceLine() {
        return sourceLine;
    }

    public void setSourceLine(long sourceLine) {
        this.sourceLine = sourceLine;
    }

    public boolean isContextInconsistent() {
        return contextInconsistent;
    }

    public void setContextInconsistent(boolean contextInconsistent) {
        this.contextInconsistent = contextInconsistent;
    }

    public String getConflictingValues() {
        return conflictingValues;
    }

    public void setConflictingValues(String conflictingValues) {
        this.conflictingValues = conflictingValues;
    }
}
