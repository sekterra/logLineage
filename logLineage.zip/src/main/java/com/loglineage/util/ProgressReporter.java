package com.loglineage.util;

import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * 콘솔 진행 상황 출력. 라인 주기 또는 파일 완료 시에만 출력한다.
 */
public class ProgressReporter {
    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private final Instant started;
    private final long reportEveryLines;

    public ProgressReporter(Instant started, long reportEveryLines) {
        this.started = started == null ? Instant.now() : started;
        this.reportEveryLines = reportEveryLines <= 0 ? 100_000L : reportEveryLines;
    }

    public long getReportEveryLines() {
        return reportEveryLines;
    }

    public void passProgress(int pass, int totalPasses, int fileIndex, int fileTotal,
                             String fileName, long cumulativeLines, long extraMetric, String extraLabel) {
        StringBuilder sb = new StringBuilder();
        sb.append('[').append(LocalDateTime.now().format(TS)).append("] ");
        sb.append("Pass ").append(pass).append('/').append(totalPasses).append(" 진행 중 | ");
        sb.append("파일 ").append(fileIndex).append('/').append(fileTotal);
        sb.append(" 처리 중 (").append(fileName == null ? "?" : fileName).append(") | ");
        sb.append("누적 처리 라인: ").append(formatLong(cumulativeLines));
        if (extraLabel != null) {
            sb.append(" | ").append(extraLabel).append(": ").append(formatLong(extraMetric));
        }
        sb.append(" | 경과시간: ").append(formatDuration(Duration.between(started, Instant.now())));
        sb.append(" | 힙사용: ").append(formatBytes(usedHeapBytes()));
        System.out.println(sb);
    }

    public void passComplete(int pass, int totalPasses, long totalLines, long metric, String metricLabel) {
        StringBuilder sb = new StringBuilder();
        sb.append('[').append(LocalDateTime.now().format(TS)).append("] ");
        sb.append("Pass ").append(pass).append('/').append(totalPasses).append(" 완료 | ");
        sb.append("총 처리 라인: ").append(formatLong(totalLines));
        if (metricLabel != null) {
            sb.append(" | ").append(metricLabel).append(": ").append(formatLong(metric));
        }
        sb.append(" | 경과시간: ").append(formatDuration(Duration.between(started, Instant.now())));
        sb.append(" | 힙사용: ").append(formatBytes(usedHeapBytes()));
        System.out.println(sb);
    }

    public void complete(String resultFileName) {
        StringBuilder sb = new StringBuilder();
        sb.append('[').append(LocalDateTime.now().format(TS)).append("] ");
        sb.append("완료 | 결과파일: ").append(resultFileName == null ? "" : resultFileName);
        sb.append(" | 총 소요시간: ").append(formatDuration(Duration.between(started, Instant.now())));
        sb.append(" | 힙사용: ").append(formatBytes(usedHeapBytes()));
        System.out.println(sb);
    }

    public static long usedHeapBytes() {
        Runtime rt = Runtime.getRuntime();
        return rt.totalMemory() - rt.freeMemory();
    }

    public static String formatDuration(Duration d) {
        long sec = Math.max(0, d.getSeconds());
        long h = sec / 3600;
        long m = (sec % 3600) / 60;
        long s = sec % 60;
        return String.format("%02d:%02d:%02d", h, m, s);
    }

    public static String formatLong(long n) {
        return String.format("%,d", n);
    }

    public static String formatBytes(long bytes) {
        if (bytes < 1024) {
            return bytes + " B";
        }
        double kb = bytes / 1024.0;
        if (kb < 1024) {
            return String.format("%.1f KB", kb);
        }
        double mb = kb / 1024.0;
        if (mb < 1024) {
            return String.format("%.1f MB", mb);
        }
        return String.format("%.2f GB", mb / 1024.0);
    }
}
