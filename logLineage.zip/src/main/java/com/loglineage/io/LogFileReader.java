package com.loglineage.io;

import com.loglineage.model.LogEvent;
import com.loglineage.output.ExecutionErrorLogger;
import com.loglineage.output.QuarantineWriter;
import com.loglineage.parse.LogLineParser;
import com.loglineage.util.ProgressReporter;

import java.io.BufferedReader;
import java.io.Closeable;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;

/**
 * 단일 로그 파일 스트리밍 리더.
 * continuation은 라인 단위로 즉시 한도 검사하며, 초과 분은 버리고 건수를 quarantine 사유에 남긴다.
 */
public class LogFileReader implements Closeable {
    private final Path file;
    private final String fileName;
    private final String systemId;
    private final BufferedReader reader;
    private final LogLineParser lineParser;
    private final QuarantineWriter quarantineWriter;
    private final ExecutionErrorLogger errorLogger;
    private final int maxMessageBytes;
    private final int maxContinuationLines;
    private final int orphanNonHeaderWarnLines;

    private LogEvent pending;
    private long lineNumber;
    private long linesRead;
    private boolean finished;
    private boolean closed;

    /** pending truncate 이후 다음 헤더 전까지 버린 continuation 수 */
    private long discardedAfterTruncate;
    private long truncateStartLine;
    private int truncateAccumulatedBytes;

    /** pending 없는 헤더 미매칭 연속 줄 */
    private long orphanNonHeaderStreak;
    private long orphanDiscardedAfterWarn;

    public LogFileReader(Path file,
                         Charset charset,
                         LogLineParser lineParser,
                         QuarantineWriter quarantineWriter,
                         ExecutionErrorLogger errorLogger) throws IOException {
        this(file, charset, lineParser, quarantineWriter, errorLogger,
                Integer.MAX_VALUE, Integer.MAX_VALUE, 10_000, null);
    }

    public LogFileReader(Path file,
                         Charset charset,
                         LogLineParser lineParser,
                         QuarantineWriter quarantineWriter,
                         ExecutionErrorLogger errorLogger,
                         int maxMessageBytes,
                         int maxContinuationLines) throws IOException {
        this(file, charset, lineParser, quarantineWriter, errorLogger,
                maxMessageBytes, maxContinuationLines, 10_000, null);
    }

    public LogFileReader(Path file,
                         Charset charset,
                         LogLineParser lineParser,
                         QuarantineWriter quarantineWriter,
                         ExecutionErrorLogger errorLogger,
                         int maxMessageBytes,
                         int maxContinuationLines,
                         String systemId) throws IOException {
        this(file, charset, lineParser, quarantineWriter, errorLogger,
                maxMessageBytes, maxContinuationLines, 10_000, systemId);
    }

    public LogFileReader(Path file,
                         Charset charset,
                         LogLineParser lineParser,
                         QuarantineWriter quarantineWriter,
                         ExecutionErrorLogger errorLogger,
                         int maxMessageBytes,
                         int maxContinuationLines,
                         int orphanNonHeaderWarnLines,
                         String systemId) throws IOException {
        this.file = file;
        this.fileName = file.getFileName().toString();
        this.systemId = systemId == null || systemId.trim().isEmpty()
                ? com.loglineage.config.SystemId.UNIDENTIFIED
                : systemId;
        this.reader = Files.newBufferedReader(file, charset);
        this.lineParser = lineParser;
        this.quarantineWriter = quarantineWriter;
        this.errorLogger = errorLogger;
        this.maxMessageBytes = maxMessageBytes <= 0 ? Integer.MAX_VALUE : maxMessageBytes;
        this.maxContinuationLines = maxContinuationLines <= 0 ? Integer.MAX_VALUE : maxContinuationLines;
        this.orphanNonHeaderWarnLines = orphanNonHeaderWarnLines <= 0 ? 10_000 : orphanNonHeaderWarnLines;
    }

    public Path getFile() {
        return file;
    }

    public String getFileName() {
        return fileName;
    }

    public String getSystemId() {
        return systemId;
    }

    public long getLinesRead() {
        return linesRead;
    }

    public Optional<LogEvent> readNext() {
        if (finished) {
            return Optional.empty();
        }
        try {
            String line;
            while ((line = reader.readLine()) != null) {
                lineNumber++;
                linesRead++;
                LogEvent header = lineParser.parseHeader(line);
                if (header != null) {
                    flushDiscardSummaries();
                    resetOrphanStreak();
                    header.setSourceFile(fileName);
                    header.setSourceLine(lineNumber);
                    header.setSystemId(systemId);
                    applyMessageBound(header);
                    if (pending != null) {
                        LogEvent emit = pending;
                        pending = header;
                        return Optional.of(emit);
                    }
                    pending = header;
                } else {
                    handleNonHeader(line);
                }
            }
            finished = true;
            flushDiscardSummaries();
            if (pending != null) {
                LogEvent emit = pending;
                pending = null;
                return Optional.of(emit);
            }
            return Optional.empty();
        } catch (IOException e) {
            finished = true;
            errorLogger.logError("로그 파일 읽기 오류: " + file, e);
            flushDiscardSummaries();
            if (pending != null) {
                LogEvent emit = pending;
                pending = null;
                return Optional.of(emit);
            }
            return Optional.empty();
        }
    }

    private void handleNonHeader(String line) {
        if (pending != null) {
            resetOrphanStreak();
            if (pending.isMessageTruncated()) {
                discardedAfterTruncate++;
                return;
            }
            boolean alreadyTruncated = pending.isMessageTruncated();
            int beforeBytes = pending.getMessageUtf8Bytes();
            if (pending.tryAppendContinuation(line, maxMessageBytes, maxContinuationLines)) {
                lineParser.detectMybatisFlags(pending);
            } else {
                if (!alreadyTruncated) {
                    handleNonHeaderLimitExceeded(beforeBytes);
                } else {
                    discardedAfterTruncate++;
                }
            }
            return;
        }

        // pending 없음 = 고아 비헤더 라인
        orphanNonHeaderStreak++;
        if (orphanNonHeaderStreak == orphanNonHeaderWarnLines) {
            errorLogger.logError(
                    "[WARN] 헤더 미매칭 라인 연속 과다 - 파일: " + fileName
                            + ", 연속줄수: " + ProgressReporter.formatLong(orphanNonHeaderStreak)
                            + ", 현재라인: " + lineNumber
                            + " -> 다음 정상 헤더까지 스킵 후 재개",
                    null);
        }
        if (orphanNonHeaderStreak <= orphanNonHeaderWarnLines) {
            try {
                quarantineWriter.write(fileName, lineNumber, line);
            } catch (IOException qe) {
                errorLogger.logError("quarantine 기록 실패: " + fileName + ":" + lineNumber, qe);
            }
        } else {
            orphanDiscardedAfterWarn++;
        }
    }

    private void applyMessageBound(LogEvent header) {
        String raw = header.getMessage();
        int originalBytes = raw == null ? 0 : raw.getBytes(java.nio.charset.StandardCharsets.UTF_8).length;
        if (header.setMessageBounded(raw, maxMessageBytes)) {
            errorLogger.logError(formatLimitWarn(fileName, lineNumber, originalBytes, maxMessageBytes), null);
            quarantineNote("[TRUNCATED_HEADER_MESSAGE] originalBytes=" + originalBytes
                    + " maxBytes=" + maxMessageBytes);
            lineParser.detectMybatisFlags(header);
        }
    }

    private void handleNonHeaderLimitExceeded(int beforeBytes) {
        truncateStartLine = pending.getSourceLine();
        truncateAccumulatedBytes = beforeBytes;
        errorLogger.logError(formatLimitWarn(fileName, truncateStartLine, beforeBytes, maxMessageBytes), null);
        quarantineNote("[TRUNCATED_EVENT_MESSAGE] maxBytes=" + maxMessageBytes
                + " maxLines=" + maxContinuationLines
                + " startLine=" + truncateStartLine);
        discardedAfterTruncate = 1;
    }

    private static String formatLimitWarn(String file, long startLine, int accumulatedBytes, int maxBytes) {
        return "[WARN] 이벤트 메시지 한도 초과 - 파일: " + file
                + ", 시작라인: " + startLine
                + ", 누적크기: " + ProgressReporter.formatLong(accumulatedBytes) + " bytes"
                + ", 한도: " + ProgressReporter.formatLong(maxBytes) + " bytes -> quarantine 처리";
    }

    private void quarantineNote(String note) {
        try {
            quarantineWriter.write(fileName, lineNumber, note);
        } catch (IOException qe) {
            errorLogger.logError("quarantine 기록 실패: " + fileName + ":" + lineNumber, qe);
        }
    }

    private void flushDiscardSummaries() {
        if (discardedAfterTruncate > 0) {
            quarantineNote("[DISCARDED_CONTINUATION_AFTER_TRUNCATE] count="
                    + discardedAfterTruncate
                    + " startLine=" + truncateStartLine
                    + " accumulatedBytes=" + truncateAccumulatedBytes
                    + " maxBytes=" + maxMessageBytes);
            discardedAfterTruncate = 0;
            truncateStartLine = 0;
            truncateAccumulatedBytes = 0;
        }
        if (orphanDiscardedAfterWarn > 0) {
            quarantineNote("[DISCARDED_ORPHAN_NONHEADER_AFTER_WARN] count="
                    + orphanDiscardedAfterWarn
                    + " warnThreshold=" + orphanNonHeaderWarnLines);
            orphanDiscardedAfterWarn = 0;
        }
    }

    private void resetOrphanStreak() {
        orphanNonHeaderStreak = 0;
    }

    @Override
    public void close() {
        if (closed) {
            return;
        }
        closed = true;
        try {
            reader.close();
        } catch (IOException e) {
            errorLogger.logError("로그 파일 닫기 오류: " + file, e);
        }
    }
}
