package com.loglineage.config;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/**
 * 런타임 YAML({@code loglineage.yaml}) 설정.
 * 파일/속성 부재 시 코드·app.properties 기본값을 유지한다.
 */
public final class RuntimeYamlConfig {
    public static final String FILE_NAME = "loglineage.yaml";

    /** named group: timestamp, level, trace, cmp, user, uri, thread, logger, message (+ optional pod) */
    public static final String DEFAULT_HEADER_WEB =
            "^(?<timestamp>\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}\\.\\d{3})\\s+(?<level>\\S+)\\s+"
                    + "\\[trace:\\s*(?<trace>[^\\]]*)\\]\\s*"
                    + "\\[cmp:\\s*(?<cmp>[^\\]]*)\\]\\s*"
                    + "\\[user:\\s*(?<user>[^\\]]*)\\]\\s*"
                    + "\\[uri:\\s*(?<uri>[^\\]]*)\\]\\s*"
                    + "\\[(?<thread>[^\\]]*)\\]\\s+(?<logger>\\S+)\\s+-\\s(?<message>.*)$";

    public static final String DEFAULT_HEADER_MOBILE =
            "^(?<timestamp>\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}\\.\\d{3})\\s+(?<level>\\S+)\\s+"
                    + "\\[trace:\\s*(?<trace>[^\\]]*)\\]\\s*"
                    + "\\[pod:\\s*(?<pod>[^\\]]*)\\]\\s*"
                    + "\\[cmp:\\s*(?<cmp>[^\\]]*)\\]\\s*"
                    + "\\[user:\\s*(?<user>[^\\]]*)\\]\\s*"
                    + "\\[uri:\\s*(?<uri>[^\\]]*)\\]\\s*"
                    + "\\[(?<thread>[^\\]]*)\\]\\s+(?<logger>\\S+)\\s+-\\s(?<message>.*)$";

    private final Long resultSplitMb;
    private final List<HeaderPatternSpec> headerPatterns;
    private final Map<String, String> filenamePatterns;
    private final List<String> loadWarnings;
    private final Path sourcePath;
    private final boolean loadedFromFile;

    private RuntimeYamlConfig(Long resultSplitMb,
                              List<HeaderPatternSpec> headerPatterns,
                              Map<String, String> filenamePatterns,
                              List<String> loadWarnings,
                              Path sourcePath,
                              boolean loadedFromFile) {
        this.resultSplitMb = resultSplitMb;
        this.headerPatterns = Collections.unmodifiableList(new ArrayList<>(headerPatterns));
        this.filenamePatterns = Collections.unmodifiableMap(new LinkedHashMap<>(filenamePatterns));
        this.loadWarnings = Collections.unmodifiableList(new ArrayList<>(loadWarnings));
        this.sourcePath = sourcePath;
        this.loadedFromFile = loadedFromFile;
    }

    public static RuntimeYamlConfig defaults() {
        return new RuntimeYamlConfig(null, defaultHeaderSpecs(), defaultFilenamePatterns(),
                Collections.<String>emptyList(), null, false);
    }

    public static RuntimeYamlConfig loadOrDefaults(Path file) {
        if (file == null || !Files.isRegularFile(file)) {
            return defaults();
        }
        try {
            String text = new String(Files.readAllBytes(file), StandardCharsets.UTF_8);
            return fromYamlText(text, file);
        } catch (IOException e) {
            List<String> warnings = new ArrayList<>();
            warnings.add("loglineage.yaml 읽기 실패, 기본값 사용: " + file + " — " + e.getMessage());
            return new RuntimeYamlConfig(null, defaultHeaderSpecs(), defaultFilenamePatterns(),
                    warnings, file, false);
        }
    }

    public static RuntimeYamlConfig loadClasspathOrDefaults(String resourceName) {
        try (InputStream in = RuntimeYamlConfig.class.getClassLoader().getResourceAsStream(resourceName)) {
            if (in == null) {
                return defaults();
            }
            byte[] buf = readAll(in);
            return fromYamlText(new String(buf, StandardCharsets.UTF_8), null);
        } catch (IOException e) {
            List<String> warnings = new ArrayList<>();
            warnings.add("classpath loglineage.yaml 읽기 실패, 기본값 사용: " + e.getMessage());
            return new RuntimeYamlConfig(null, defaultHeaderSpecs(), defaultFilenamePatterns(),
                    warnings, null, false);
        }
    }

    public static RuntimeYamlConfig fromYamlText(String text, Path sourcePath) {
        List<String> warnings = new ArrayList<>();
        Map<String, Object> root;
        try {
            root = SimpleYaml.parseMap(text);
        } catch (RuntimeException e) {
            warnings.add("loglineage.yaml 파싱 실패, 기본값 사용: " + e.getMessage());
            return new RuntimeYamlConfig(null, defaultHeaderSpecs(), defaultFilenamePatterns(),
                    warnings, sourcePath, false);
        }

        Long splitMb = SimpleYaml.asLong(root.get("result_split_mb"));
        if (splitMb != null && splitMb <= 0) {
            warnings.add("result_split_mb 가 유효하지 않아 무시: " + splitMb);
            splitMb = null;
        }

        List<HeaderPatternSpec> headers = parseHeaderPatterns(root.get("header_patterns"), warnings);
        if (headers.isEmpty()) {
            headers = defaultHeaderSpecs();
        }

        Map<String, String> filenames = parseFilenamePatterns(root.get("filename_patterns"), warnings);
        if (filenames.isEmpty()) {
            filenames = defaultFilenamePatterns();
        } else {
            // 누락 키는 기본값으로 채움
            Map<String, String> merged = defaultFilenamePatterns();
            merged.putAll(filenames);
            filenames = merged;
        }

        return new RuntimeYamlConfig(splitMb, headers, filenames, warnings, sourcePath, true);
    }

    private static List<HeaderPatternSpec> parseHeaderPatterns(Object raw, List<String> warnings) {
        List<HeaderPatternSpec> out = new ArrayList<>();
        if (raw == null) {
            return out;
        }
        List<Object> list = SimpleYaml.asList(raw);
        if (list.isEmpty() && raw instanceof String) {
            String regex = ((String) raw).trim();
            if (!regex.isEmpty()) {
                out.add(new HeaderPatternSpec("custom", regex));
            }
            return out;
        }
        int i = 0;
        for (Object item : list) {
            i++;
            if (item instanceof String) {
                String regex = ((String) item).trim();
                if (!regex.isEmpty()) {
                    out.add(new HeaderPatternSpec("pattern-" + i, regex));
                }
                continue;
            }
            Map<String, Object> map = SimpleYaml.asMap(item);
            if (map.isEmpty()) {
                continue;
            }
            String name = SimpleYaml.asString(map.get("name"));
            if (name == null || name.trim().isEmpty()) {
                name = "pattern-" + i;
            }
            String regex = SimpleYaml.asString(map.get("regex"));
            if (regex == null || regex.trim().isEmpty()) {
                warnings.add("header_patterns[" + i + "] regex 없음 — 건너뜀");
                continue;
            }
            out.add(new HeaderPatternSpec(name.trim(), regex.trim()));
        }
        return out;
    }

    private static Map<String, String> parseFilenamePatterns(Object raw, List<String> warnings) {
        Map<String, String> out = new LinkedHashMap<>();
        Map<String, Object> map = SimpleYaml.asMap(raw);
        if (map.isEmpty()) {
            return out;
        }
        putFilename(out, map, "web", warnings);
        putFilename(out, map, "mobile", warnings);
        putFilename(out, map, "mweb", warnings);
        putFilename(out, map, "login", warnings);
        return out;
    }

    private static void putFilename(Map<String, String> out, Map<String, Object> map, String key,
                                    List<String> warnings) {
        Object v = map.get(key);
        if (v == null) {
            return;
        }
        String s = SimpleYaml.asString(v);
        if (s == null || s.trim().isEmpty()) {
            warnings.add("filename_patterns." + key + " 비어 있어 기본값 유지");
            return;
        }
        out.put(key, s.trim());
    }

    public static List<HeaderPatternSpec> defaultHeaderSpecs() {
        List<HeaderPatternSpec> list = new ArrayList<>();
        list.add(new HeaderPatternSpec("web", DEFAULT_HEADER_WEB));
        list.add(new HeaderPatternSpec("mobile", DEFAULT_HEADER_MOBILE));
        return list;
    }

    public static Map<String, String> defaultFilenamePatterns() {
        Map<String, String> map = new LinkedHashMap<>();
        map.put("web", "tsms-web");
        map.put("mobile", "tsms-mobile");
        map.put("mweb", "tsms-mweb");
        map.put("login", "tsms-login");
        return map;
    }

    public List<Pattern> compileHeaderPatterns() {
        List<Pattern> compiled = new ArrayList<>();
        for (HeaderPatternSpec spec : headerPatterns) {
            try {
                compiled.add(Pattern.compile(spec.getRegex()));
            } catch (PatternSyntaxException e) {
                // caller should prefer compileHeaderPatterns(warnings)
                throw e;
            }
        }
        return compiled;
    }

    public List<Pattern> compileHeaderPatterns(List<String> warningsOut) {
        List<Pattern> compiled = new ArrayList<>();
        for (HeaderPatternSpec spec : headerPatterns) {
            try {
                compiled.add(Pattern.compile(spec.getRegex()));
            } catch (PatternSyntaxException e) {
                warningsOut.add("header_patterns '" + spec.getName() + "' 구문 오류로 비활성: "
                        + e.getDescription());
            }
        }
        if (compiled.isEmpty()) {
            warningsOut.add("유효한 header_patterns 없음 — 내장 기본 패턴 사용");
            for (HeaderPatternSpec spec : defaultHeaderSpecs()) {
                compiled.add(Pattern.compile(spec.getRegex()));
            }
        }
        return compiled;
    }

    public Long getResultSplitMb() {
        return resultSplitMb;
    }

    public List<HeaderPatternSpec> getHeaderPatterns() {
        return headerPatterns;
    }

    public Map<String, String> getFilenamePatterns() {
        return filenamePatterns;
    }

    public String getFilenamePattern(String key, String fallback) {
        String v = filenamePatterns.get(key);
        if (v == null || v.trim().isEmpty()) {
            return fallback;
        }
        return v;
    }

    public List<String> getLoadWarnings() {
        return loadWarnings;
    }

    public Path getSourcePath() {
        return sourcePath;
    }

    public boolean isLoadedFromFile() {
        return loadedFromFile;
    }

    private static byte[] readAll(InputStream in) throws IOException {
        byte[] buf = new byte[8192];
        int n;
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
        while ((n = in.read(buf)) >= 0) {
            out.write(buf, 0, n);
        }
        return out.toByteArray();
    }

    public static final class HeaderPatternSpec {
        private final String name;
        private final String regex;

        public HeaderPatternSpec(String name, String regex) {
            this.name = name;
            this.regex = regex;
        }

        public String getName() {
            return name;
        }

        public String getRegex() {
            return regex;
        }
    }
}
