package com.loglineage.config;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * JDK-only 최소 YAML 파서.
 * 지원: 맵/리스트/스칼라, indent 중첩, 주석(#), quoted 문자열, {@code |} 블록 스칼라.
 * (외부 SnakeYAML 등 의존성 없음)
 */
public final class SimpleYaml {
    /** 비정상 indent/구조로 인한 무한 루프 방지. */
    private static final int MAX_PARSE_STEPS = 100_000;

    private SimpleYaml() {
    }

    @SuppressWarnings("unchecked")
    public static Map<String, Object> parseMap(String text) {
        Object root = parse(text);
        if (root == null) {
            return new LinkedHashMap<>();
        }
        if (root instanceof Map) {
            return (Map<String, Object>) root;
        }
        throw new IllegalArgumentException("YAML 루트는 맵이어야 합니다");
    }

    public static Object parse(String text) {
        if (text == null || text.trim().isEmpty()) {
            return new LinkedHashMap<String, Object>();
        }
        List<String> lines = normalizeLines(text);
        ParseState state = new ParseState(lines);
        return state.parseBlock(0);
    }

    private static List<String> normalizeLines(String text) {
        String[] raw = text.replace("\r\n", "\n").replace('\r', '\n').split("\n", -1);
        List<String> lines = new ArrayList<>(raw.length);
        for (String line : raw) {
            lines.add(line);
        }
        return lines;
    }

    private static final class ParseState {
        private final List<String> lines;
        private int index;
        private int steps;

        private ParseState(List<String> lines) {
            this.lines = lines;
            this.index = 0;
            this.steps = 0;
        }

        private void tick() {
            steps++;
            if (steps > MAX_PARSE_STEPS) {
                throw new IllegalStateException(
                        "YAML 파싱 단계 초과(무한 루프 의심). lineIndex=" + index);
            }
        }

        private Object parseBlock(int minIndent) {
            skipBlankAndComments();
            if (index >= lines.size()) {
                return new LinkedHashMap<String, Object>();
            }
            int indent = indentOf(lines.get(index));
            if (indent < minIndent) {
                return new LinkedHashMap<String, Object>();
            }
            String trimmed = trimComment(lines.get(index).substring(indent));
            if (trimmed.startsWith("- ")) {
                return parseList(minIndent);
            }
            return parseMap(minIndent);
        }

        private Map<String, Object> parseMap(int minIndent) {
            Map<String, Object> map = new LinkedHashMap<>();
            while (index < lines.size()) {
                tick();
                int before = index;
                skipBlankAndComments();
                if (index >= lines.size()) {
                    break;
                }
                String line = lines.get(index);
                int indent = indentOf(line);
                if (indent < minIndent) {
                    break;
                }
                if (indent > minIndent && minIndent > 0) {
                    // 상위가 기대하는 indent 가 아니면 종료 (중첩은 키 처리에서 소비)
                    break;
                }
                if (indent != minIndent) {
                    // 루트(minIndent=0)에서 더 들여쓴 줄은 무시하지 않고 에러에 가깝게 스킵
                    if (minIndent == 0 && indent > 0 && map.isEmpty()) {
                        index++;
                        continue;
                    }
                    break;
                }
                String content = trimComment(line.substring(indent));
                if (content.startsWith("- ")) {
                    break;
                }
                int colon = indexOfKeyColon(content);
                if (colon < 0) {
                    index++;
                    continue;
                }
                String key = unquote(content.substring(0, colon).trim());
                String after = content.substring(colon + 1).trim();
                index++;
                if (after.isEmpty()) {
                    skipBlankAndComments();
                    if (index < lines.size()) {
                        int nextIndent = indentOf(lines.get(index));
                        String nextTrim = trimComment(lines.get(index).substring(
                                Math.min(nextIndent, lines.get(index).length())));
                        if (nextIndent > indent) {
                            if (nextTrim.startsWith("- ") || nextTrim.equals("-")) {
                                map.put(key, parseList(indent + 1));
                            } else {
                                map.put(key, parseMap(indent + 2 <= nextIndent ? nextIndent : indent + 2));
                            }
                            continue;
                        }
                    }
                    map.put(key, "");
                } else if (after.equals("|") || after.equals(">")) {
                    map.put(key, parseBlockScalar(indent, after.equals("|")));
                } else {
                    map.put(key, parseScalar(after));
                }
                if (index == before) {
                    index++;
                }
            }
            return map;
        }

        private List<Object> parseList(int minIndent) {
            List<Object> list = new ArrayList<>();
            while (index < lines.size()) {
                tick();
                int before = index;
                skipBlankAndComments();
                if (index >= lines.size()) {
                    break;
                }
                String line = lines.get(index);
                int indent = indentOf(line);
                if (indent < minIndent) {
                    break;
                }
                String content = trimComment(line.substring(indent));
                if (!content.startsWith("-")) {
                    break;
                }
                String afterDash = content.length() == 1 ? "" : content.substring(1).trim();
                index++;
                if (afterDash.isEmpty()) {
                    skipBlankAndComments();
                    if (index < lines.size() && indentOf(lines.get(index)) > indent) {
                        int childIndent = indentOf(lines.get(index));
                        String child = trimComment(lines.get(index).substring(childIndent));
                        if (child.startsWith("- ")) {
                            list.add(parseList(childIndent));
                        } else {
                            list.add(parseMap(childIndent));
                        }
                    } else {
                        list.add("");
                    }
                } else if (afterDash.equals("|") || afterDash.equals(">")) {
                    list.add(parseBlockScalar(indent, afterDash.equals("|")));
                } else {
                    int colon = indexOfKeyColon(afterDash);
                    if (colon > 0) {
                        // inline map start: - name: web  (index already past this list line)
                        Map<String, Object> item = new LinkedHashMap<>();
                        String k = unquote(afterDash.substring(0, colon).trim());
                        String v = afterDash.substring(colon + 1).trim();
                        if (v.isEmpty()) {
                            skipBlankAndComments();
                            if (index < lines.size() && indentOf(lines.get(index)) > indent) {
                                int childIndent = indentOf(lines.get(index));
                                item.put(k, parseMap(childIndent));
                            } else {
                                item.put(k, "");
                            }
                        } else if (v.equals("|") || v.equals(">")) {
                            item.put(k, parseBlockScalar(indent, v.equals("|")));
                        } else {
                            item.put(k, parseScalar(v));
                        }
                        // continue reading more keys of this list item map
                        while (index < lines.size()) {
                            tick();
                            int itemBefore = index;
                            skipBlankAndComments();
                            if (index >= lines.size()) {
                                break;
                            }
                            int ni = indentOf(lines.get(index));
                            if (ni <= indent) {
                                break;
                            }
                            String nc = trimComment(lines.get(index).substring(ni));
                            if (nc.startsWith("-")) {
                                break;
                            }
                            int c2 = indexOfKeyColon(nc);
                            if (c2 < 0) {
                                break;
                            }
                            String k2 = unquote(nc.substring(0, c2).trim());
                            String v2 = nc.substring(c2 + 1).trim();
                            index++;
                            if (v2.isEmpty()) {
                                skipBlankAndComments();
                                if (index < lines.size() && indentOf(lines.get(index)) > ni) {
                                    item.put(k2, parseMap(indentOf(lines.get(index))));
                                } else {
                                    item.put(k2, "");
                                }
                            } else if (v2.equals("|") || v2.equals(">")) {
                                item.put(k2, parseBlockScalar(ni, v2.equals("|")));
                            } else {
                                item.put(k2, parseScalar(v2));
                            }
                            if (index == itemBefore) {
                                index++;
                            }
                        }
                        list.add(item);
                    } else {
                        list.add(parseScalar(afterDash));
                    }
                }
                if (index == before) {
                    index++;
                }
            }
            return list;
        }

        private String parseBlockScalar(int parentIndent, boolean literal) {
            StringBuilder sb = new StringBuilder();
            boolean first = true;
            while (index < lines.size()) {
                String line = lines.get(index);
                if (line.trim().isEmpty()) {
                    // blank line inside block
                    int peek = index + 1;
                    boolean more = false;
                    while (peek < lines.size()) {
                        if (!lines.get(peek).trim().isEmpty() && !isCommentLine(lines.get(peek))) {
                            more = indentOf(lines.get(peek)) > parentIndent;
                            break;
                        }
                        peek++;
                    }
                    if (!more) {
                        break;
                    }
                    if (!first) {
                        sb.append('\n');
                    }
                    index++;
                    first = false;
                    continue;
                }
                if (isCommentLine(line) && indentOf(line) <= parentIndent) {
                    break;
                }
                int indent = indentOf(line);
                if (indent <= parentIndent) {
                    break;
                }
                if (!first) {
                    sb.append(literal ? '\n' : ' ');
                }
                sb.append(line.substring(indent));
                first = false;
                index++;
            }
            return sb.toString();
        }

        private void skipBlankAndComments() {
            while (index < lines.size()) {
                String line = lines.get(index);
                if (line.trim().isEmpty() || isCommentLine(line)) {
                    index++;
                    continue;
                }
                break;
            }
        }
    }

    private static boolean isCommentLine(String line) {
        int i = 0;
        while (i < line.length() && line.charAt(i) == ' ') {
            i++;
        }
        return i < line.length() && line.charAt(i) == '#';
    }

    private static int indentOf(String line) {
        int i = 0;
        while (i < line.length() && line.charAt(i) == ' ') {
            i++;
        }
        if (i < line.length() && line.charAt(i) == '\t') {
            throw new IllegalArgumentException("YAML 들여쓰기는 스페이스만 지원합니다");
        }
        return i;
    }

    private static String trimComment(String content) {
        boolean inSingle = false;
        boolean inDouble = false;
        for (int i = 0; i < content.length(); i++) {
            char c = content.charAt(i);
            if (c == '\'' && !inDouble) {
                inSingle = !inSingle;
            } else if (c == '"' && !inSingle) {
                inDouble = !inDouble;
            } else if (c == '#' && !inSingle && !inDouble) {
                return content.substring(0, i).trim();
            }
        }
        return content.trim();
    }

    private static int indexOfKeyColon(String content) {
        boolean inSingle = false;
        boolean inDouble = false;
        for (int i = 0; i < content.length(); i++) {
            char c = content.charAt(i);
            if (c == '\'' && !inDouble) {
                inSingle = !inSingle;
            } else if (c == '"' && !inSingle) {
                inDouble = !inDouble;
            } else if (c == ':' && !inSingle && !inDouble) {
                return i;
            }
        }
        return -1;
    }

    private static Object parseScalar(String raw) {
        String v = raw.trim();
        if (v.isEmpty()) {
            return "";
        }
        if ((v.startsWith("'") && v.endsWith("'")) || (v.startsWith("\"") && v.endsWith("\""))) {
            return unquote(v);
        }
        if ("true".equalsIgnoreCase(v) || "false".equalsIgnoreCase(v)) {
            return Boolean.parseBoolean(v);
        }
        if (isInteger(v)) {
            try {
                return Long.parseLong(v);
            } catch (NumberFormatException ignored) {
                // fall through
            }
        }
        return v;
    }

    private static boolean isInteger(String v) {
        if (v.isEmpty()) {
            return false;
        }
        int i = 0;
        if (v.charAt(0) == '+' || v.charAt(0) == '-') {
            i = 1;
        }
        if (i >= v.length()) {
            return false;
        }
        for (; i < v.length(); i++) {
            if (!Character.isDigit(v.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    private static String unquote(String v) {
        if (v == null) {
            return null;
        }
        String s = v.trim();
        if (s.length() >= 2) {
            if (s.startsWith("'") && s.endsWith("'")) {
                return s.substring(1, s.length() - 1).replace("''", "'");
            }
            if (s.startsWith("\"") && s.endsWith("\"")) {
                return unescapeDouble(s.substring(1, s.length() - 1));
            }
        }
        return s;
    }

    private static String unescapeDouble(String s) {
        StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\\' && i + 1 < s.length()) {
                char n = s.charAt(++i);
                switch (n) {
                    case 'n':
                        sb.append('\n');
                        break;
                    case 't':
                        sb.append('\t');
                        break;
                    case 'r':
                        sb.append('\r');
                        break;
                    case '\\':
                        sb.append('\\');
                        break;
                    case '"':
                        sb.append('"');
                        break;
                    default:
                        sb.append(n);
                        break;
                }
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    public static String asString(Object value) {
        if (value == null) {
            return null;
        }
        if (value instanceof String) {
            return (String) value;
        }
        return String.valueOf(value);
    }

    public static Long asLong(Object value) {
        if (value == null) {
            return null;
        }
        if (value instanceof Number) {
            return ((Number) value).longValue();
        }
        String s = String.valueOf(value).trim();
        if (s.isEmpty()) {
            return null;
        }
        try {
            return Long.parseLong(s);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    public static Map<String, Object> asMap(Object value) {
        if (value instanceof Map) {
            return (Map<String, Object>) value;
        }
        return Collections.emptyMap();
    }

    @SuppressWarnings("unchecked")
    public static List<Object> asList(Object value) {
        if (value instanceof List) {
            return (List<Object>) value;
        }
        return Collections.emptyList();
    }
}
