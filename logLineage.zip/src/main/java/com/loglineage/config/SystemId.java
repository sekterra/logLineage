package com.loglineage.config;

/**
 * 로그 파일명으로 판별한 시스템 식별자.
 * 2중화로 파일이 여러 개여도 동일 토큰이면 같은 값으로 통일한다.
 */
public final class SystemId {
    public static final String WEB = "WEB";
    public static final String MOBILE = "MOBILE";
    public static final String MWEB = "MWEB";
    public static final String LOGIN = "LOGIN";
    public static final String UNIDENTIFIED = "미식별";

    private SystemId() {
    }
}
