package com.loglineage.config;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * 파일명 토큰으로 시스템을 판별한다.
 * 더 구체적(긴) 토큰을 먼저 매칭해 {@code tsms-mweb} 가 {@code tsms-web} 으로
 * 오인되지 않도록 한다.
 */
public class SystemClassifier {
    private final List<Rule> rules;

    public SystemClassifier(String webToken, String mobileToken, String mwebToken, String loginToken) {
        List<Rule> built = new ArrayList<>();
        // 긴/구체 토큰 우선
        built.add(new Rule(normalizeToken(mwebToken, "tsms-mweb"), SystemId.MWEB));
        built.add(new Rule(normalizeToken(mobileToken, "tsms-mobile"), SystemId.MOBILE));
        built.add(new Rule(normalizeToken(loginToken, "tsms-login"), SystemId.LOGIN));
        built.add(new Rule(normalizeToken(webToken, "tsms-web"), SystemId.WEB));
        built.sort((a, b) -> Integer.compare(b.token.length(), a.token.length()));
        this.rules = built;
    }

    public static SystemClassifier fromAppConfig(AppConfig config) {
        return new SystemClassifier(
                config.getSystemWebFilenameContains(),
                config.getSystemMobileFilenameContains(),
                config.getSystemMwebFilenameContains(),
                config.getSystemLoginFilenameContains());
    }

    /**
     * 파일명(경로 제외)으로 시스템 코드를 반환. 매칭 실패 시 {@link SystemId#UNIDENTIFIED}.
     */
    public String classify(String fileName) {
        if (fileName == null || fileName.isEmpty()) {
            return SystemId.UNIDENTIFIED;
        }
        String lower = fileName.toLowerCase(Locale.ROOT);
        for (Rule rule : rules) {
            if (lower.contains(rule.token)) {
                return rule.systemId;
            }
        }
        return SystemId.UNIDENTIFIED;
    }

    private static String normalizeToken(String raw, String defaultToken) {
        if (raw == null) {
            return defaultToken;
        }
        String trimmed = raw.trim().toLowerCase(Locale.ROOT);
        return trimmed.isEmpty() ? defaultToken : trimmed;
    }

    private static final class Rule {
        private final String token;
        private final String systemId;

        private Rule(String token, String systemId) {
            this.token = token;
            this.systemId = systemId;
        }
    }
}
