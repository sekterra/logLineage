package com.loglineage.config;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.TreeMap;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/**
 * error-signature.properties 로더.
 * {@code error.signature.regex.N} 키의 정규식으로 메시지 기반 에러를 판정한다.
 */
public class ErrorSignatureConfig {
    public static final int MAX_PATTERN_LENGTH = 512;
    private static final String KEY_PREFIX = "error.signature.regex.";

    private final List<Pattern> signatures;
    private final List<String> loadWarnings;

    public ErrorSignatureConfig(List<Pattern> signatures, List<String> loadWarnings) {
        this.signatures = Collections.unmodifiableList(new ArrayList<>(
                signatures == null ? Collections.<Pattern>emptyList() : signatures));
        this.loadWarnings = Collections.unmodifiableList(new ArrayList<>(
                loadWarnings == null ? Collections.<String>emptyList() : loadWarnings));
    }

    public static ErrorSignatureConfig load(Path propertiesFile) throws IOException {
        return fromProperties(AppConfig.loadProperties(propertiesFile));
    }

    public static ErrorSignatureConfig loadDefault() throws IOException {
        return fromProperties(AppConfig.loadClasspathOrEmpty("error-signature.properties"));
    }

    private static ErrorSignatureConfig fromProperties(Properties props) {
        List<String> warnings = new ArrayList<>();
        List<Pattern> patterns = new ArrayList<>();
        TreeMap<Integer, String> ordered = new TreeMap<>();
        for (Map.Entry<Object, Object> entry : props.entrySet()) {
            String key = String.valueOf(entry.getKey()).trim();
            if (!key.startsWith(KEY_PREFIX)) {
                continue;
            }
            String suffix = key.substring(KEY_PREFIX.length()).trim();
            try {
                ordered.put(Integer.parseInt(suffix), String.valueOf(entry.getValue()));
            } catch (NumberFormatException e) {
                warnings.add("error-signature 키 무시(번호 아님): " + key);
            }
        }
        for (Map.Entry<Integer, String> entry : ordered.entrySet()) {
            String key = KEY_PREFIX + entry.getKey();
            Pattern compiled = compileOrNull(entry.getValue(), key, warnings);
            if (compiled != null) {
                patterns.add(compiled);
            }
        }
        return new ErrorSignatureConfig(patterns, warnings);
    }

    private static Pattern compileOrNull(String raw, String key, List<String> warnings) {
        if (raw == null) {
            return null;
        }
        String trimmed = raw.trim();
        if (trimmed.isEmpty()) {
            return null;
        }
        if (trimmed.length() > MAX_PATTERN_LENGTH) {
            warnings.add("error-signature 패턴 길이 초과로 비활성: " + key
                    + " (max=" + MAX_PATTERN_LENGTH + ", actual=" + trimmed.length() + ")");
            return null;
        }
        try {
            return Pattern.compile(trimmed, Pattern.MULTILINE);
        } catch (PatternSyntaxException e) {
            warnings.add("error-signature 패턴 구문 오류로 비활성: " + key + " — " + e.getDescription());
            return null;
        }
    }

    public List<Pattern> getSignatures() {
        return signatures;
    }

    public List<String> getLoadWarnings() {
        return loadWarnings;
    }

    /**
     * 메시지(연속 라인 포함)가 시그니처 중 하나라도 매칭되면 true.
     */
    public boolean matchesMessage(String message) {
        if (message == null || message.isEmpty() || signatures.isEmpty()) {
            return false;
        }
        for (Pattern pattern : signatures) {
            if (pattern.matcher(message).find()) {
                return true;
            }
        }
        return false;
    }
}
