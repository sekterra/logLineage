package com.loglineage.lineage;

import com.loglineage.model.LogEvent;

import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

/**
 * Pass 1: 에러 발생 (회사코드,사번) 키만 수집. 이벤트 본문은 보관하지 않는다.
 */
public class Pass1IdentityIndex {
    private final Map<String, GroupAcc> open = new HashMap<>();
    private final Set<UserKey> targetUsers = new LinkedHashSet<>();
    private long errorEventCount;

    public void accept(LogEvent event, ErrorEventDetector detector) {
        if (event == null) {
            return;
        }
        detector.apply(event);
        boolean hasFull = isPresent(event.getCmp()) && isPresent(event.getUser());
        String traceId = event.getTraceId();

        if (traceId == null || traceId.isEmpty()) {
            if (event.isErrorEvent()) {
                errorEventCount++;
                if (hasFull) {
                    targetUsers.add(UserKey.of(event.getCmp(), event.getUser()));
                }
            }
            return;
        }

        // 정상·신원완전·그룹 미개시 이벤트는 Acc 생성 없이 스킵 (대용량 비에러 로그 메모리 방어)
        if (!event.isErrorEvent() && hasFull && !open.containsKey(traceId)) {
            return;
        }

        GroupAcc acc = open.get(traceId);
        if (acc == null) {
            acc = new GroupAcc();
            open.put(traceId, acc);
        }
        if (isPresent(event.getCmp())) {
            acc.cmps.add(event.getCmp().trim());
        }
        if (isPresent(event.getUser())) {
            acc.users.add(event.getUser().trim());
        }
        if (event.isErrorEvent()) {
            errorEventCount++;
            acc.sawError = true;
            if (hasFull) {
                targetUsers.add(UserKey.of(event.getCmp(), event.getUser()));
            }
        }
    }

    public void finishFile(String sourceFile) {
        for (GroupAcc acc : open.values()) {
            if (!acc.sawError) {
                continue;
            }
            String resolvedCmp = acc.cmps.isEmpty() ? null : acc.cmps.iterator().next();
            String resolvedUser = acc.users.isEmpty() ? null : acc.users.iterator().next();
            UserKey uk = UserKey.of(resolvedCmp, resolvedUser);
            if (uk != null) {
                targetUsers.add(uk);
            }
        }
        open.clear();
    }

    public boolean isTargetUser(String cmp, String user) {
        UserKey uk = UserKey.of(cmp, user);
        return uk != null && targetUsers.contains(uk);
    }

    public Set<UserKey> getTargetUsers() {
        return Collections.unmodifiableSet(targetUsers);
    }

    public long getErrorEventCount() {
        return errorEventCount;
    }

    private static boolean isPresent(String v) {
        return v != null && !v.trim().isEmpty();
    }

    public static final class UserKey {
        private final String companyCode;
        private final String employeeId;

        private UserKey(String companyCode, String employeeId) {
            this.companyCode = companyCode;
            this.employeeId = employeeId;
        }

        public static UserKey of(String cmp, String user) {
            if (!isPresent(cmp) || !isPresent(user)) {
                return null;
            }
            return new UserKey(cmp.trim(), user.trim());
        }

        public String getCompanyCode() {
            return companyCode;
        }

        public String getEmployeeId() {
            return employeeId;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }
            if (!(o instanceof UserKey)) {
                return false;
            }
            UserKey userKey = (UserKey) o;
            return Objects.equals(companyCode, userKey.companyCode)
                    && Objects.equals(employeeId, userKey.employeeId);
        }

        @Override
        public int hashCode() {
            return Objects.hash(companyCode, employeeId);
        }
    }

    private static final class GroupAcc {
        private final LinkedHashSet<String> cmps = new LinkedHashSet<>();
        private final LinkedHashSet<String> users = new LinkedHashSet<>();
        private boolean sawError;
    }
}
