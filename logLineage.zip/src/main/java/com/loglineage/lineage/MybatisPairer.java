package com.loglineage.lineage;

import com.loglineage.model.LogEvent;
import com.loglineage.model.SqlPair;
import com.loglineage.model.TraceGroup;
import com.loglineage.parse.MybatisParameterParser;
import com.loglineage.sql.SqlBinder;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * 동일 thread + 동일 traceId 기준으로 Preparing / Parameters / Total 페어링.
 */
public class MybatisPairer {
    private static final Pattern LOG_TIMESTAMP_PREFIX = Pattern.compile(
            "^\\d{4}-\\d{2}-\\d{2}[ T]\\d{2}:\\d{2}:\\d{2}");

    private final MybatisParameterParser parameterParser;
    private final SqlBinder sqlBinder;

    public MybatisPairer(MybatisParameterParser parameterParser, SqlBinder sqlBinder) {
        this.parameterParser = parameterParser;
        this.sqlBinder = sqlBinder;
    }

    /**
     * Preparing 이벤트 → SqlPair 매핑. Parameters/Total은 소비 대상으로 표시.
     */
    public PairingResult pair(TraceGroup group) {
        Map<LogEvent, SqlPair> preparingToSql = new HashMap<>();
        Set<LogEvent> consumed = new HashSet<>();
        List<LogEvent> events = group.getEvents();

        for (int i = 0; i < events.size(); i++) {
            LogEvent preparing = events.get(i);
            if (!preparing.isMybatisPreparing()) {
                continue;
            }
            LogEvent parameters = null;
            LogEvent total = null;
            for (int j = i + 1; j < events.size(); j++) {
                LogEvent candidate = events.get(j);
                if (!samePairKey(preparing, candidate)) {
                    continue;
                }
                if (parameters == null && candidate.isMybatisParameters()) {
                    parameters = candidate;
                    continue;
                }
                if (parameters != null && total == null && candidate.isMybatisTotal()) {
                    total = candidate;
                    break;
                }
                // 다음 Preparing이 같은 키로 오면 현재 페어 종료
                if (candidate.isMybatisPreparing()) {
                    break;
                }
            }

            String template = extractPreparingSql(preparing.getMessage());
            String executable = template;
            if (parameters != null) {
                List<MybatisParameterParser.Param> params = parameterParser.parse(parameters.getMessage());
                executable = sqlBinder.bind(template, params);
                consumed.add(parameters);
            }
            if (total != null) {
                consumed.add(total);
            }
            // 바인딩 후에도 로그 잔여물이 남지 않도록 한 번 더 정제
            executable = sanitizeSqlOnly(executable);
            preparingToSql.put(preparing, new SqlPair(template, executable));
        }
        return new PairingResult(preparingToSql, consumed);
    }

    private static boolean samePairKey(LogEvent a, LogEvent b) {
        return Objects.equals(nullToEmpty(a.getThread()), nullToEmpty(b.getThread()))
                && Objects.equals(nullToEmpty(a.getTraceId()), nullToEmpty(b.getTraceId()));
    }

    private static String nullToEmpty(String v) {
        return v == null ? "" : v;
    }

    /**
     * Preparing 메시지에서 SQL 구문만 추출한다.
     * continuation/스택/Parameters 등 로그 잔여물은 제외한다.
     */
    public static String extractPreparingSql(String message) {
        if (message == null) {
            return "";
        }
        int idx = message.indexOf("Preparing:");
        String raw = idx < 0 ? message : message.substring(idx + "Preparing:".length());
        return sanitizeSqlOnly(raw);
    }

    /**
     * SQL 본문만 남긴다. 줄 단위로 로그 노이즈가 나오면 중단하고,
     * 한 줄 안에 {@code ==>}/{@code Parameters:} 등이 붙으면 그 앞에서 자른다.
     * 여러 줄 SQL은 공백으로 이어 붙여 구문을 유지한다.
     */
    static String sanitizeSqlOnly(String raw) {
        if (raw == null) {
            return "";
        }
        String[] lines = raw.split("\\R", -1);
        StringBuilder sb = new StringBuilder();
        for (String line : lines) {
            String trimmed = line == null ? "" : line.trim();
            if (trimmed.isEmpty()) {
                if (sb.length() > 0) {
                    break;
                }
                continue;
            }
            String cut = cutInlineLogNoise(trimmed);
            if (cut.isEmpty() || looksLikeLogNoise(cut)) {
                break;
            }
            if (sb.length() > 0) {
                sb.append(' ');
            }
            sb.append(cut);
        }
        return sb.toString().trim();
    }

    private static String cutInlineLogNoise(String line) {
        int cut = line.length();
        cut = minPositive(cut, indexOfIgnoreCase(line, "==>"));
        cut = minPositive(cut, indexOfIgnoreCase(line, "<=="));
        cut = minPositive(cut, indexOfIgnoreCase(line, "Parameters:"));
        cut = minPositive(cut, indexOfIgnoreCase(line, "Total:"));
        // Preparing 가 중복 삽입된 경우
        int prep = indexOfIgnoreCase(line, "Preparing:");
        if (prep > 0) {
            cut = Math.min(cut, prep);
        }
        return line.substring(0, cut).trim();
    }

    private static int minPositive(int current, int candidate) {
        if (candidate < 0) {
            return current;
        }
        return Math.min(current, candidate);
    }

    private static int indexOfIgnoreCase(String haystack, String needle) {
        return haystack.toLowerCase().indexOf(needle.toLowerCase());
    }

    static boolean looksLikeLogNoise(String line) {
        if (line == null || line.isEmpty()) {
            return true;
        }
        String t = line.trim();
        if (t.startsWith("==>") || t.startsWith("<==")) {
            return true;
        }
        if (t.startsWith("at ") || t.startsWith("Caused by:")) {
            return true;
        }
        if (t.regionMatches(true, 0, "Parameters:", 0, "Parameters:".length())) {
            return true;
        }
        if (t.regionMatches(true, 0, "Preparing:", 0, "Preparing:".length())) {
            return true;
        }
        if (LOG_TIMESTAMP_PREFIX.matcher(t).find()) {
            return true;
        }
        return false;
    }

    public static final class PairingResult {
        private final Map<LogEvent, SqlPair> preparingToSql;
        private final Set<LogEvent> consumed;

        public PairingResult(Map<LogEvent, SqlPair> preparingToSql, Set<LogEvent> consumed) {
            this.preparingToSql = preparingToSql;
            this.consumed = consumed;
        }

        public Map<LogEvent, SqlPair> getPreparingToSql() {
            return preparingToSql;
        }

        public Set<LogEvent> getConsumed() {
            return consumed;
        }
    }
}
