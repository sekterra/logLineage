package com.loglineage.lineage;

import com.loglineage.config.ErrorSignatureConfig;
import com.loglineage.model.LogEvent;

/**
 * IS_ERROR_EVENT 판정: LEVEL=ERROR 또는 error-signature 메시지 매칭.
 */
public class ErrorEventDetector {
    private final ErrorSignatureConfig signatureConfig;

    public ErrorEventDetector(ErrorSignatureConfig signatureConfig) {
        this.signatureConfig = signatureConfig;
    }

    public void apply(LogEvent event) {
        if (event == null) {
            return;
        }
        boolean errorLevel = event.getLevel() != null
                && "ERROR".equalsIgnoreCase(event.getLevel().trim());
        boolean signatureHit = signatureConfig != null
                && signatureConfig.matchesMessage(event.getMessage());
        event.setErrorEvent(errorLevel || signatureHit);
    }
}
