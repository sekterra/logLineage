package com.loglineage;

import com.loglineage.config.AppConfig;
import com.loglineage.config.ClassifyConfig;
import com.loglineage.config.ErrorSignatureConfig;
import com.loglineage.config.MybatisTypeConfig;
import com.loglineage.config.RuntimeYamlConfig;
import com.loglineage.config.SystemClassifier;
import com.loglineage.config.SystemId;
import com.loglineage.io.LogFileReader;
import com.loglineage.io.LogFileScanner;
import com.loglineage.lineage.ContextRuleEngine;
import com.loglineage.lineage.ErrorEventDetector;
import com.loglineage.lineage.EventClassifier;
import com.loglineage.lineage.LineageRecordFactory;
import com.loglineage.lineage.MybatisPairer;
import com.loglineage.lineage.Pass1IdentityIndex;
import com.loglineage.lineage.ThreadTracePropagator;
import com.loglineage.lineage.TraceGroupBuilder;
import com.loglineage.model.LineageRecord;
import com.loglineage.model.LogEvent;
import com.loglineage.model.TraceGroup;
import com.loglineage.output.ExecutionErrorLogger;
import com.loglineage.output.OutputFilePermissionHardener;
import com.loglineage.output.QuarantineWriter;
import com.loglineage.output.RunSummaryWriter;
import com.loglineage.output.TsvWriter;
import com.loglineage.parse.LogLineParser;
import com.loglineage.parse.MybatisParameterParser;
import com.loglineage.sql.SqlBinder;
import com.loglineage.util.ProgressReporter;
import com.loglineage.util.TsvUtil;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * 에러 사용자 중심 RCA 타임라인 CLI (2-Pass 저메모리).
 */
public final class LogLineageApp {
    private static final DateTimeFormatter RUN_ID_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd-HHmmss");

    private LogLineageApp() {
    }

    public static void main(String[] args) {
        if (args.length < 1 || args.length > 3) {
            printUsage();
            System.exit(1);
            return;
        }
        Path logDir = Paths.get(args[0]);
        Path configDir = null;
        Long resultSplitMb = null;

        if (args.length >= 2) {
            Long mb = parsePositiveLong(args[1]);
            if (mb != null) {
                resultSplitMb = mb;
            } else {
                configDir = Paths.get(args[1]);
            }
        }
        if (args.length >= 3) {
            Long mb = parsePositiveLong(args[2]);
            if (mb == null) {
                System.err.println("result 분할 크기(MB)는 양의 정수여야 합니다: " + args[2]);
                printUsage();
                System.exit(1);
                return;
            }
            resultSplitMb = mb;
        }

        System.exit(new LogLineageApp().run(logDir, configDir, resultSplitMb));
    }

    private static void printUsage() {
        System.err.println("사용법:");
        System.err.println("  run.bat <로그폴더경로> [설정폴더경로] [result분할MB]");
        System.err.println("  run.bat <로그폴더경로> [result분할MB]");
        System.err.println("설정폴더의 loglineage.yaml 로 result분할MB/헤더패턴/파일명패턴을 지정할 수 있습니다.");
        System.err.println("result 분할 우선순위: CLI > YAML > app.properties > 기본 200MB");
        System.err.println("출력은 <로그폴더>/output 에 생성됩니다.");
    }

    private static Long parsePositiveLong(String raw) {
        if (raw == null) {
            return null;
        }
        String trimmed = raw.trim();
        if (trimmed.isEmpty()) {
            return null;
        }
        for (int i = 0; i < trimmed.length(); i++) {
            if (!Character.isDigit(trimmed.charAt(i))) {
                return null;
            }
        }
        try {
            long value = Long.parseLong(trimmed);
            return value > 0 ? value : null;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    int run(Path logDir, Path configDir) {
        return run(logDir, configDir, null);
    }

    int run(Path logDir, Path configDir, Long resultSplitMb) {
        Instant started = Instant.now();
        String runId = LocalDateTime.now().format(RUN_ID_FORMAT);
        Path outDir = logDir.resolve("output");
        ExecutionErrorLogger errorLogger = null;
        QuarantineWriter quarantineWriter = null;
        TsvWriter tsvWriter = null;
        OutputFilePermissionHardener permissionHardener = new OutputFilePermissionHardener();

        try {
            recreateOutputDirectory(outDir);

            AppConfig appConfig = loadAppConfig(configDir);
            ClassifyConfig classifyConfig = loadClassifyConfig(configDir);
            MybatisTypeConfig typeConfig = loadMybatisTypeConfig(configDir);
            ErrorSignatureConfig signatureConfig = loadErrorSignatureConfig(configDir);
            RuntimeYamlConfig runtimeConfig = loadRuntimeYamlConfig(configDir);

            errorLogger = new ExecutionErrorLogger(outDir, runId, appConfig.getOutputCharset(), permissionHardener);
            for (String warning : classifyConfig.getLoadWarnings()) {
                errorLogger.logError(warning, null);
            }
            for (String warning : signatureConfig.getLoadWarnings()) {
                errorLogger.logError(warning, null);
            }
            for (String warning : runtimeConfig.getLoadWarnings()) {
                errorLogger.logError(warning, null);
            }
            if (runtimeConfig.isLoadedFromFile()) {
                System.out.println("런타임 YAML: "
                        + (runtimeConfig.getSourcePath() != null
                        ? runtimeConfig.getSourcePath().toAbsolutePath()
                        : "classpath:" + RuntimeYamlConfig.FILE_NAME));
            }

            quarantineWriter = new QuarantineWriter(outDir, runId, appConfig.getOutputCharset(), permissionHardener);
            QuarantineWriter pass1Quarantine = new QuarantineWriter(outDir, runId, appConfig.getOutputCharset(),
                    permissionHardener, true);
            long resultSplitBytes = resolveResultSplitBytes(appConfig, runtimeConfig, resultSplitMb);
            if (resultSplitMb != null) {
                System.out.println("result 분할 한도: " + resultSplitMb + "MB (CLI)");
            } else if (runtimeConfig.getResultSplitMb() != null) {
                System.out.println("result 분할 한도: " + runtimeConfig.getResultSplitMb() + "MB (YAML)");
            } else {
                System.out.println("result 분할 한도: "
                        + (resultSplitBytes / (1024L * 1024L)) + "MB (설정/기본)");
            }
            tsvWriter = new TsvWriter(outDir, runId, appConfig.getOutputCharset(), permissionHardener,
                    resultSplitBytes);

            LogFileScanner scanner = new LogFileScanner(appConfig, errorLogger);
            List<Path> files = scanner.scan(logDir);
            SystemClassifier systemClassifier = SystemClassifier.fromAppConfig(appConfig, runtimeConfig);
            ProgressReporter progress = new ProgressReporter(started, appConfig.getProgressEveryLines());

            List<String> fileNames = new ArrayList<>();
            List<String> fileSystemLabels = new ArrayList<>();
            List<String> unidentifiedFiles = new ArrayList<>();
            List<String> systems = new ArrayList<>();
            for (Path file : files) {
                String name = file.getFileName().toString();
                String system = systemClassifier.classify(name);
                fileNames.add(name);
                fileSystemLabels.add(name + " => " + system);
                systems.add(system);
                if (SystemId.UNIDENTIFIED.equals(system)) {
                    unidentifiedFiles.add(name);
                }
            }
            if (!unidentifiedFiles.isEmpty()) {
                writeUnidentifiedSystemsReport(outDir, runId, appConfig.getOutputCharset(),
                        unidentifiedFiles, permissionHardener);
            }

            List<String> headerWarnings = new ArrayList<>();
            LogLineParser lineParser = LogLineParser.fromRuntimeConfig(runtimeConfig, headerWarnings);
            for (String warning : headerWarnings) {
                errorLogger.logError(warning, null);
            }
            ErrorEventDetector errorDetector = new ErrorEventDetector(signatureConfig);

            // -------- Pass 1: 에러 사용자 키만 수집 --------
            Pass1IdentityIndex pass1 = new Pass1IdentityIndex();
            long pass1Lines = 0;
            for (int i = 0; i < files.size(); i++) {
                Path file = files.get(i);
                String system = systems.get(i);
                try (LogFileReader reader = openReader(file, appConfig, lineParser,
                        pass1Quarantine, errorLogger, system)) {
                    ThreadTracePropagator propagator = new ThreadTracePropagator();
                    long fileLinesAtStart = pass1Lines;
                    Optional<LogEvent> next;
                    while ((next = reader.readNext()).isPresent()) {
                        LogEvent event = next.get();
                        propagator.apply(event);
                        pass1.accept(event, errorDetector);
                        pass1Lines = fileLinesAtStart + reader.getLinesRead();
                        if (pass1Lines > 0 && pass1Lines % progress.getReportEveryLines() == 0) {
                            progress.passProgress(1, 2, i + 1, files.size(), reader.getFileName(),
                                    pass1Lines, pass1.getTargetUsers().size(), "식별된 대상 사용자");
                        }
                    }
                    pass1.finishFile(reader.getFileName());
                    pass1Lines = fileLinesAtStart + reader.getLinesRead();
                    progress.passProgress(1, 2, i + 1, files.size(), reader.getFileName(),
                            pass1Lines, pass1.getTargetUsers().size(), "식별된 대상 사용자");
                } catch (Exception e) {
                    errorLogger.logError("Pass1 파일 처리 실패: " + file, e);
                }
            }
            progress.passComplete(1, 2, pass1Lines, pass1.getTargetUsers().size(), "식별된 대상 사용자(명)");

            // -------- Pass 2: 대상 사용자 이벤트만 버퍼 --------
            ContextRuleEngine ruleEngine = new ContextRuleEngine();
            MybatisPairer pairer = new MybatisPairer(new MybatisParameterParser(), new SqlBinder(typeConfig));
            LineageRecordFactory recordFactory = new LineageRecordFactory(new EventClassifier(classifyConfig));
            List<LineageRecord> timeline = new ArrayList<>();
            long pass2Lines = 0;
            long collectedEvents = 0;
            long estimatedBytes = 0;
            boolean bufferWarned = false;
            long groupCount = 0;

            for (int i = 0; i < files.size(); i++) {
                Path file = files.get(i);
                String system = systems.get(i);
                try (LogFileReader reader = openReader(file, appConfig, lineParser,
                        quarantineWriter, errorLogger, system)) {
                    ThreadTracePropagator propagator = new ThreadTracePropagator();
                    Map<String, TargetGroupBuffer> openGroups = new HashMap<>();
                    List<LogEvent> nullTraceKept = new ArrayList<>();
                    long fileLinesAtStart = pass2Lines;
                    Optional<LogEvent> next;
                    while ((next = reader.readNext()).isPresent()) {
                        LogEvent event = next.get();
                        propagator.apply(event);
                        pass2Lines = fileLinesAtStart + reader.getLinesRead();

                        String traceId = event.getTraceId();
                        if (traceId == null || traceId.isEmpty()) {
                            if (pass1.isTargetUser(event.getCmp(), event.getUser())) {
                                nullTraceKept.add(event);
                                collectedEvents++;
                                estimatedBytes += estimateEventBytes(event);
                            }
                        } else {
                            TargetGroupBuffer buf = openGroups.get(traceId);
                            if (buf == null) {
                                buf = new TargetGroupBuffer();
                                openGroups.put(traceId, buf);
                            }
                            if (buf.rejected) {
                                continue;
                            }
                            boolean hasId = isPresent(event.getCmp()) && isPresent(event.getUser());
                            if (hasId) {
                                if (pass1.isTargetUser(event.getCmp(), event.getUser())) {
                                    buf.target = true;
                                    buf.events.add(event);
                                    collectedEvents++;
                                    estimatedBytes += estimateEventBytes(event);
                                } else if (buf.target) {
                                    // 충돌 등으로 다른 cmp 가 와도 이미 대상 그룹이면 유지
                                    buf.events.add(event);
                                    collectedEvents++;
                                    estimatedBytes += estimateEventBytes(event);
                                } else if (buf.events.isEmpty()) {
                                    buf.rejected = true;
                                } else {
                                    // 버퍼에 빈 신원만 있다 → 비대상 확정, 폐기
                                    collectedEvents -= buf.events.size();
                                    for (LogEvent dropped : buf.events) {
                                        estimatedBytes -= estimateEventBytes(dropped);
                                    }
                                    buf.events.clear();
                                    buf.rejected = true;
                                }
                            } else if (!buf.rejected) {
                                buf.events.add(event);
                                collectedEvents++;
                                estimatedBytes += estimateEventBytes(event);
                            }
                        }

                        if (!bufferWarned && (collectedEvents >= appConfig.getPass2WarnEventCount()
                                || estimatedBytes >= appConfig.getPass2WarnBytes())) {
                            bufferWarned = true;
                            errorLogger.logError(
                                    "[WARN] Pass2 버퍼 임계치 초과(계속 진행) - 수집이벤트: "
                                            + ProgressReporter.formatLong(collectedEvents)
                                            + ", 추정바이트: " + ProgressReporter.formatLong(estimatedBytes)
                                            + ", 임계이벤트: " + appConfig.getPass2WarnEventCount()
                                            + ", 임계바이트: " + appConfig.getPass2WarnBytes(),
                                    null);
                        }
                        if (pass2Lines > 0 && pass2Lines % progress.getReportEveryLines() == 0) {
                            progress.passProgress(2, 2, i + 1, files.size(), reader.getFileName(),
                                    pass2Lines, collectedEvents, "대상 이벤트 수집");
                        }
                    }

                    List<LogEvent> forBuild = new ArrayList<>();
                    for (TargetGroupBuffer buf : openGroups.values()) {
                        if (buf.target && !buf.events.isEmpty()) {
                            forBuild.addAll(buf.events);
                        } else if (!buf.rejected && !buf.events.isEmpty()) {
                            // 끝까지 신원 없이 남은 버퍼는 대상 아님
                            collectedEvents -= buf.events.size();
                        }
                    }
                    forBuild.addAll(nullTraceKept);
                    forBuild.sort(Comparator
                            .comparing(LogEvent::getTimestamp, Comparator.nullsLast(Comparator.naturalOrder()))
                            .thenComparingLong(LogEvent::getSourceLine));
                    List<TraceGroup> groups = new TraceGroupBuilder().build(forBuild);
                    groupCount += groups.size();
                    for (TraceGroup group : groups) {
                        ContextRuleEngine.Disposition disposition = ruleEngine.apply(group);
                        if (disposition == ContextRuleEngine.Disposition.UNAUTHENTICATED) {
                            continue;
                        }
                        List<LineageRecord> records = recordFactory.toRecords(group, pairer.pair(group));
                        for (LineageRecord record : records) {
                            if (pass1.isTargetUser(record.getCompanyCode(), record.getEmployeeId())) {
                                timeline.add(record);
                            }
                        }
                    }
                    pass2Lines = fileLinesAtStart + reader.getLinesRead();
                    progress.passProgress(2, 2, i + 1, files.size(), reader.getFileName(),
                            pass2Lines, collectedEvents, "대상 이벤트 수집");
                } catch (Exception e) {
                    errorLogger.logError("Pass2 파일 처리 실패: " + file, e);
                }
            }
            progress.passComplete(2, 2, pass2Lines, collectedEvents, "대상 이벤트 수집(건)");

            // 사번 1차 → 이벤트시각 2차 (사용자별 블록, 블록 내 시간순)
            timeline.sort(Comparator
                    .comparing((LineageRecord r) -> nullToEmpty(r.getEmployeeId()))
                    .thenComparing(LineageRecord::getEventTime, Comparator.nullsLast(Comparator.naturalOrder()))
                    .thenComparing(r -> nullToEmpty(r.getCompanyCode()))
                    .thenComparing(r -> nullToEmpty(r.getTraceId()))
                    .thenComparingLong(LineageRecord::getSourceLine));

            for (LineageRecord record : timeline) {
                tsvWriter.writeTimeline(record);
                if (record.isContextInconsistent()) {
                    tsvWriter.writeInconsistent(record);
                }
            }

            long quarantineCount = quarantineWriter.getCount();
            long timelineCount = tsvWriter.getTimelineCount();
            long inconsistentCount = tsvWriter.getInconsistentCount();
            int resultPartCount = tsvWriter.getResultPartCount();
            List<String> resultFileNames = new ArrayList<>(tsvWriter.getResultFileNames());
            closeQuietly(tsvWriter, "TsvWriter", errorLogger);
            tsvWriter = null;
            closeQuietly(quarantineWriter, "QuarantineWriter", errorLogger);
            quarantineWriter = null;

            Duration elapsed = Duration.between(started, Instant.now());
            new RunSummaryWriter().write(
                    outDir,
                    runId,
                    appConfig.getOutputCharset(),
                    fileNames,
                    fileSystemLabels,
                    unidentifiedFiles.size(),
                    Math.max(pass1Lines, pass2Lines),
                    quarantineCount,
                    groupCount,
                    pass1.getTargetUsers().size(),
                    pass1.getErrorEventCount(),
                    timelineCount,
                    inconsistentCount,
                    resultPartCount,
                    errorLogger.getErrorCount(),
                    elapsed,
                    permissionHardener.getFailures(),
                    permissionHardener
            );

            if (resultFileNames.size() <= 1) {
                progress.complete(runId + "-result.tsv");
            } else {
                progress.complete(resultFileNames.get(0) + " 외 " + (resultFileNames.size() - 1)
                        + "개 분할 (" + resultFileNames.size() + " files)");
            }
            return 0;
        } catch (Exception e) {
            if (errorLogger != null) {
                errorLogger.logError("치명적 오류로 중단", e);
                System.err.println("실패: " + e.getMessage());
                System.err.println("상세 로그: " + errorLogger.getErrorFile().toAbsolutePath());
            } else {
                Path bootstrapLog = writeBootstrapErrorLog(outDir, runId, e, permissionHardener);
                System.err.println("실패: " + e.getMessage());
                if (bootstrapLog != null) {
                    System.err.println("상세 로그: " + bootstrapLog.toAbsolutePath());
                }
            }
            return 2;
        } finally {
            closeQuietly(tsvWriter, "TsvWriter", errorLogger);
            closeQuietly(quarantineWriter, "QuarantineWriter", errorLogger);
            closeQuietly(errorLogger, "ExecutionErrorLogger", null);
        }
    }

    private static LogFileReader openReader(Path file, AppConfig appConfig, LogLineParser lineParser,
                                            QuarantineWriter quarantineWriter,
                                            ExecutionErrorLogger errorLogger,
                                            String system) throws IOException {
        return new LogFileReader(
                file,
                appConfig.getLogCharset(),
                lineParser,
                quarantineWriter,
                errorLogger,
                appConfig.getMaxMessageBytes(),
                appConfig.getMaxContinuationLines(),
                appConfig.getOrphanNonHeaderWarnLines(),
                system
        );
    }

    private static boolean isPresent(String v) {
        return v != null && !v.trim().isEmpty();
    }

    private static final class TargetGroupBuffer {
        private final List<LogEvent> events = new ArrayList<>();
        private boolean target;
        private boolean rejected;
    }

    private static long estimateEventBytes(LogEvent event) {
        long n = 256;
        String msg = event.getMessage();
        if (msg != null) {
            n += msg.length() * 2L;
        }
        return n;
    }

    private static void recreateOutputDirectory(Path outDir) throws IOException {
        if (Files.exists(outDir)) {
            try (java.util.stream.Stream<Path> walk = Files.walk(outDir)) {
                List<Path> paths = new ArrayList<>();
                walk.sorted(Comparator.reverseOrder()).forEach(paths::add);
                for (Path path : paths) {
                    Files.deleteIfExists(path);
                }
            }
        }
        Files.createDirectories(outDir);
    }

    private static long resolveResultSplitBytes(AppConfig appConfig, RuntimeYamlConfig runtime,
                                                Long resultSplitMbCli) {
        if (resultSplitMbCli != null && resultSplitMbCli > 0) {
            return resultSplitMbCli * 1024L * 1024L;
        }
        if (runtime != null && runtime.getResultSplitMb() != null && runtime.getResultSplitMb() > 0) {
            return runtime.getResultSplitMb() * 1024L * 1024L;
        }
        long fromConfig = appConfig.getResultSplitMaxBytes();
        return fromConfig > 0 ? fromConfig : AppConfig.DEFAULT_RESULT_SPLIT_MAX_BYTES;
    }

    private static long resolveResultSplitBytes(AppConfig appConfig, Long resultSplitMb) {
        return resolveResultSplitBytes(appConfig, null, resultSplitMb);
    }

    private static Path writeUnidentifiedSystemsReport(Path outDir,
                                                       String runId,
                                                       Charset charset,
                                                       List<String> unidentifiedFiles,
                                                       OutputFilePermissionHardener hardener) throws Exception {
        Path report = outDir.resolve(runId + "-unidentified-systems.tsv");
        try (BufferedWriter writer = Files.newBufferedWriter(report, charset,
                StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE)) {
            writer.write("원본파일명\t시스템");
            writer.newLine();
            for (String name : unidentifiedFiles) {
                writer.write(TsvUtil.join(name, SystemId.UNIDENTIFIED));
                writer.newLine();
            }
        }
        if (hardener != null) {
            hardener.harden(report);
        }
        return report;
    }

    private static Path writeBootstrapErrorLog(Path outDir, String runId, Exception e,
                                               OutputFilePermissionHardener hardener) {
        Path logPath = outDir.resolve(runId + "-execution-error.log");
        try {
            Files.createDirectories(outDir);
            StringWriter sw = new StringWriter();
            sw.write("==== " + LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME) + " ====\n");
            sw.write("기동/초기화 오류 (errorLogger 생성 전)\n");
            e.printStackTrace(new PrintWriter(sw));
            Files.write(logPath, sw.toString().getBytes(StandardCharsets.UTF_8),
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);
            if (hardener != null) {
                hardener.harden(logPath);
            }
            return logPath;
        } catch (Exception writeFail) {
            System.err.println("오류 로그 파일 기록 실패: " + writeFail.getMessage());
            return null;
        }
    }

    private static AppConfig loadAppConfig(Path configDir) throws Exception {
        Path file = resolveConfigFile(configDir, "app.properties");
        return file != null ? AppConfig.load(file) : AppConfig.loadDefault();
    }

    private static ClassifyConfig loadClassifyConfig(Path configDir) throws Exception {
        Path file = resolveConfigFile(configDir, "classify.properties");
        return file != null ? ClassifyConfig.load(file) : ClassifyConfig.loadDefault();
    }

    private static MybatisTypeConfig loadMybatisTypeConfig(Path configDir) throws Exception {
        Path file = resolveConfigFile(configDir, "mybatis-type.properties");
        return file != null ? MybatisTypeConfig.load(file) : MybatisTypeConfig.loadDefault();
    }

    private static ErrorSignatureConfig loadErrorSignatureConfig(Path configDir) throws Exception {
        Path file = resolveConfigFile(configDir, "error-signature.properties");
        return file != null ? ErrorSignatureConfig.load(file) : ErrorSignatureConfig.loadDefault();
    }

    private static RuntimeYamlConfig loadRuntimeYamlConfig(Path configDir) {
        Path file = resolveConfigFile(configDir, RuntimeYamlConfig.FILE_NAME);
        if (file != null) {
            return RuntimeYamlConfig.loadOrDefaults(file);
        }
        // 설정 폴더에 없으면 classpath 샘플/기본 시도, 없어도 코드 기본값
        return RuntimeYamlConfig.loadClasspathOrDefaults(RuntimeYamlConfig.FILE_NAME);
    }

    private static Path resolveConfigFile(Path configDir, String name) {
        if (configDir == null) {
            return null;
        }
        if (Files.isDirectory(configDir)) {
            Path candidate = configDir.resolve(name);
            return Files.isRegularFile(candidate) ? candidate : null;
        }
        if (Files.isRegularFile(configDir)) {
            Path sibling = configDir.getParent() == null
                    ? Paths.get(name)
                    : configDir.getParent().resolve(name);
            return Files.isRegularFile(sibling) ? sibling : null;
        }
        return null;
    }

    private static String nullToEmpty(String v) {
        return v == null ? "" : v;
    }

    private static void closeQuietly(AutoCloseable closeable, String name, ExecutionErrorLogger errorLogger) {
        if (closeable == null) {
            return;
        }
        try {
            closeable.close();
        } catch (Exception e) {
            if (errorLogger != null) {
                errorLogger.logError("리소스 닫기 실패(비치명): " + name, e);
            } else {
                System.err.println("리소스 닫기 실패(비치명): " + name + " — " + e.getMessage());
            }
        }
    }
}
