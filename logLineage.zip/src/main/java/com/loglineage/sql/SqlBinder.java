package com.loglineage.sql;

import com.loglineage.config.MybatisTypeConfig;
import com.loglineage.parse.MybatisParameterParser;

import java.util.List;

/**
 * MyBatis SQL 템플릿의 ? 를 파라미터로 바인딩.
 * 작은따옴표 문자열 리터럴 안의 {@code ?} 는 치환하지 않는다.
 */
public class SqlBinder {
    private final MybatisTypeConfig typeConfig;

    public SqlBinder(MybatisTypeConfig typeConfig) {
        this.typeConfig = typeConfig;
    }

    public String bind(String sqlTemplate, List<MybatisParameterParser.Param> params) {
        if (sqlTemplate == null) {
            return "";
        }
        if (params == null || params.isEmpty()) {
            return sqlTemplate;
        }
        StringBuilder result = new StringBuilder(sqlTemplate.length() + 16);
        int paramIndex = 0;
        boolean inSingleQuote = false;
        int i = 0;
        while (i < sqlTemplate.length()) {
            char c = sqlTemplate.charAt(i);
            if (c == '\'') {
                // SQL 표준: '' 는 이스케이프된 따옴표
                if (inSingleQuote && i + 1 < sqlTemplate.length() && sqlTemplate.charAt(i + 1) == '\'') {
                    result.append('\'');
                    result.append('\'');
                    i += 2;
                    continue;
                }
                inSingleQuote = !inSingleQuote;
                result.append(c);
                i++;
                continue;
            }
            if (c == '?' && !inSingleQuote && paramIndex < params.size()) {
                result.append(formatParam(params.get(paramIndex)));
                paramIndex++;
                i++;
                continue;
            }
            result.append(c);
            i++;
        }
        return result.toString();
    }

    private String formatParam(MybatisParameterParser.Param param) {
        if (param == null || param.isNullValue()) {
            return "NULL";
        }
        String value = param.getValue() == null ? "" : param.getValue();
        if (typeConfig.requiresQuotes(param.getTypeName())) {
            return "'" + escapeSql(value) + "'";
        }
        return value;
    }

    private static String escapeSql(String value) {
        return value.replace("'", "''");
    }
}
