@echo off
setlocal
cd /d "%~dp0"
if not exist dist\loglineage.jar (
  call build.bat
)
java -jar dist\loglineage.jar %*
endlocal
