@echo off
setlocal
cd /d "%~dp0"

set CLASSES=build\classes
set TEST_OUT=build\test-classes
if not exist "%CLASSES%" (
  echo build\classes missing - run build.bat first
  exit /b 1
)
if exist "%TEST_OUT%" rmdir /s /q "%TEST_OUT%"
mkdir "%TEST_OUT%"

dir /s /b src\test\java\*.java > build\test-sources.txt
javac -encoding UTF-8 -cp "%CLASSES%" -d "%TEST_OUT%" @build\test-sources.txt
if errorlevel 1 (
  echo test compile failed
  exit /b 1
)

java -cp "%CLASSES%;%TEST_OUT%" com.loglineage.output.OutputFilePermissionHardenerTest
if errorlevel 1 (
  echo OutputFilePermissionHardenerTest failed
  exit /b 1
)

java -cp "%CLASSES%;%TEST_OUT%" com.loglineage.AppSecFixTest
set EXITCODE=%ERRORLEVEL%
endlocal & exit /b %EXITCODE%
