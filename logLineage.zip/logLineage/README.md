# LogLineage

JDK 표준 라이브러리만 사용하는 비즈니스 라인리지(Business Lineage) 추적 도구입니다.  
Maven/Gradle 등 외부 의존성 없이 `javac` / `jar` 로 빌드합니다.

## 클래스 구조 요약

상세 설계는 [DESIGN.md](DESIGN.md) 를 참고하세요.

| 패키지 | 역할 |
|--------|------|
| `com.loglineage` | CLI 진입점 (`LogLineageApp`) |
| `config` | `app` / `classify` / `mybatis-type` properties 로딩 |
| `io` | 파일 스캔, 파일별 스트리밍 리더, 타임스탬프 K-way merge |
| `parse` | 헤더 / 컨텍스트 태그 / MyBatis Parameters 파싱 |
| `model` | `LogEvent`, `TraceGroup`, `LineageRecord` 등 |
| `lineage` | 그룹화, 규칙 A/B/C, MyBatis 페어링, 이벤트 분류 |
| `sql` | SQL `?` 바인딩 |
| `output` | TSV / quarantine / run-summary / execution-error / ACL 권한 강화 |
| `util` | 시간·TSV 유틸 |

## 빌드

요구사항: JDK 8 이상 (`javac`, `jar` 명령 사용 가능)

```bat
build.bat
```

또는

```bash
chmod +x build.sh
./build.sh
```

결과물: `dist/loglineage.jar`

## 실행

```bat
java -jar dist\loglineage.jar <로그폴더경로> [설정파일경로]
```

예:

```bat
java -jar dist\loglineage.jar sample-logs config
```

출력은 `<로그폴더>/output` 아래에 생성됩니다(없으면 자동 생성).  
설정 경로를 생략하면 JAR 내장(기본) properties를 사용합니다.

## 설정 파일 (placeholder)

미확정 값은 코드에 하드코딩하지 않습니다. `config/` 또는 지정한 설정 폴더의 properties를 채우세요.

### `app.properties`

| 키 | 설명 | 기본/비고 |
|----|------|-----------|
| `log.file.extensions` | 스캔 확장자(쉼표 구분) | 예: `.log` |
| `log.charset` | 로그 인코딩 | `UTF-8` |
| `output.charset` | 출력 인코딩 | `UTF-8` |
| `event.message.max.bytes` | 이벤트 메시지 최대 UTF-8 바이트 | `1048576` (1 MiB) |
| `event.continuation.max.lines` | 이벤트당 continuation 최대 라인 | `10000` |

메시지/continuation 한도 초과 분은 quarantine하고, 헤더 메시지는 truncate 후 계속 처리합니다.

### `classify.properties` (빈 placeholder)

| 키 | 설명 |
|----|------|
| `classify.controller.logger.pattern` | CONTROLLER 판정용 logger 정규식 (비어 있으면 비활성) |
| `classify.service.logger.pattern` | SERVICE 판정용 logger 정규식 (비어 있으면 비활성) |

패턴 구문이 잘못되었거나 길이 한도(512)를 초과하면 해당 분류만 비활성화하고
`execution-error.log`에 남긴 뒤 기동을 계속합니다.

MyBatis는 Preparing/Parameters/Total 존재로 식별합니다.  
어느 분류에도 안 맞으면 `UNCLASSIFIED` (quarantine 아님).

### `mybatis-type.properties` (빈 placeholder)

| 키 | 설명 |
|----|------|
| `mybatis.type.numeric` | 인용 없이 바인딩할 타입명 목록(쉼표) |
| `mybatis.type.string` | 단일 인용으로 바인딩할 타입명 목록(쉼표) |

어느 목록에도 없으면 인용 처리합니다. `null` 값은 `NULL` 키워드로 바인딩합니다.

## 출력 파일

실행 시작 시 `yyyyMMdd-HHmmss` runId를 한 번 생성하고, 동일 접두사로 `<로그폴더>/output`에 기록합니다.

| 파일 | 내용 |
|------|------|
| `yyyyMMdd-HHmmss.tsv` | 정상 라인리지 |
| `yyyyMMdd-HHmmss-unauthenticated-or-unresolved.tsv` | 규칙 B (cmp/user 전부 없음) |
| `yyyyMMdd-HHmmss-context-inconsistent.tsv` | 규칙 C (+ `CONFLICTING_VALUES`) |
| `yyyyMMdd-HHmmss-quarantine.tsv` | 헤더 미매칭·선행 이벤트 없는 라인 |
| `yyyyMMdd-HHmmss-run-summary.log` | 실행 요약 (ACL 권한 강화 실패 시 사유 포함) |
| `yyyyMMdd-HHmmss-execution-error.log` | IO/인코딩 등 오류 스택 |

출력 산출물은 생성 직후 Windows ACL로 **현재 실행 계정 읽기/쓰기**만 허용하도록 강화합니다.
POSIX `0600` / `setPosixFilePermissions`는 사용하지 않습니다. 권한 강화가 실패해도 배치는 계속되며,
`run-summary.log`에 `출력 파일 접근 권한 강화 실패: <사유>`가 남습니다.

## 테스트

```bat
build.bat
test.bat
```

JUnit/Maven 없이 JDK `javac` + `java`로 ACL·TSV 이스케이프·Parameters 파서·classify 가드·한도 동작을 검증합니다.

## 처리 흐름

1. 확장자 필터로 로그 폴더 스캔  
2. 파일별 `BufferedReader` 스트리밍 (`LogFileReader`)  
3. 타임스탬프 오름차순 K-way merge (물리 병합 없음)  
4. 헤더/컨텍스트 파싱, quarantine 분기  
5. `traceId` 그룹화 → 규칙 A/B/C  
6. MyBatis 3줄 페어링 → SQL_TEMPLATE / SQL_EXECUTABLE  
7. 그룹 최초 시각 정렬 → SEQ → TSV 출력  
