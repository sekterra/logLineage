@echo off
setlocal
cd /d "%~dp0"

set OUT=build\classes
set DIST=dist
if exist "%OUT%" rmdir /s /q "%OUT%"
if exist "%DIST%" rmdir /s /q "%DIST%"
mkdir "%OUT%"
mkdir "%DIST%"

dir /s /b src\main\java\*.java > build\sources.txt
javac -encoding UTF-8 -d "%OUT%" @build\sources.txt
if errorlevel 1 (
  echo compile failed
  exit /b 1
)

xcopy /y /q src\main\resources\* "%OUT%\" >nul
jar cfm "%DIST%\loglineage.jar" manifest.mf -C "%OUT%" .
echo Built %DIST%\loglineage.jar
endlocal
