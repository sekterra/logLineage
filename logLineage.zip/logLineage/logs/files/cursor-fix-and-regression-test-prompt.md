# LogLineage 헤더 파싱 정정 및 회귀 검증 프롬프트

> Cursor AI에게 그대로 전달하는 프롬프트입니다. 프로젝트 전체 소스코드를
> 컨텍스트에 포함한 상태에서 사용하세요. 첨부 파일(web-1.log, web-2.log,
> mobile-1.log, mobile-2.log)을 테스트 입력 폴더에 넣고 함께 사용합니다.

---

## 배경 (원인 확정됨)

실행 결과 산출물(lineage.tsv)이 완전히 비어있는 문제를 분석한 결과, 원인은
로직 버그가 아니라 **헤더 정규식이 실제 로그 포맷과 애초에 일치하지 않았던
것**으로 확정되었습니다. 기존 정규식은 11개 테스트 라인 중 0건 매칭, 아래
정정된 정규식은 동일 조건에서 정상 매칭됨을 별도 검증(Python re 모듈 기반
독립 검증)으로 이미 확인했습니다.

## 실제 로그 헤더 포맷 (확정)

```
TIMESTAMP LEVEL [trace:TRACE_ID] [cmp: COMPANY_COD] [user: EMP_NO] [uri: REQUEST_URI] [THREAD] LOGGER - MESSAGE
```

기존 스펙 문서와의 핵심 차이:
1. trace/cmp/user/uri 태그는 메시지(%msg) 내부가 아니라 **헤더 자체**에 위치
2. LEVEL이 THREAD보다 먼저 옴 (기존 가정과 순서 반대)
3. THREAD는 `{thread}`가 아니라 `[THREAD]` — 대괄호
4. `[cmp: 값]`처럼 콜론 뒤 공백이 있는 태그가 존재하며, 값이 비어 있는
   `[cmp: ]` 형태도 정상 케이스임

## 지시 사항

### 1. `LogLineParser` (또는 동등 클래스) 헤더 정규식 교체

```regex
^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3})\s+(\S+)\s+\[trace:\s*([^\]]*)\]\s*\[cmp:\s*([^\]]*)\]\s*\[user:\s*([^\]]*)\]\s*\[uri:\s*([^\]]*)\]\s*\[([^\]]*)\]\s+(\S+)\s+-\s(.*)$
```
그룹: 1=timestamp, 2=level, 3=trace, 4=cmp, 5=user, 6=uri, 7=thread, 8=logger, 9=message

### 2. `UserContextExtractor` 역할 통합

trace/cmp/user/uri는 더 이상 메시지 내부를 별도 정규식으로 재검색할 필요가
없습니다. 헤더 파싱 단계에서 함께 추출되므로, `UserContextExtractor`는
제거하거나 헤더 파서 내부 로직으로 흡수하세요. `LogEvent`(또는 동등 모델)에
`traceId`, `compCode`, `empNo`, `uri` 필드를 직접 추가하고, 파싱 직후
즉시 채우도록 구현하세요.

### 3. 값이 빈 태그 처리

`[cmp: ]`, `[user: ]`처럼 태그는 존재하나 값이 비어있는 라인은 정상
데이터입니다. 예외로 처리하지 말고 빈 문자열/null로 저장한 뒤, 기존에
합의된 규칙을 그대로 적용하세요.
- 규칙 A(Backfill): 같은 traceId 그룹 내 일부 라인만 값이 있으면 보완
- 규칙 B: 그룹 전체가 결측이면 `unauthenticated-or-unresolved.tsv`로 분리
- 규칙 C: 같은 traceId 내 값이 서로 다르면 `context-inconsistent.tsv`로 분리

### 4. 회귀 테스트 (반드시 수행)

1. 첨부된 `web-1.log`, `web-2.log`, `mobile-1.log`, `mobile-2.log` 4개
   파일을 테스트 입력 폴더에 배치
2. 프로그램 실행 후 아래를 확인:
   - `quarantine.tsv`에 남는 라인이 스택트레이스 연속 라인 3건과 헤더 자체가
     깨진 라인 1건, 총 4건 내외인지 (그 이상이면 정규식이 여전히 일부
     케이스를 놓치고 있다는 뜻이므로 원인 재분석 필요)
   - `lineage.tsv`에 traceId 기준으로 약 28개 그룹이 생성되는지
   - `context-inconsistent.tsv`에 회사코드가 중간에 바뀌는 traceId(1건)가
     정확히 잡히는지
   - `unauthenticated-or-unresolved.tsv` 혹은 backfill 처리로, cmp/user가
     일부만 비어있는 traceId(1건)가 나머지 값으로 정상 보완되는지
   - MyBatis 3줄(Preparing/Parameters/Total)이 SQL_TEMPLATE, SQL_EXECUTABLE로
     정상 조합되는지, 그리고 Total 라인이 누락된 케이스(샘플에 포함됨)에서
     프로그램이 죽지 않고 SQL_TEMPLATE/EXECUTABLE만 채운 채 넘어가는지
   - health check 라인(cmp/user가 완전히 빈 단독 이벤트)이 규칙 B에 따라
     메인 산출물에서 제외되고 보조 산출물에 남는지

### 5. 완료 후 보고 형식

수정 완료 후, 위 6개 확인 항목 각각에 대해 실제 결과값(건수 등)을 표로
정리해서 보고할 것. 기대치와 다른 항목이 있으면 원인 후보를 함께 제시할 것
(추측 금지 — 실제 코드 동작 근거를 댈 것).
