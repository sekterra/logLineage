#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

OUT=build/classes
DIST=dist
rm -rf "$OUT" "$DIST"
mkdir -p "$OUT" "$DIST" build

find src/main/java -name '*.java' > build/sources.txt
javac -encoding UTF-8 -d "$OUT" @build/sources.txt
cp -f src/main/resources/* "$OUT/" 2>/dev/null || true
jar cfm "$DIST/loglineage.jar" manifest.mf -C "$OUT" .
echo "Built $DIST/loglineage.jar"
