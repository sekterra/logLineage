package com.loglineage.sql;

import com.loglineage.config.MybatisTypeConfig;
import com.loglineage.parse.MybatisParameterParser;

import java.util.List;

/**
 * MyBatis SQL 템플릿의 ? 를 파라미터로 바인딩.
 */
public class SqlBinder {
    private final MybatisTypeConfig typeConfig;

    public SqlBinder(MybatisTypeConfig typeConfig) {
        this.typeConfig = typeConfig;
    }

    public String bind(String sqlTemplate, List<MybatisParameterParser.Param> params) {
        if (sqlTemplate == null) {
            return "";
        }
        if (params == null || params.isEmpty()) {
            return sqlTemplate;
        }
        StringBuilder result = new StringBuilder();
        int paramIndex = 0;
        int i = 0;
        while (i < sqlTemplate.length()) {
            char c = sqlTemplate.charAt(i);
            if (c == '?' && paramIndex < params.size()) {
                result.append(formatParam(params.get(paramIndex)));
                paramIndex++;
                i++;
            } else {
                result.append(c);
                i++;
            }
        }
        return result.toString();
    }

    private String formatParam(MybatisParameterParser.Param param) {
        if (param == null || param.isNullValue()) {
            return "NULL";
        }
        String value = param.getValue() == null ? "" : param.getValue();
        if (typeConfig.requiresQuotes(param.getTypeName())) {
            return "'" + escapeSql(value) + "'";
        }
        return value;
    }

    private static String escapeSql(String value) {
        return value.replace("'", "''");
    }
}
