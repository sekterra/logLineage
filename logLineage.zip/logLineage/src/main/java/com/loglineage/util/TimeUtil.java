package com.loglineage.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

/**
 * 로그 타임스탬프 유틸.
 */
public final class TimeUtil {
    public static final DateTimeFormatter LOG_TIMESTAMP =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

    private TimeUtil() {
    }

    public static LocalDateTime parse(String text) {
        if (text == null) {
            return null;
        }
        try {
            return LocalDateTime.parse(text, LOG_TIMESTAMP);
        } catch (DateTimeParseException e) {
            return null;
        }
    }

    public static String format(LocalDateTime time) {
        if (time == null) {
            return "";
        }
        return LOG_TIMESTAMP.format(time);
    }
}
