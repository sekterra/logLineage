package com.loglineage.util;

/**
 * TSV 필드 이스케이프 유틸.
 */
public final class TsvUtil {
    private TsvUtil() {
    }

    public static String nullToEmpty(String value) {
        return value == null ? "" : value;
    }

    /**
     * 탭/개행/캐리지리턴을 공백으로 치환하여 TSV 한 셀로 안전하게 출력하고,
     * 선두 {@code =}+{@code -}/{@code @} 는 수식 인젝션 방지를 위해 {@code '} 를 접두한다.
     */
    public static String escape(String value) {
        if (value == null || value.isEmpty()) {
            return "";
        }
        StringBuilder sb = new StringBuilder(value.length() + 1);
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            switch (c) {
                case '\t':
                case '\n':
                case '\r':
                    sb.append(' ');
                    break;
                default:
                    sb.append(c);
            }
        }
        if (sb.length() > 0) {
            char first = sb.charAt(0);
            if (first == '=' || first == '+' || first == '-' || first == '@') {
                sb.insert(0, '\'');
            }
        }
        return sb.toString();
    }

    public static String join(String... fields) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < fields.length; i++) {
            if (i > 0) {
                sb.append('\t');
            }
            sb.append(escape(fields[i]));
        }
        return sb.toString();
    }
}
