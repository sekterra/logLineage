package com.loglineage.io;

import com.loglineage.config.AppConfig;
import com.loglineage.output.ExecutionErrorLogger;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * 로그 폴더에서 확장자 필터로 파일을 스캔한다. 파일 개수는 하드코딩하지 않음.
 */
public class LogFileScanner {
    private final AppConfig appConfig;
    private final ExecutionErrorLogger errorLogger;

    public LogFileScanner(AppConfig appConfig, ExecutionErrorLogger errorLogger) {
        this.appConfig = appConfig;
        this.errorLogger = errorLogger;
    }

    public List<Path> scan(Path logFolder) {
        List<Path> files = new ArrayList<>();
        if (logFolder == null || !Files.isDirectory(logFolder)) {
            return files;
        }
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(logFolder)) {
            for (Path path : stream) {
                try {
                    if (!Files.isRegularFile(path)) {
                        continue;
                    }
                    String name = path.getFileName().toString().toLowerCase(Locale.ROOT);
                    for (String ext : appConfig.getLogFileExtensions()) {
                        if (name.endsWith(ext.toLowerCase(Locale.ROOT))) {
                            files.add(path);
                            break;
                        }
                    }
                } catch (Exception e) {
                    errorLogger.logError("파일 스캔 중 오류: " + path, e);
                }
            }
        } catch (IOException e) {
            errorLogger.logError("로그 폴더 스캔 실패: " + logFolder, e);
        }
        files.sort(Comparator.comparing(p -> p.getFileName().toString()));
        return Collections.unmodifiableList(files);
    }
}
