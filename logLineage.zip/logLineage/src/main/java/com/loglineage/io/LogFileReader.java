package com.loglineage.io;

import com.loglineage.model.LogEvent;
import com.loglineage.output.ExecutionErrorLogger;
import com.loglineage.output.QuarantineWriter;
import com.loglineage.parse.LogLineParser;

import java.io.BufferedReader;
import java.io.Closeable;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;

/**
 * 단일 로그 파일 스트리밍 리더.
 * 전체 파일을 메모리에 올리지 않고 BufferedReader로 한 줄씩 처리.
 * 이벤트 메시지 바이트/continuation 라인 상한을 적용해 초과분은 quarantine한다.
 */
public class LogFileReader implements Closeable {
    private final Path file;
    private final String fileName;
    private final String systemId;
    private final BufferedReader reader;
    private final LogLineParser lineParser;
    private final QuarantineWriter quarantineWriter;
    private final ExecutionErrorLogger errorLogger;
    private final int maxMessageBytes;
    private final int maxContinuationLines;

    private LogEvent pending;
    private long lineNumber;
    private long linesRead;
    private boolean finished;
    private boolean closed;

    public LogFileReader(Path file,
                         Charset charset,
                         LogLineParser lineParser,
                         QuarantineWriter quarantineWriter,
                         ExecutionErrorLogger errorLogger) throws IOException {
        this(file, charset, lineParser, quarantineWriter, errorLogger,
                Integer.MAX_VALUE, Integer.MAX_VALUE, null);
    }

    public LogFileReader(Path file,
                         Charset charset,
                         LogLineParser lineParser,
                         QuarantineWriter quarantineWriter,
                         ExecutionErrorLogger errorLogger,
                         int maxMessageBytes,
                         int maxContinuationLines) throws IOException {
        this(file, charset, lineParser, quarantineWriter, errorLogger,
                maxMessageBytes, maxContinuationLines, null);
    }

    public LogFileReader(Path file,
                         Charset charset,
                         LogLineParser lineParser,
                         QuarantineWriter quarantineWriter,
                         ExecutionErrorLogger errorLogger,
                         int maxMessageBytes,
                         int maxContinuationLines,
                         String systemId) throws IOException {
        this.file = file;
        this.fileName = file.getFileName().toString();
        this.systemId = systemId == null || systemId.trim().isEmpty()
                ? com.loglineage.config.SystemId.UNIDENTIFIED
                : systemId;
        this.reader = Files.newBufferedReader(file, charset);
        this.lineParser = lineParser;
        this.quarantineWriter = quarantineWriter;
        this.errorLogger = errorLogger;
        this.maxMessageBytes = maxMessageBytes <= 0 ? Integer.MAX_VALUE : maxMessageBytes;
        this.maxContinuationLines = maxContinuationLines <= 0 ? Integer.MAX_VALUE : maxContinuationLines;
    }

    public Path getFile() {
        return file;
    }

    public String getFileName() {
        return fileName;
    }

    public String getSystemId() {
        return systemId;
    }

    public long getLinesRead() {
        return linesRead;
    }

    /**
     * 다음 완성 이벤트를 반환. 파일 끝이면 empty.
     */
    public Optional<LogEvent> readNext() {
        if (finished) {
            return Optional.empty();
        }
        try {
            String line;
            while ((line = reader.readLine()) != null) {
                lineNumber++;
                linesRead++;
                LogEvent header = lineParser.parseHeader(line);
                if (header != null) {
                    header.setSourceFile(fileName);
                    header.setSourceLine(lineNumber);
                    header.setSystemId(systemId);
                    applyMessageBound(header);
                    if (pending != null) {
                        LogEvent emit = pending;
                        pending = header;
                        return Optional.of(emit);
                    }
                    pending = header;
                } else {
                    if (pending != null) {
                        boolean alreadyTruncated = pending.isMessageTruncated();
                        if (pending.tryAppendContinuation(line, maxMessageBytes, maxContinuationLines)) {
                            lineParser.detectMybatisFlags(pending);
                        } else {
                            quarantineExcess(line, !alreadyTruncated);
                        }
                    } else {
                        try {
                            quarantineWriter.write(fileName, lineNumber, line);
                        } catch (IOException qe) {
                            errorLogger.logError("quarantine 기록 실패: " + fileName + ":" + lineNumber, qe);
                        }
                    }
                }
            }
            finished = true;
            if (pending != null) {
                LogEvent emit = pending;
                pending = null;
                return Optional.of(emit);
            }
            return Optional.empty();
        } catch (IOException e) {
            finished = true;
            errorLogger.logError("로그 파일 읽기 오류: " + file, e);
            if (pending != null) {
                LogEvent emit = pending;
                pending = null;
                return Optional.of(emit);
            }
            return Optional.empty();
        }
    }

    private void applyMessageBound(LogEvent header) {
        String raw = header.getMessage();
        if (header.setMessageBounded(raw, maxMessageBytes)) {
            errorLogger.logError(
                    "이벤트 헤더 메시지 한도 초과 truncate: " + fileName + ":" + lineNumber
                            + " (maxBytes=" + maxMessageBytes + ")",
                    null);
            try {
                quarantineWriter.write(fileName, lineNumber,
                        "[TRUNCATED_HEADER_MESSAGE] originalBytesExceeded");
            } catch (IOException qe) {
                errorLogger.logError("quarantine 기록 실패: " + fileName + ":" + lineNumber, qe);
            }
            lineParser.detectMybatisFlags(header);
        }
    }

    private void quarantineExcess(String line, boolean logLimitOnce) {
        if (logLimitOnce) {
            errorLogger.logError(
                    "이벤트 continuation 한도 초과 quarantine: " + fileName + ":" + lineNumber
                            + " (maxBytes=" + maxMessageBytes
                            + ", maxLines=" + maxContinuationLines + ")",
                    null);
        }
        try {
            quarantineWriter.write(fileName, lineNumber, line);
        } catch (IOException qe) {
            errorLogger.logError("quarantine 기록 실패: " + fileName + ":" + lineNumber, qe);
        }
    }

    @Override
    public void close() {
        if (closed) {
            return;
        }
        closed = true;
        try {
            reader.close();
        } catch (IOException e) {
            errorLogger.logError("로그 파일 닫기 오류: " + file, e);
        }
    }
}
