package com.loglineage.io;

import com.loglineage.model.LogEvent;

import java.io.Closeable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.PriorityQueue;

/**
 * 여러 LogFileReader를 타임스탬프 오름차순으로 K-way merge.
 * 파일을 물리적으로 합치지 않는다.
 */
public class KWayMergeReader implements Closeable, Iterable<LogEvent> {
    private static final Comparator<Head> HEAD_COMPARATOR = (a, b) -> {
        LocalDateTime ta = a.event.getTimestamp();
        LocalDateTime tb = b.event.getTimestamp();
        if (ta == null && tb == null) {
            int byFile = a.reader.getFileName().compareTo(b.reader.getFileName());
            if (byFile != 0) {
                return byFile;
            }
            return Long.compare(a.event.getSourceLine(), b.event.getSourceLine());
        }
        if (ta == null) {
            return 1;
        }
        if (tb == null) {
            return -1;
        }
        int cmp = ta.compareTo(tb);
        if (cmp != 0) {
            return cmp;
        }
        int byFile = a.reader.getFileName().compareTo(b.reader.getFileName());
        if (byFile != 0) {
            return byFile;
        }
        return Long.compare(a.event.getSourceLine(), b.event.getSourceLine());
    };

    private final List<LogFileReader> readers;
    private final PriorityQueue<Head> queue;

    public KWayMergeReader(List<LogFileReader> readers) {
        this.readers = new ArrayList<>(readers);
        this.queue = new PriorityQueue<>(Math.max(1, readers.size()), HEAD_COMPARATOR);
        for (LogFileReader reader : this.readers) {
            Optional<LogEvent> next = reader.readNext();
            next.ifPresent(event -> queue.offer(new Head(reader, event)));
        }
    }

    public Optional<LogEvent> readNext() {
        Head head = queue.poll();
        if (head == null) {
            return Optional.empty();
        }
        Optional<LogEvent> next = head.reader.readNext();
        next.ifPresent(event -> queue.offer(new Head(head.reader, event)));
        return Optional.of(head.event);
    }

    public long getTotalLinesRead() {
        long total = 0;
        for (LogFileReader reader : readers) {
            total += reader.getLinesRead();
        }
        return total;
    }

    @Override
    public Iterator<LogEvent> iterator() {
        return new Iterator<LogEvent>() {
            private LogEvent next = KWayMergeReader.this.readNext().orElse(null);

            @Override
            public boolean hasNext() {
                return next != null;
            }

            @Override
            public LogEvent next() {
                LogEvent current = next;
                next = KWayMergeReader.this.readNext().orElse(null);
                return current;
            }
        };
    }

    @Override
    public void close() {
        for (LogFileReader reader : readers) {
            reader.close();
        }
    }

    private static final class Head {
        private final LogFileReader reader;
        private final LogEvent event;

        private Head(LogFileReader reader, LogEvent event) {
            this.reader = reader;
            this.event = event;
        }
    }
}
