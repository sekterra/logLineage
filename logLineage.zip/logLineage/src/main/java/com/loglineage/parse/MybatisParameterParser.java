package com.loglineage.parse;

import java.util.ArrayList;
import java.util.List;

/**
 * MyBatis Parameters 라인 파서.
 * 단순 콤마 분할이 아닌 value(Type) 패턴을 선형 스캔으로 파싱한다 (ReDoS 회피).
 */
public class MybatisParameterParser {

    public static class Param {
        private final String value;
        private final String typeName;

        public Param(String value, String typeName) {
            this.value = value;
            this.typeName = typeName;
        }

        public String getValue() {
            return value;
        }

        public String getTypeName() {
            return typeName;
        }

        public boolean isNullValue() {
            return value != null && "null".equalsIgnoreCase(value.trim());
        }
    }

    /**
     * "Parameters: a(Integer), b(String)" 형태 메시지에서 파라미터 목록 추출.
     * 값 내부 콤마는 허용하며, 각 파라미터는 마지막 {@code (Type)} 세그먼트로 구분한다.
     */
    public List<Param> parse(String message) {
        List<Param> params = new ArrayList<>();
        if (message == null) {
            return params;
        }
        String payload = message;
        int idx = message.indexOf("Parameters:");
        if (idx >= 0) {
            payload = message.substring(idx + "Parameters:".length()).trim();
        }
        if (payload.isEmpty()) {
            return params;
        }

        int start = 0;
        int n = payload.length();
        while (start < n) {
            int open = -1;
            int close = -1;
            int nextStart = -1;

            for (int i = start; i < n; i++) {
                if (payload.charAt(i) != '(') {
                    continue;
                }
                int typeStart = i + 1;
                int j = typeStart;
                while (j < n && isTypeChar(payload.charAt(j))) {
                    j++;
                }
                if (j == typeStart || j >= n || payload.charAt(j) != ')') {
                    continue;
                }
                int after = j + 1;
                if (after == n) {
                    open = i;
                    close = j;
                    nextStart = n;
                    break;
                }
                if (payload.charAt(after) == ',') {
                    after++;
                    while (after < n && Character.isWhitespace(payload.charAt(after))) {
                        after++;
                    }
                    open = i;
                    close = j;
                    nextStart = after;
                    break;
                }
            }

            if (open < 0) {
                break;
            }

            String value = payload.substring(start, open).trim();
            if (value.startsWith(",")) {
                value = value.substring(1).trim();
            }
            String type = payload.substring(open + 1, close);
            params.add(new Param(value, type));
            start = nextStart;
        }
        return params;
    }

    private static boolean isTypeChar(char c) {
        return Character.isLetterOrDigit(c) || c == '_' || c == '.' || c == '$';
    }
}
