package com.loglineage.parse;

import com.loglineage.model.LogEvent;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 컨텍스트 태그 파서.
 * 매칭 실패 시 trace 관련 필드는 null (정상).
 */
public class ContextTagParser {
    public static final Pattern CONTEXT_PATTERN = Pattern.compile(
            "\\[trace:([^\\]]*)\\]\\[cmp:([^\\]]*)\\]\\[user:([^\\]]*)\\]\\[uri:([^\\]]*)\\]"
    );

    public void apply(LogEvent event) {
        if (event == null || event.getMessage() == null) {
            return;
        }
        Matcher m = CONTEXT_PATTERN.matcher(event.getMessage());
        if (!m.find()) {
            event.setTraceId(null);
            event.setCmp(null);
            event.setUser(null);
            event.setUri(null);
            return;
        }
        event.setTraceId(emptyToNull(m.group(1)));
        event.setCmp(emptyToNull(m.group(2)));
        event.setUser(emptyToNull(m.group(3)));
        event.setUri(emptyToNull(m.group(4)));
    }

    private static String emptyToNull(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }
}
