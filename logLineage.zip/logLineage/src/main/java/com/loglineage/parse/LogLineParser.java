package com.loglineage.parse;

import com.loglineage.model.LogEvent;
import com.loglineage.util.TimeUtil;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 로그 헤더 라인 파서.
 * 헤더에서 timestamp/level/trace/cmp/user/uri/thread/logger/message 를 함께 추출한다.
 */
public class LogLineParser {
    public static final Pattern HEADER_PATTERN = Pattern.compile(
            "^(\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}\\.\\d{3})\\s+(\\S+)\\s+"
                    + "\\[trace:\\s*([^\\]]*)\\]\\s*"
                    + "\\[cmp:\\s*([^\\]]*)\\]\\s*"
                    + "\\[user:\\s*([^\\]]*)\\]\\s*"
                    + "\\[uri:\\s*([^\\]]*)\\]\\s*"
                    + "\\[([^\\]]*)\\]\\s+(\\S+)\\s+-\\s(.*)$"
    );

    public LogEvent parseHeader(String line) {
        if (line == null) {
            return null;
        }
        Matcher m = HEADER_PATTERN.matcher(line);
        if (!m.matches()) {
            return null;
        }
        LogEvent event = new LogEvent();
        event.setTimestamp(TimeUtil.parse(m.group(1)));
        event.setLevel(m.group(2) == null ? null : m.group(2).trim());
        event.setTraceId(emptyToNull(m.group(3)));
        event.setCmp(emptyToNull(m.group(4)));
        event.setUser(emptyToNull(m.group(5)));
        event.setUri(emptyToNull(m.group(6)));
        event.setThread(m.group(7));
        event.setLogger(m.group(8));
        event.setMessage(m.group(9) == null ? "" : m.group(9));
        detectMybatisFlags(event);
        return event;
    }

    public void detectMybatisFlags(LogEvent event) {
        String msg = event.getMessage();
        if (msg == null) {
            return;
        }
        if (containsToken(msg, "Preparing:")) {
            event.setMybatisPreparing(true);
        }
        if (containsToken(msg, "Parameters:")) {
            event.setMybatisParameters(true);
        }
        if (containsToken(msg, "Total:")) {
            event.setMybatisTotal(true);
        }
    }

    private static boolean containsToken(String message, String token) {
        return message.contains(token);
    }

    /**
     * 태그는 존재하나 값이 비어 있는 경우(예: {@code [cmp: ]})는 null 로 정규화한다.
     */
    private static String emptyToNull(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }
}
