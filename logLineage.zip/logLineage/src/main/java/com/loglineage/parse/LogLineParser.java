package com.loglineage.parse;

import com.loglineage.model.LogEvent;
import com.loglineage.util.TimeUtil;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 로그 헤더 라인 파서.
 * 헤더 정규식은 스펙 고정값 사용.
 */
public class LogLineParser {
    public static final Pattern HEADER_PATTERN = Pattern.compile(
            "^(\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}\\.\\d{3})\\s+\\{([^}]*)\\}\\s+(\\S+)\\s+(\\S+)\\s+-\\s(.*)$"
    );

    public LogEvent parseHeader(String line) {
        if (line == null) {
            return null;
        }
        Matcher m = HEADER_PATTERN.matcher(line);
        if (!m.matches()) {
            return null;
        }
        LogEvent event = new LogEvent();
        event.setTimestamp(TimeUtil.parse(m.group(1)));
        event.setThread(m.group(2));
        event.setLevel(m.group(3) == null ? null : m.group(3).trim());
        event.setLogger(m.group(4));
        event.setMessage(m.group(5) == null ? "" : m.group(5));
        detectMybatisFlags(event);
        return event;
    }

    public void detectMybatisFlags(LogEvent event) {
        String msg = event.getMessage();
        if (msg == null) {
            return;
        }
        if (containsToken(msg, "Preparing:")) {
            event.setMybatisPreparing(true);
        }
        if (containsToken(msg, "Parameters:")) {
            event.setMybatisParameters(true);
        }
        if (containsToken(msg, "Total:")) {
            event.setMybatisTotal(true);
        }
    }

    private static boolean containsToken(String message, String token) {
        return message.contains(token);
    }
}
