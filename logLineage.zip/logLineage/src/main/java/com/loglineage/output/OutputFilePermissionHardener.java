package com.loglineage.output;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.attribute.AclEntry;
import java.nio.file.attribute.AclEntryPermission;
import java.nio.file.attribute.AclEntryType;
import java.nio.file.attribute.AclFileAttributeView;
import java.nio.file.attribute.UserPrincipal;
import java.nio.file.attribute.UserPrincipalLookupService;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Windows ACL로 출력 파일을 현재 실행 계정 읽기/쓰기만 허용하도록 강화한다.
 * {@code Files.setPosixFilePermissions}는 Windows에서 지원되지 않으므로 사용하지 않는다.
 * 실패 시 예외를 밖으로 던지지 않고 메시지를 수집하며, 호출부는 배치를 계속한다.
 */
public class OutputFilePermissionHardener {
    public static final String FAILURE_PREFIX = "출력 파일 접근 권한 강화 실패: ";

    private static final Set<String> GROUP_LIKE_NAMES = Collections.unmodifiableSet(new HashSet<String>(Arrays.asList(
            "everyone",
            "users",
            "authenticated users",
            "interactive",
            "builtin\\users",
            "nt authority\\authenticated users",
            "nt authority\\interactive"
    )));

    private final List<String> failures = new ArrayList<String>();

    /**
     * 대상 파일 ACL을 현재 실행 계정 전용 읽기/쓰기로 재구성한다.
     * 상속·기본 그룹(Users, Everyone 등) 권한 제거를 시도한다.
     * 실패해도 예외를 밖으로 던지지 않고 {@link #getFailures()}에 기록한다.
     */
    public void harden(Path path) {
        if (path == null) {
            recordFailure("path가 null");
            return;
        }
        try {
            AclFileAttributeView view = Files.getFileAttributeView(
                    path, AclFileAttributeView.class, LinkOption.NOFOLLOW_LINKS);
            if (view == null) {
                recordFailure(path, "AclFileAttributeView를 사용할 수 없음");
                return;
            }
            applyOwnerOnlyAcl(path, view);
        } catch (Exception e) {
            recordFailure(path, reasonOf(e));
        }
    }

    /**
     * ACL을 현재 사용자 ALLOW(읽기/쓰기 및 필수 속성)만 남기도록 설정한다.
     * 기존 ACL의 Everyone/Users 등 그룹형 엔트리를 명시적으로 제외한 뒤 setAcl로 교체한다.
     */
    void applyOwnerOnlyAcl(Path path, AclFileAttributeView view) throws IOException {
        UserPrincipal currentUser = resolveCurrentUser(path, view);

        // 상속·기본 그룹 ACE를 명시적으로 식별·제외 (Users, Everyone 등)
        List<AclEntry> existing = view.getAcl();
        for (AclEntry entry : existing) {
            if (isGroupLikePrincipal(entry.principal())) {
                // 교체 ACL에 포함하지 않음
                continue;
            }
        }

        AclEntry ownerAllow = AclEntry.newBuilder()
                .setType(AclEntryType.ALLOW)
                .setPrincipal(currentUser)
                .setPermissions(ownerReadWritePermissions())
                .build();
        view.setAcl(Collections.singletonList(ownerAllow));
    }

    private static UserPrincipal resolveCurrentUser(Path path, AclFileAttributeView view) throws IOException {
        try {
            UserPrincipalLookupService lookup = path.getFileSystem().getUserPrincipalLookupService();
            String userName = System.getProperty("user.name");
            if (userName != null && !userName.trim().isEmpty()) {
                return lookup.lookupPrincipalByName(userName);
            }
        } catch (Exception ignored) {
            // fall through to file owner
        }
        UserPrincipal owner = view.getOwner();
        if (owner == null) {
            throw new IOException("현재 실행 계정을 확인할 수 없음");
        }
        return owner;
    }

    private static EnumSet<AclEntryPermission> ownerReadWritePermissions() {
        return EnumSet.of(
                AclEntryPermission.READ_DATA,
                AclEntryPermission.WRITE_DATA,
                AclEntryPermission.APPEND_DATA,
                AclEntryPermission.READ_ATTRIBUTES,
                AclEntryPermission.WRITE_ATTRIBUTES,
                AclEntryPermission.READ_NAMED_ATTRS,
                AclEntryPermission.WRITE_NAMED_ATTRS,
                AclEntryPermission.READ_ACL,
                AclEntryPermission.DELETE,
                AclEntryPermission.SYNCHRONIZE
        );
    }

    static boolean isGroupLikePrincipal(UserPrincipal principal) {
        if (principal == null) {
            return false;
        }
        String name = principal.getName();
        if (name == null) {
            return false;
        }
        String normalized = name.toLowerCase(Locale.ROOT).trim();
        if (GROUP_LIKE_NAMES.contains(normalized)) {
            return true;
        }
        int slash = Math.max(normalized.lastIndexOf('\\'), normalized.lastIndexOf('/'));
        String leaf = slash >= 0 ? normalized.substring(slash + 1) : normalized;
        return GROUP_LIKE_NAMES.contains(leaf);
    }

    private void recordFailure(Path path, String reason) {
        String file = path.getFileName() == null ? path.toString() : path.getFileName().toString();
        recordFailure(file + " — " + reason);
    }

    private void recordFailure(String reason) {
        failures.add(FAILURE_PREFIX + reason);
    }

    /** 테스트/강제 실패 기록용. */
    void recordFailureMessage(String reason) {
        recordFailure(reason);
    }

    static String reasonOf(Throwable t) {
        if (t == null) {
            return "unknown";
        }
        String msg = t.getMessage();
        if (msg != null && !msg.trim().isEmpty()) {
            return t.getClass().getSimpleName() + ": " + msg;
        }
        return t.getClass().getSimpleName();
    }

    /** run-summary 등에 기록할 실패 메시지(누적). */
    public List<String> getFailures() {
        return Collections.unmodifiableList(failures);
    }

    public boolean hasFailures() {
        return !failures.isEmpty();
    }

    /** 테스트용: 실패 목록 초기. */
    void clearFailures() {
        failures.clear();
    }
}
