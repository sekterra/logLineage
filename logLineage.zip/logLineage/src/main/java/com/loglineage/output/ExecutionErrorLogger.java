package com.loglineage.output;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * IO/인코딩 오류를 {runId}-execution-error.log에 기록. 부분 실패만 하고 계속 진행.
 */
public class ExecutionErrorLogger implements AutoCloseable {
    private final Path errorFile;
    private final Charset charset;
    private PrintWriter writer;
    private int errorCount;

    public ExecutionErrorLogger(Path outputDir, String runId, Charset charset,
                                OutputFilePermissionHardener permissionHardener) throws IOException {
        Files.createDirectories(outputDir);
        this.errorFile = outputDir.resolve(runId + "-execution-error.log");
        this.charset = charset;
        this.writer = new PrintWriter(Files.newBufferedWriter(errorFile, charset,
                StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE), true);
        OutputFilePermissionHardener hardener = permissionHardener == null
                ? new OutputFilePermissionHardener()
                : permissionHardener;
        hardener.harden(errorFile);
    }

    public Path getErrorFile() {
        return errorFile;
    }

    public synchronized void logError(String message, Throwable t) {
        errorCount++;
        if (writer == null) {
            return;
        }
        writer.println("==== " + LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME) + " ====");
        writer.println(message);
        if (t != null) {
            StringWriter sw = new StringWriter();
            t.printStackTrace(new PrintWriter(sw));
            writer.println(sw);
        }
        writer.println();
        writer.flush();
    }

    public int getErrorCount() {
        return errorCount;
    }

    @Override
    public void close() {
        if (writer != null) {
            writer.close();
            writer = null;
        }
    }
}
