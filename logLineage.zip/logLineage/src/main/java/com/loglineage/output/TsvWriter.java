package com.loglineage.output;

import com.loglineage.model.LineageRecord;
import com.loglineage.util.TimeUtil;
import com.loglineage.util.TsvUtil;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

/**
 * lineage / unresolved / inconsistent TSV 작성기.
 */
public class TsvWriter implements AutoCloseable {
    public static final String LINEAGE_HEADER =
            "SEQ\tTRACE_ID\t회사코드\t사번\t이벤트시각\tEVENT_TYPE\tTHREAD\tLOGGER\tURI\tURI_SOURCE\tSQL_TEMPLATE\tSQL_EXECUTABLE\t원본파일명\t원본라인번호";

    public static final String INCONSISTENT_HEADER = LINEAGE_HEADER + "\tCONFLICTING_VALUES";

    private final OutputFilePermissionHardener permissionHardener;
    private final BufferedWriter lineageWriter;
    private final BufferedWriter unresolvedWriter;
    private final BufferedWriter inconsistentWriter;
    private long lineageCount;
    private long unresolvedCount;
    private long inconsistentCount;

    public TsvWriter(Path outputDir, String runId, Charset charset,
                     OutputFilePermissionHardener permissionHardener) throws IOException {
        Files.createDirectories(outputDir);
        this.permissionHardener = permissionHardener == null
                ? new OutputFilePermissionHardener()
                : permissionHardener;
        this.lineageWriter = open(outputDir.resolve(runId + ".tsv"), charset, LINEAGE_HEADER);
        this.unresolvedWriter = open(outputDir.resolve(runId + "-unauthenticated-or-unresolved.tsv"), charset, LINEAGE_HEADER);
        this.inconsistentWriter = open(outputDir.resolve(runId + "-context-inconsistent.tsv"), charset, INCONSISTENT_HEADER);
    }

    private BufferedWriter open(Path path, Charset charset, String header) throws IOException {
        BufferedWriter writer = Files.newBufferedWriter(path, charset,
                StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);
        permissionHardener.harden(path);
        writer.write(header);
        writer.newLine();
        return writer;
    }

    public void writeMain(LineageRecord record) throws IOException {
        writeLine(lineageWriter, record, false);
        lineageCount++;
    }

    public void writeUnresolved(LineageRecord record) throws IOException {
        writeLine(unresolvedWriter, record, false);
        unresolvedCount++;
    }

    public void writeInconsistent(LineageRecord record) throws IOException {
        writeLine(inconsistentWriter, record, true);
        inconsistentCount++;
    }

    private void writeLine(BufferedWriter writer, LineageRecord record, boolean withConflict) throws IOException {
        String base = TsvUtil.join(
                Long.toString(record.getSeq()),
                TsvUtil.nullToEmpty(record.getTraceId()),
                TsvUtil.nullToEmpty(record.getCompanyCode()),
                TsvUtil.nullToEmpty(record.getEmployeeId()),
                TimeUtil.format(record.getEventTime()),
                record.getEventType() == null ? "" : record.getEventType().name(),
                TsvUtil.nullToEmpty(record.getThread()),
                TsvUtil.nullToEmpty(record.getLogger()),
                TsvUtil.nullToEmpty(record.getUri()),
                TsvUtil.nullToEmpty(record.getUriSource()),
                TsvUtil.nullToEmpty(record.getSqlTemplate()),
                TsvUtil.nullToEmpty(record.getSqlExecutable()),
                TsvUtil.nullToEmpty(record.getSourceFile()),
                Long.toString(record.getSourceLine())
        );
        if (withConflict) {
            writer.write(base);
            writer.write('\t');
            writer.write(TsvUtil.escape(TsvUtil.nullToEmpty(record.getConflictingValues())));
        } else {
            writer.write(base);
        }
        writer.newLine();
    }

    public long getLineageCount() {
        return lineageCount;
    }

    public long getUnresolvedCount() {
        return unresolvedCount;
    }

    public long getInconsistentCount() {
        return inconsistentCount;
    }

    @Override
    public void close() throws IOException {
        IOException first = null;
        first = closeOne(lineageWriter, first);
        first = closeOne(unresolvedWriter, first);
        first = closeOne(inconsistentWriter, first);
        if (first != null) {
            throw first;
        }
    }

    private static IOException closeOne(BufferedWriter writer, IOException first) {
        if (writer == null) {
            return first;
        }
        try {
            writer.close();
        } catch (IOException e) {
            if (first == null) {
                return e;
            }
            first.addSuppressed(e);
        }
        return first;
    }
}
