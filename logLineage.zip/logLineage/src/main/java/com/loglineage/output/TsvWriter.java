package com.loglineage.output;

import com.loglineage.model.LineageRecord;
import com.loglineage.util.TimeUtil;
import com.loglineage.util.TsvUtil;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

/**
 * RCA 결과 / context-inconsistent TSV 작성기.
 * 메인 파일명: {runId}-result.tsv (runId = yyyy-MM-dd-HHmmss)
 */
public class TsvWriter implements AutoCloseable {
    /** 한글 헤더. EVENT_TYPE / SQL_TEMPLATE 제외. */
    public static final String RESULT_HEADER =
            "시스템\t회사코드\t사번\t이벤트시각\t에러여부\t트레이스ID\t레벨\tURI\t로거\t"
                    + "실행SQL\t메시지\t원본파일명\t원본라인번호\t컨텍스트불일치";

    public static final String INCONSISTENT_HEADER = RESULT_HEADER + "\t충돌값";

    private final OutputFilePermissionHardener permissionHardener;
    private final BufferedWriter timelineWriter;
    private final BufferedWriter inconsistentWriter;
    private long timelineCount;
    private long inconsistentCount;

    public TsvWriter(Path outputDir, String runId, Charset charset,
                     OutputFilePermissionHardener permissionHardener) throws IOException {
        Files.createDirectories(outputDir);
        this.permissionHardener = permissionHardener == null
                ? new OutputFilePermissionHardener()
                : permissionHardener;
        this.timelineWriter = open(outputDir.resolve(runId + "-result.tsv"), charset, RESULT_HEADER);
        this.inconsistentWriter = open(outputDir.resolve(runId + "-context-inconsistent.tsv"), charset, INCONSISTENT_HEADER);
    }

    private BufferedWriter open(Path path, Charset charset, String header) throws IOException {
        BufferedWriter writer = Files.newBufferedWriter(path, charset,
                StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);
        permissionHardener.harden(path);
        writer.write(header);
        writer.newLine();
        return writer;
    }

    public void writeTimeline(LineageRecord record) throws IOException {
        writeLine(timelineWriter, record, false);
        timelineCount++;
    }

    public void writeInconsistent(LineageRecord record) throws IOException {
        writeLine(inconsistentWriter, record, true);
        inconsistentCount++;
    }

    private void writeLine(BufferedWriter writer, LineageRecord record, boolean withConflict) throws IOException {
        String base = TsvUtil.join(
                TsvUtil.nullToEmpty(record.getSystemId()),
                TsvUtil.nullToEmpty(record.getCompanyCode()),
                TsvUtil.nullToEmpty(record.getEmployeeId()),
                TimeUtil.format(record.getEventTime()),
                record.isErrorEvent() ? "Y" : "N",
                TsvUtil.nullToEmpty(record.getTraceId()),
                TsvUtil.nullToEmpty(record.getLevel()),
                TsvUtil.nullToEmpty(record.getUri()),
                TsvUtil.nullToEmpty(record.getLogger()),
                TsvUtil.nullToEmpty(record.getSqlExecutable()),
                TsvUtil.nullToEmpty(record.getMessage()),
                TsvUtil.nullToEmpty(record.getSourceFile()),
                Long.toString(record.getSourceLine()),
                record.isContextInconsistent() ? "Y" : "N"
        );
        if (withConflict) {
            writer.write(base);
            writer.write('\t');
            writer.write(TsvUtil.escape(TsvUtil.nullToEmpty(record.getConflictingValues())));
        } else {
            writer.write(base);
        }
        writer.newLine();
    }

    public long getTimelineCount() {
        return timelineCount;
    }

    public long getInconsistentCount() {
        return inconsistentCount;
    }

    @Override
    public void close() throws IOException {
        IOException first = null;
        first = closeOne(timelineWriter, first);
        first = closeOne(inconsistentWriter, first);
        if (first != null) {
            throw first;
        }
    }

    private static IOException closeOne(BufferedWriter writer, IOException first) {
        if (writer == null) {
            return first;
        }
        try {
            writer.close();
        } catch (IOException e) {
            if (first == null) {
                return e;
            }
            first.addSuppressed(e);
        }
        return first;
    }
}
