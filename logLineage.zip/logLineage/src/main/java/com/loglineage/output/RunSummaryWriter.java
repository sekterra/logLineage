package com.loglineage.output;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.List;

/**
 * {runId}-run-summary.log 작성기.
 */
public class RunSummaryWriter {
    public void write(Path outputDir,
                      String runId,
                      Charset charset,
                      List<String> inputFiles,
                      long lineCount,
                      long quarantineCount,
                      long groupCount,
                      long mainGroupCount,
                      long unauthenticatedGroupCount,
                      long inconsistentGroupCount,
                      long lineageRecords,
                      long unresolvedRecords,
                      long inconsistentRecords,
                      int executionErrors,
                      Duration elapsed,
                      List<String> permissionHardeningFailures,
                      OutputFilePermissionHardener permissionHardener) throws IOException {
        Files.createDirectories(outputDir);
        Path file = outputDir.resolve(runId + "-run-summary.log");
        List<String> failures = permissionHardeningFailures == null
                ? Collections.<String>emptyList()
                : permissionHardeningFailures;
        try (BufferedWriter writer = Files.newBufferedWriter(file, charset,
                StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE)) {
            writer.write("LogLineage Run Summary");
            writer.newLine();
            writer.write("runId: " + runId);
            writer.newLine();
            writer.write("생성시각: " + LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
            writer.newLine();
            writer.write("입력파일수: " + inputFiles.size());
            writer.newLine();
            writer.write("입력파일목록:");
            writer.newLine();
            for (String name : inputFiles) {
                writer.write("  - " + name);
                writer.newLine();
            }
            writer.write("총라인수: " + lineCount);
            writer.newLine();
            writer.write("quarantine건수: " + quarantineCount);
            writer.newLine();
            writer.write("trace그룹수: " + groupCount);
            writer.newLine();
            writer.write("메인그룹수: " + mainGroupCount);
            writer.newLine();
            writer.write("미인증/미해석그룹수(B): " + unauthenticatedGroupCount);
            writer.newLine();
            writer.write("컨텍스트충돌그룹수(C): " + inconsistentGroupCount);
            writer.newLine();
            writer.write(runId + ".tsv레코드수: " + lineageRecords);
            writer.newLine();
            writer.write(runId + "-unauthenticated-or-unresolved.tsv레코드수: " + unresolvedRecords);
            writer.newLine();
            writer.write(runId + "-context-inconsistent.tsv레코드수: " + inconsistentRecords);
            writer.newLine();
            writer.write("실행오류수: " + executionErrors);
            writer.newLine();
            writer.write("소요시간(ms): " + elapsed.toMillis());
            writer.newLine();
            for (String failure : failures) {
                writer.write(failure);
                writer.newLine();
            }
        }

        OutputFilePermissionHardener hardener = permissionHardener == null
                ? new OutputFilePermissionHardener()
                : permissionHardener;
        int before = hardener.getFailures().size();
        hardener.harden(file);
        List<String> all = hardener.getFailures();
        if (all.size() > before) {
            // 요약 파일 자체 권한 강화 실패도 동일 형식으로 파일에 남긴다
            try (BufferedWriter appender = Files.newBufferedWriter(file, charset,
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND, StandardOpenOption.WRITE)) {
                for (int i = before; i < all.size(); i++) {
                    appender.write(all.get(i));
                    appender.newLine();
                }
            }
        }
    }
}
