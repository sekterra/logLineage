package com.loglineage.config;

import java.io.IOException;
import java.nio.file.Path;
import java.util.Collections;
import java.util.HashSet;
import java.util.Locale;
import java.util.Properties;
import java.util.Set;

/**
 * mybatis-type.properties 로더.
 * 타입 목록은 외부화되며 코드에 하드코딩하지 않는다.
 */
public class MybatisTypeConfig {
    private final Set<String> numericTypes;
    private final Set<String> stringTypes;

    public MybatisTypeConfig(Set<String> numericTypes, Set<String> stringTypes) {
        this.numericTypes = Collections.unmodifiableSet(new HashSet<>(numericTypes));
        this.stringTypes = Collections.unmodifiableSet(new HashSet<>(stringTypes));
    }

    public static MybatisTypeConfig load(Path propertiesFile) throws IOException {
        return fromProperties(AppConfig.loadProperties(propertiesFile));
    }

    public static MybatisTypeConfig loadDefault() throws IOException {
        return fromProperties(AppConfig.loadClasspathOrEmpty("mybatis-type.properties"));
    }

    private static MybatisTypeConfig fromProperties(Properties props) {
        return new MybatisTypeConfig(
                parseTypeSet(props.getProperty("mybatis.type.numeric", "")),
                parseTypeSet(props.getProperty("mybatis.type.string", ""))
        );
    }

    private static Set<String> parseTypeSet(String raw) {
        Set<String> set = new HashSet<>();
        if (raw == null || raw.trim().isEmpty()) {
            return set;
        }
        for (String part : raw.split(",")) {
            String t = part.trim();
            if (!t.isEmpty()) {
                set.add(normalizeType(t));
            }
        }
        return set;
    }

    private static String normalizeType(String typeName) {
        String simple = typeName;
        int dot = typeName.lastIndexOf('.');
        if (dot >= 0 && dot < typeName.length() - 1) {
            simple = typeName.substring(dot + 1);
        }
        return simple.toLowerCase(Locale.ROOT);
    }

    /**
     * numeric 목록에 있으면 인용 없음, 그 외(string 목록 포함·미등록)는 인용.
     */
    public boolean requiresQuotes(String typeName) {
        if (typeName == null || typeName.trim().isEmpty()) {
            return true;
        }
        String normalized = normalizeType(typeName);
        if (numericTypes.contains(normalized)) {
            return false;
        }
        return true;
    }

    public Set<String> getNumericTypes() {
        return numericTypes;
    }

    public Set<String> getStringTypes() {
        return stringTypes;
    }
}
