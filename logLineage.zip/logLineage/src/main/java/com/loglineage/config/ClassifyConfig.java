package com.loglineage.config;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/**
 * classify.properties 로더.
 * 패턴이 비어 있거나 컴파일 실패 시 해당 분류는 비활성.
 */
public class ClassifyConfig {
    /** 분류 패턴 문자열 최대 길이 (복잡도 가드). */
    public static final int MAX_PATTERN_LENGTH = 512;

    private final Pattern controllerPattern;
    private final Pattern servicePattern;
    private final List<String> loadWarnings;

    public ClassifyConfig(Pattern controllerPattern, Pattern servicePattern) {
        this(controllerPattern, servicePattern, Collections.<String>emptyList());
    }

    public ClassifyConfig(Pattern controllerPattern, Pattern servicePattern, List<String> loadWarnings) {
        this.controllerPattern = controllerPattern;
        this.servicePattern = servicePattern;
        this.loadWarnings = Collections.unmodifiableList(new ArrayList<>(
                loadWarnings == null ? Collections.<String>emptyList() : loadWarnings));
    }

    public static ClassifyConfig load(Path propertiesFile) throws IOException {
        Properties props = AppConfig.loadProperties(propertiesFile);
        return fromProperties(props);
    }

    public static ClassifyConfig loadDefault() throws IOException {
        return fromProperties(AppConfig.loadClasspathOrEmpty("classify.properties"));
    }

    private static ClassifyConfig fromProperties(Properties props) {
        List<String> warnings = new ArrayList<>();
        Pattern controller = compileOrNull(
                props.getProperty("classify.controller.logger.pattern", ""),
                "classify.controller.logger.pattern",
                warnings);
        Pattern service = compileOrNull(
                props.getProperty("classify.service.logger.pattern", ""),
                "classify.service.logger.pattern",
                warnings);
        return new ClassifyConfig(controller, service, warnings);
    }

    private static Pattern compileOrNull(String raw, String key, List<String> warnings) {
        if (raw == null) {
            return null;
        }
        String trimmed = raw.trim();
        if (trimmed.isEmpty()) {
            return null;
        }
        if (trimmed.length() > MAX_PATTERN_LENGTH) {
            warnings.add("classify 패턴 길이 초과로 비활성: " + key
                    + " (max=" + MAX_PATTERN_LENGTH + ", actual=" + trimmed.length() + ")");
            return null;
        }
        try {
            return Pattern.compile(trimmed);
        } catch (PatternSyntaxException e) {
            warnings.add("classify 패턴 구문 오류로 비활성: " + key + " — " + e.getDescription());
            return null;
        }
    }

    public List<String> getLoadWarnings() {
        return loadWarnings;
    }

    public boolean matchesController(String logger) {
        return matches(controllerPattern, logger);
    }

    public boolean matchesService(String logger) {
        return matches(servicePattern, logger);
    }

    private static boolean matches(Pattern pattern, String value) {
        if (pattern == null || value == null) {
            return false;
        }
        return pattern.matcher(value).find();
    }
}
