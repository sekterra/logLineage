package com.loglineage.config;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;

/**
 * app.properties 로더.
 */
public class AppConfig {
    /** 이벤트 메시지 최대 UTF-8 바이트 기본값 (1 MiB). */
    public static final int DEFAULT_MAX_MESSAGE_BYTES = 1_048_576;
    /** 이벤트당 continuation 라인 수 기본값. */
    public static final int DEFAULT_MAX_CONTINUATION_LINES = 10_000;

    private final List<String> logFileExtensions;
    private final Charset logCharset;
    private final Charset outputCharset;
    private final int maxMessageBytes;
    private final int maxContinuationLines;
    private final String systemWebFilenameContains;
    private final String systemMobileFilenameContains;
    private final String systemMwebFilenameContains;
    private final String systemLoginFilenameContains;

    public AppConfig(List<String> logFileExtensions, Charset logCharset, Charset outputCharset,
                     int maxMessageBytes, int maxContinuationLines) {
        this(logFileExtensions, logCharset, outputCharset, maxMessageBytes, maxContinuationLines,
                "tsms-web", "tsms-mobile", "tsms-mweb", "tsms-login");
    }

    public AppConfig(List<String> logFileExtensions, Charset logCharset, Charset outputCharset,
                     int maxMessageBytes, int maxContinuationLines,
                     String systemWebFilenameContains, String systemMobileFilenameContains) {
        this(logFileExtensions, logCharset, outputCharset, maxMessageBytes, maxContinuationLines,
                systemWebFilenameContains, systemMobileFilenameContains, "tsms-mweb", "tsms-login");
    }

    public AppConfig(List<String> logFileExtensions, Charset logCharset, Charset outputCharset,
                     int maxMessageBytes, int maxContinuationLines,
                     String systemWebFilenameContains, String systemMobileFilenameContains,
                     String systemMwebFilenameContains, String systemLoginFilenameContains) {
        this.logFileExtensions = Collections.unmodifiableList(new ArrayList<>(logFileExtensions));
        this.logCharset = logCharset;
        this.outputCharset = outputCharset;
        this.maxMessageBytes = maxMessageBytes;
        this.maxContinuationLines = maxContinuationLines;
        this.systemWebFilenameContains = systemWebFilenameContains;
        this.systemMobileFilenameContains = systemMobileFilenameContains;
        this.systemMwebFilenameContains = systemMwebFilenameContains;
        this.systemLoginFilenameContains = systemLoginFilenameContains;
    }

    public static AppConfig load(Path propertiesFile) throws IOException {
        Properties props = loadProperties(propertiesFile);
        return fromProperties(props);
    }

    public static AppConfig loadDefault() throws IOException {
        Properties props = loadClasspathOrEmpty("app.properties");
        return fromProperties(props);
    }

    private static AppConfig fromProperties(Properties props) {
        String extRaw = props.getProperty("log.file.extensions", ".log");
        List<String> extensions = new ArrayList<>();
        for (String part : extRaw.split(",")) {
            String trimmed = part.trim();
            if (!trimmed.isEmpty()) {
                if (!trimmed.startsWith(".")) {
                    trimmed = "." + trimmed;
                }
                extensions.add(trimmed.toLowerCase());
            }
        }
        if (extensions.isEmpty()) {
            extensions.add(".log");
        }

        Charset logCharset = charsetOrUtf8(props.getProperty("log.charset", "UTF-8"));
        Charset outputCharset = charsetOrUtf8(props.getProperty("output.charset", "UTF-8"));
        int maxMessageBytes = positiveIntOrDefault(
                props.getProperty("event.message.max.bytes"), DEFAULT_MAX_MESSAGE_BYTES);
        int maxContinuationLines = positiveIntOrDefault(
                props.getProperty("event.continuation.max.lines"), DEFAULT_MAX_CONTINUATION_LINES);
        String webToken = props.getProperty("system.web.filename.contains", "tsms-web");
        String mobileToken = props.getProperty("system.mobile.filename.contains", "tsms-mobile");
        String mwebToken = props.getProperty("system.mweb.filename.contains", "tsms-mweb");
        String loginToken = props.getProperty("system.login.filename.contains", "tsms-login");
        return new AppConfig(extensions, logCharset, outputCharset, maxMessageBytes, maxContinuationLines,
                webToken, mobileToken, mwebToken, loginToken);
    }

    private static int positiveIntOrDefault(String raw, int defaultValue) {
        if (raw == null) {
            return defaultValue;
        }
        String trimmed = raw.trim();
        if (trimmed.isEmpty()) {
            return defaultValue;
        }
        try {
            int value = Integer.parseInt(trimmed);
            return value > 0 ? value : defaultValue;
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    private static Charset charsetOrUtf8(String name) {
        try {
            return Charset.forName(name.trim());
        } catch (Exception e) {
            return StandardCharsets.UTF_8;
        }
    }

    static Properties loadProperties(Path path) throws IOException {
        Properties props = new Properties();
        if (path != null && Files.isRegularFile(path)) {
            try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
                props.load(reader);
            }
        }
        return props;
    }

    static Properties loadClasspathOrEmpty(String resourceName) throws IOException {
        Properties props = new Properties();
        try (InputStream in = AppConfig.class.getClassLoader().getResourceAsStream(resourceName)) {
            if (in != null) {
                props.load(in);
            }
        }
        return props;
    }

    public List<String> getLogFileExtensions() {
        return logFileExtensions;
    }

    public Charset getLogCharset() {
        return logCharset;
    }

    public Charset getOutputCharset() {
        return outputCharset;
    }

    public int getMaxMessageBytes() {
        return maxMessageBytes;
    }

    public int getMaxContinuationLines() {
        return maxContinuationLines;
    }

    public String getSystemWebFilenameContains() {
        return systemWebFilenameContains;
    }

    public String getSystemMobileFilenameContains() {
        return systemMobileFilenameContains;
    }

    public String getSystemMwebFilenameContains() {
        return systemMwebFilenameContains;
    }

    public String getSystemLoginFilenameContains() {
        return systemLoginFilenameContains;
    }
}
