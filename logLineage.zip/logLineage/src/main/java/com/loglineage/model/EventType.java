package com.loglineage.model;

/**
 * 이벤트 분류 타입. MyBatis는 Preparing/Parameters/Total 존재로 식별.
 */
public enum EventType {
    CONTROLLER,
    SERVICE,
    MYBATIS,
    UNCLASSIFIED
}
