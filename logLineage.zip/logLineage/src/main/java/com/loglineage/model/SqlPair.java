package com.loglineage.model;

/**
 * MyBatis Preparing + Parameters 바인딩 결과.
 */
public class SqlPair {
    private final String sqlTemplate;
    private final String sqlExecutable;

    public SqlPair(String sqlTemplate, String sqlExecutable) {
        this.sqlTemplate = sqlTemplate;
        this.sqlExecutable = sqlExecutable;
    }

    public String getSqlTemplate() {
        return sqlTemplate;
    }

    public String getSqlExecutable() {
        return sqlExecutable;
    }
}
