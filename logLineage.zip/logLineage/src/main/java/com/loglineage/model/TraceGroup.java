package com.loglineage.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * 동일 traceId 이벤트를 시간 순서대로 보관.
 */
public class TraceGroup {
    private final String traceId;
    private final List<LogEvent> events = new ArrayList<>();
    private String resolvedCmp;
    private String resolvedUser;
    private boolean conflicting;
    private String conflictingValues;

    public TraceGroup(String traceId) {
        this.traceId = traceId;
    }

    public String getTraceId() {
        return traceId;
    }

    public List<LogEvent> getEvents() {
        return events;
    }

    public void addEvent(LogEvent event) {
        events.add(event);
    }

    public LocalDateTime getFirstEventTime() {
        if (events.isEmpty()) {
            return null;
        }
        return events.get(0).getTimestamp();
    }

    public String getResolvedCmp() {
        return resolvedCmp;
    }

    public void setResolvedCmp(String resolvedCmp) {
        this.resolvedCmp = resolvedCmp;
    }

    public String getResolvedUser() {
        return resolvedUser;
    }

    public void setResolvedUser(String resolvedUser) {
        this.resolvedUser = resolvedUser;
    }

    public boolean isConflicting() {
        return conflicting;
    }

    public void setConflicting(boolean conflicting) {
        this.conflicting = conflicting;
    }

    public String getConflictingValues() {
        return conflictingValues;
    }

    public void setConflictingValues(String conflictingValues) {
        this.conflictingValues = conflictingValues;
    }
}
