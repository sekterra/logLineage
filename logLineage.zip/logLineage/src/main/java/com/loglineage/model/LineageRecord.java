package com.loglineage.model;

import java.time.LocalDateTime;

/**
 * TSV 출력용 라인리지 레코드.
 */
public class LineageRecord {
    private long seq;
    private String traceId;
    private String companyCode;
    private String employeeId;
    private LocalDateTime eventTime;
    private EventType eventType;
    private String thread;
    private String logger;
    private String uri;
    private String uriSource;
    private String sqlTemplate;
    private String sqlExecutable;
    private String sourceFile;
    private long sourceLine;
    private String conflictingValues;

    public long getSeq() {
        return seq;
    }

    public void setSeq(long seq) {
        this.seq = seq;
    }

    public String getTraceId() {
        return traceId;
    }

    public void setTraceId(String traceId) {
        this.traceId = traceId;
    }

    public String getCompanyCode() {
        return companyCode;
    }

    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public LocalDateTime getEventTime() {
        return eventTime;
    }

    public void setEventTime(LocalDateTime eventTime) {
        this.eventTime = eventTime;
    }

    public EventType getEventType() {
        return eventType;
    }

    public void setEventType(EventType eventType) {
        this.eventType = eventType;
    }

    public String getThread() {
        return thread;
    }

    public void setThread(String thread) {
        this.thread = thread;
    }

    public String getLogger() {
        return logger;
    }

    public void setLogger(String logger) {
        this.logger = logger;
    }

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public String getUriSource() {
        return uriSource;
    }

    public void setUriSource(String uriSource) {
        this.uriSource = uriSource;
    }

    public String getSqlTemplate() {
        return sqlTemplate;
    }

    public void setSqlTemplate(String sqlTemplate) {
        this.sqlTemplate = sqlTemplate;
    }

    public String getSqlExecutable() {
        return sqlExecutable;
    }

    public void setSqlExecutable(String sqlExecutable) {
        this.sqlExecutable = sqlExecutable;
    }

    public String getSourceFile() {
        return sourceFile;
    }

    public void setSourceFile(String sourceFile) {
        this.sourceFile = sourceFile;
    }

    public long getSourceLine() {
        return sourceLine;
    }

    public void setSourceLine(long sourceLine) {
        this.sourceLine = sourceLine;
    }

    public String getConflictingValues() {
        return conflictingValues;
    }

    public void setConflictingValues(String conflictingValues) {
        this.conflictingValues = conflictingValues;
    }
}
