package com.loglineage;

import com.loglineage.config.AppConfig;
import com.loglineage.config.ClassifyConfig;
import com.loglineage.config.ErrorSignatureConfig;
import com.loglineage.config.MybatisTypeConfig;
import com.loglineage.config.SystemClassifier;
import com.loglineage.config.SystemId;
import com.loglineage.io.KWayMergeReader;
import com.loglineage.io.LogFileReader;
import com.loglineage.io.LogFileScanner;
import com.loglineage.lineage.ContextRuleEngine;
import com.loglineage.lineage.ErrorEventDetector;
import com.loglineage.lineage.EventClassifier;
import com.loglineage.lineage.LineageRecordFactory;
import com.loglineage.lineage.MybatisPairer;
import com.loglineage.lineage.ThreadTracePropagator;
import com.loglineage.lineage.TraceGroupBuilder;
import com.loglineage.model.LineageRecord;
import com.loglineage.model.LogEvent;
import com.loglineage.model.TraceGroup;
import com.loglineage.output.ExecutionErrorLogger;
import com.loglineage.output.OutputFilePermissionHardener;
import com.loglineage.output.QuarantineWriter;
import com.loglineage.output.RunSummaryWriter;
import com.loglineage.output.TsvWriter;
import com.loglineage.parse.LogLineParser;
import com.loglineage.parse.MybatisParameterParser;
import com.loglineage.sql.SqlBinder;
import com.loglineage.util.TsvUtil;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

/**
 * 에러 사용자 중심 RCA 타임라인 CLI 진입점.
 * <pre>
 * java -jar loglineage.jar &lt;로그폴더경로&gt; [설정파일경로]
 * </pre>
 * 출력은 {@code <로그폴더>/output} 아래에 기록한다.
 * 실행 시 기존 output 폴더를 삭제한 뒤 새로 만들고,
 * 실행 시각({@code yyyy-MM-dd-HHmmss}) 접두사로 산출물을 남긴다.
 */
public final class LogLineageApp {
    private static final DateTimeFormatter RUN_ID_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd-HHmmss");

    private LogLineageApp() {
    }

    public static void main(String[] args) {
        if (args.length < 1) {
            printUsage();
            System.exit(1);
            return;
        }

        Path logDir = Paths.get(args[0]);
        Path configDir = args.length >= 2 ? Paths.get(args[1]) : null;

        int code = new LogLineageApp().run(logDir, configDir);
        System.exit(code);
    }

    private static void printUsage() {
        System.err.println("사용법: java -jar loglineage.jar <로그폴더경로> [설정파일경로]");
        System.err.println("출력은 <로그폴더>/output 에 생성됩니다.");
        System.err.println("설정 경로에는 app.properties, classify.properties,");
        System.err.println("mybatis-type.properties, error-signature.properties 를 둡니다.");
    }

    int run(Path logDir, Path configDir) {
        Instant started = Instant.now();
        String runId = LocalDateTime.now().format(RUN_ID_FORMAT);
        Path outDir = logDir.resolve("output");
        ExecutionErrorLogger errorLogger = null;
        QuarantineWriter quarantineWriter = null;
        TsvWriter tsvWriter = null;
        KWayMergeReader mergeReader = null;
        OutputFilePermissionHardener permissionHardener = new OutputFilePermissionHardener();

        try {
            recreateOutputDirectory(outDir);

            AppConfig appConfig = loadAppConfig(configDir);
            ClassifyConfig classifyConfig = loadClassifyConfig(configDir);
            MybatisTypeConfig typeConfig = loadMybatisTypeConfig(configDir);
            ErrorSignatureConfig signatureConfig = loadErrorSignatureConfig(configDir);

            errorLogger = new ExecutionErrorLogger(outDir, runId, appConfig.getOutputCharset(), permissionHardener);
            for (String warning : classifyConfig.getLoadWarnings()) {
                errorLogger.logError(warning, null);
            }
            for (String warning : signatureConfig.getLoadWarnings()) {
                errorLogger.logError(warning, null);
            }

            quarantineWriter = new QuarantineWriter(outDir, runId, appConfig.getOutputCharset(), permissionHardener);
            tsvWriter = new TsvWriter(outDir, runId, appConfig.getOutputCharset(), permissionHardener);

            LogFileScanner scanner = new LogFileScanner(appConfig, errorLogger);
            List<Path> files = scanner.scan(logDir);
            SystemClassifier systemClassifier = SystemClassifier.fromAppConfig(appConfig);

            LogLineParser lineParser = new LogLineParser();
            List<LogFileReader> readers = new ArrayList<>();
            List<String> fileSystemLabels = new ArrayList<>();
            List<String> unidentifiedFiles = new ArrayList<>();
            for (Path file : files) {
                try {
                    String system = systemClassifier.classify(file.getFileName().toString());
                    fileSystemLabels.add(file.getFileName() + " => " + system);
                    if (SystemId.UNIDENTIFIED.equals(system)) {
                        unidentifiedFiles.add(file.getFileName().toString());
                    }
                    readers.add(new LogFileReader(
                            file,
                            appConfig.getLogCharset(),
                            lineParser,
                            quarantineWriter,
                            errorLogger,
                            appConfig.getMaxMessageBytes(),
                            appConfig.getMaxContinuationLines(),
                            system
                    ));
                } catch (Exception e) {
                    errorLogger.logError("로그 파일 열기 실패: " + file, e);
                }
            }
            if (!unidentifiedFiles.isEmpty()) {
                writeUnidentifiedSystemsReport(outDir, runId, appConfig.getOutputCharset(),
                        unidentifiedFiles, permissionHardener);
            }

            mergeReader = new KWayMergeReader(readers);

            ThreadTracePropagator propagator = new ThreadTracePropagator();
            TraceGroupBuilder groupBuilder = new TraceGroupBuilder();
            List<LogEvent> orderedEvents = new ArrayList<>();
            for (LogEvent event : mergeReader) {
                propagator.apply(event);
                orderedEvents.add(event);
            }
            long lineCount = mergeReader.getTotalLinesRead();
            closeQuietly(mergeReader, "KWayMergeReader", errorLogger);
            mergeReader = null;

            // 1~2) traceId 그룹 내 cmp/user backfill (및 충돌 표시)
            List<TraceGroup> groups = groupBuilder.build(orderedEvents);
            orderedEvents.clear();

            ContextRuleEngine ruleEngine = new ContextRuleEngine();
            ErrorEventDetector errorDetector = new ErrorEventDetector(signatureConfig);
            MybatisPairer pairer = new MybatisPairer(new MybatisParameterParser(), new SqlBinder(typeConfig));
            LineageRecordFactory recordFactory = new LineageRecordFactory(new EventClassifier(classifyConfig));

            Set<UserKey> targetUsers = new HashSet<>();
            long errorEventCount = 0;
            List<LineageRecord> allRecords = new ArrayList<>();

            for (TraceGroup group : groups) {
                ContextRuleEngine.Disposition disposition = ruleEngine.apply(group);

                // 3) IS_ERROR_EVENT 부여
                for (LogEvent event : group.getEvents()) {
                    errorDetector.apply(event);
                    if (event.isErrorEvent()) {
                        errorEventCount++;
                        UserKey key = userKeyOf(event, group);
                        if (key != null) {
                            targetUsers.add(key);
                        }
                    }
                }

                // 미인증(신원 없음) 그룹은 타임라인 대상이 될 수 없음
                if (disposition == ContextRuleEngine.Disposition.UNAUTHENTICATED) {
                    continue;
                }

                MybatisPairer.PairingResult pairing = pairer.pair(group);
                allRecords.addAll(recordFactory.toRecords(group, pairing));
            }

            // 4~6) 에러 보유 (cmp,user)만 남기고 사번→시각 정렬
            List<LineageRecord> timeline = new ArrayList<>();
            for (LineageRecord record : allRecords) {
                UserKey key = userKeyOf(record.getCompanyCode(), record.getEmployeeId());
                if (key == null || !targetUsers.contains(key)) {
                    continue;
                }
                timeline.add(record);
            }
            timeline.sort(Comparator
                    .comparing((LineageRecord r) -> nullToEmpty(r.getEmployeeId()))
                    .thenComparing(r -> r.getEventTime(), Comparator.nullsLast(Comparator.naturalOrder()))
                    .thenComparing(r -> nullToEmpty(r.getCompanyCode()))
                    .thenComparing(r -> nullToEmpty(r.getTraceId()))
                    .thenComparingLong(LineageRecord::getSourceLine));

            for (LineageRecord record : timeline) {
                tsvWriter.writeTimeline(record);
                if (record.isContextInconsistent()) {
                    tsvWriter.writeInconsistent(record);
                }
            }

            long quarantineCount = quarantineWriter.getCount();
            long timelineCount = tsvWriter.getTimelineCount();
            long inconsistentCount = tsvWriter.getInconsistentCount();
            closeQuietly(tsvWriter, "TsvWriter", errorLogger);
            tsvWriter = null;
            closeQuietly(quarantineWriter, "QuarantineWriter", errorLogger);
            quarantineWriter = null;

            List<String> fileNames = new ArrayList<>();
            for (Path f : files) {
                fileNames.add(f.getFileName().toString());
            }

            Duration elapsed = Duration.between(started, Instant.now());
            new RunSummaryWriter().write(
                    outDir,
                    runId,
                    appConfig.getOutputCharset(),
                    fileNames,
                    fileSystemLabels,
                    unidentifiedFiles.size(),
                    lineCount,
                    quarantineCount,
                    groups.size(),
                    targetUsers.size(),
                    errorEventCount,
                    timelineCount,
                    inconsistentCount,
                    errorLogger.getErrorCount(),
                    elapsed,
                    permissionHardener.getFailures(),
                    permissionHardener
            );

            System.out.println("완료: 출력=" + outDir.toAbsolutePath() + " (runId=" + runId + ")");
            System.out.println("파일=" + files.size()
                    + ", 라인=" + lineCount
                    + ", 대상사용자=" + targetUsers.size()
                    + ", result=" + timelineCount
                    + ", quarantine=" + quarantineCount
                    + ", 소요ms=" + elapsed.toMillis());
            return 0;
        } catch (Exception e) {
            if (errorLogger != null) {
                errorLogger.logError("치명적 오류로 중단", e);
                System.err.println("실패: " + e.getMessage());
                System.err.println("상세 로그: " + errorLogger.getErrorFile().toAbsolutePath());
            } else {
                Path bootstrapLog = writeBootstrapErrorLog(outDir, runId, e, permissionHardener);
                System.err.println("실패: " + e.getMessage());
                if (bootstrapLog != null) {
                    System.err.println("상세 로그: " + bootstrapLog.toAbsolutePath());
                }
            }
            return 2;
        } finally {
            closeQuietly(mergeReader, "KWayMergeReader", errorLogger);
            closeQuietly(tsvWriter, "TsvWriter", errorLogger);
            closeQuietly(quarantineWriter, "QuarantineWriter", errorLogger);
            closeQuietly(errorLogger, "ExecutionErrorLogger", null);
        }
    }

    private static UserKey userKeyOf(LogEvent event, TraceGroup group) {
        String cmp = firstNonBlank(event.getCmp(), group.getResolvedCmp());
        String user = firstNonBlank(event.getUser(), group.getResolvedUser());
        return userKeyOf(cmp, user);
    }

    private static UserKey userKeyOf(String cmp, String user) {
        if (!isPresent(cmp) || !isPresent(user)) {
            return null;
        }
        return new UserKey(cmp.trim(), user.trim());
    }

    private static String firstNonBlank(String a, String b) {
        if (isPresent(a)) {
            return a.trim();
        }
        if (isPresent(b)) {
            return b.trim();
        }
        return null;
    }

    private static boolean isPresent(String value) {
        return value != null && !value.trim().isEmpty();
    }

    /**
     * 기존 output 디렉터리를 통째로 지운 뒤 새로 생성한다.
     */
    private static void recreateOutputDirectory(Path outDir) throws IOException {
        if (Files.exists(outDir)) {
            try (java.util.stream.Stream<Path> walk = Files.walk(outDir)) {
                List<Path> paths = new ArrayList<>();
                walk.sorted(Comparator.reverseOrder()).forEach(paths::add);
                for (Path path : paths) {
                    Files.deleteIfExists(path);
                }
            }
        }
        Files.createDirectories(outDir);
    }

    private static Path writeUnidentifiedSystemsReport(Path outDir,
                                                       String runId,
                                                       Charset charset,
                                                       List<String> unidentifiedFiles,
                                                       OutputFilePermissionHardener hardener) throws Exception {
        Path report = outDir.resolve(runId + "-unidentified-systems.tsv");
        try (BufferedWriter writer = Files.newBufferedWriter(report, charset,
                StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE)) {
            writer.write("원본파일명\t시스템");
            writer.newLine();
            for (String name : unidentifiedFiles) {
                writer.write(TsvUtil.join(name, SystemId.UNIDENTIFIED));
                writer.newLine();
            }
        }
        if (hardener != null) {
            hardener.harden(report);
        }
        return report;
    }

    private static Path writeBootstrapErrorLog(Path outDir, String runId, Exception e,
                                               OutputFilePermissionHardener hardener) {
        Path logPath = outDir.resolve(runId + "-execution-error.log");
        try {
            Files.createDirectories(outDir);
            StringWriter sw = new StringWriter();
            sw.write("==== " + LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME) + " ====\n");
            sw.write("기동/초기화 오류 (errorLogger 생성 전)\n");
            e.printStackTrace(new PrintWriter(sw));
            Files.write(logPath, sw.toString().getBytes(StandardCharsets.UTF_8),
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);
            if (hardener != null) {
                hardener.harden(logPath);
            }
            return logPath;
        } catch (Exception writeFail) {
            System.err.println("오류 로그 파일 기록 실패: " + writeFail.getMessage());
            System.err.println("원인: " + e.getMessage());
            return null;
        }
    }

    private static AppConfig loadAppConfig(Path configDir) throws Exception {
        Path file = resolveConfigFile(configDir, "app.properties");
        if (file != null) {
            return AppConfig.load(file);
        }
        return AppConfig.loadDefault();
    }

    private static ClassifyConfig loadClassifyConfig(Path configDir) throws Exception {
        Path file = resolveConfigFile(configDir, "classify.properties");
        if (file != null) {
            return ClassifyConfig.load(file);
        }
        return ClassifyConfig.loadDefault();
    }

    private static MybatisTypeConfig loadMybatisTypeConfig(Path configDir) throws Exception {
        Path file = resolveConfigFile(configDir, "mybatis-type.properties");
        if (file != null) {
            return MybatisTypeConfig.load(file);
        }
        return MybatisTypeConfig.loadDefault();
    }

    private static ErrorSignatureConfig loadErrorSignatureConfig(Path configDir) throws Exception {
        Path file = resolveConfigFile(configDir, "error-signature.properties");
        if (file != null) {
            return ErrorSignatureConfig.load(file);
        }
        return ErrorSignatureConfig.loadDefault();
    }

    private static Path resolveConfigFile(Path configDir, String name) {
        if (configDir == null) {
            return null;
        }
        if (Files.isDirectory(configDir)) {
            Path candidate = configDir.resolve(name);
            return Files.isRegularFile(candidate) ? candidate : null;
        }
        if (Files.isRegularFile(configDir)) {
            Path sibling = configDir.getParent() == null
                    ? Paths.get(name)
                    : configDir.getParent().resolve(name);
            return Files.isRegularFile(sibling) ? sibling : null;
        }
        return null;
    }

    private static String nullToEmpty(String v) {
        return v == null ? "" : v;
    }

    private static void closeQuietly(AutoCloseable closeable, String name, ExecutionErrorLogger errorLogger) {
        if (closeable == null) {
            return;
        }
        try {
            closeable.close();
        } catch (Exception e) {
            if (errorLogger != null) {
                errorLogger.logError("리소스 닫기 실패(비치명): " + name, e);
            } else {
                System.err.println("리소스 닫기 실패(비치명): " + name + " — " + e.getMessage());
            }
        }
    }

    private static final class UserKey {
        private final String companyCode;
        private final String employeeId;

        private UserKey(String companyCode, String employeeId) {
            this.companyCode = companyCode;
            this.employeeId = employeeId;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }
            if (!(o instanceof UserKey)) {
                return false;
            }
            UserKey userKey = (UserKey) o;
            return Objects.equals(companyCode, userKey.companyCode)
                    && Objects.equals(employeeId, userKey.employeeId);
        }

        @Override
        public int hashCode() {
            return Objects.hash(companyCode, employeeId);
        }
    }
}
