package com.loglineage;

import com.loglineage.config.AppConfig;
import com.loglineage.config.ClassifyConfig;
import com.loglineage.config.MybatisTypeConfig;
import com.loglineage.io.KWayMergeReader;
import com.loglineage.io.LogFileReader;
import com.loglineage.io.LogFileScanner;
import com.loglineage.lineage.ContextRuleEngine;
import com.loglineage.lineage.EventClassifier;
import com.loglineage.lineage.LineageRecordFactory;
import com.loglineage.lineage.MybatisPairer;
import com.loglineage.lineage.ThreadTracePropagator;
import com.loglineage.lineage.TraceGroupBuilder;
import com.loglineage.model.LineageRecord;
import com.loglineage.model.LogEvent;
import com.loglineage.model.TraceGroup;
import com.loglineage.output.ExecutionErrorLogger;
import com.loglineage.output.OutputFilePermissionHardener;
import com.loglineage.output.QuarantineWriter;
import com.loglineage.output.RunSummaryWriter;
import com.loglineage.output.TsvWriter;
import com.loglineage.parse.ContextTagParser;
import com.loglineage.parse.LogLineParser;
import com.loglineage.parse.MybatisParameterParser;
import com.loglineage.sql.SqlBinder;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Business Lineage 추적 CLI 진입점.
 * <pre>
 * java -jar loglineage.jar &lt;로그폴더경로&gt; [설정파일경로]
 * </pre>
 * 출력은 {@code <로그폴더>/output} 아래에 실행 시각({@code yyyyMMdd-HHmmss}) 접두사로 기록한다.
 */
public final class LogLineageApp {
    private static final DateTimeFormatter RUN_ID_FORMAT = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss");

    private LogLineageApp() {
    }

    public static void main(String[] args) {
        if (args.length < 1) {
            printUsage();
            System.exit(1);
            return;
        }

        Path logDir = Paths.get(args[0]);
        Path configDir = args.length >= 2 ? Paths.get(args[1]) : null;

        int code = new LogLineageApp().run(logDir, configDir);
        System.exit(code);
    }

    private static void printUsage() {
        System.err.println("사용법: java -jar loglineage.jar <로그폴더경로> [설정파일경로]");
        System.err.println("출력은 <로그폴더>/output 에 생성됩니다.");
        System.err.println("설정 경로에는 app.properties, classify.properties, mybatis-type.properties 를 둡니다.");
    }

    int run(Path logDir, Path configDir) {
        Instant started = Instant.now();
        String runId = LocalDateTime.now().format(RUN_ID_FORMAT);
        Path outDir = logDir.resolve("output");
        ExecutionErrorLogger errorLogger = null;
        QuarantineWriter quarantineWriter = null;
        TsvWriter tsvWriter = null;
        KWayMergeReader mergeReader = null;
        OutputFilePermissionHardener permissionHardener = new OutputFilePermissionHardener();

        try {
            Files.createDirectories(outDir);

            AppConfig appConfig = loadAppConfig(configDir);
            ClassifyConfig classifyConfig = loadClassifyConfig(configDir);
            MybatisTypeConfig typeConfig = loadMybatisTypeConfig(configDir);

            errorLogger = new ExecutionErrorLogger(outDir, runId, appConfig.getOutputCharset(), permissionHardener);
            for (String warning : classifyConfig.getLoadWarnings()) {
                errorLogger.logError(warning, null);
            }

            quarantineWriter = new QuarantineWriter(outDir, runId, appConfig.getOutputCharset(), permissionHardener);
            tsvWriter = new TsvWriter(outDir, runId, appConfig.getOutputCharset(), permissionHardener);

            LogFileScanner scanner = new LogFileScanner(appConfig, errorLogger);
            List<Path> files = scanner.scan(logDir);

            LogLineParser lineParser = new LogLineParser();
            ContextTagParser contextParser = new ContextTagParser();
            List<LogFileReader> readers = new ArrayList<>();
            for (Path file : files) {
                try {
                    readers.add(new LogFileReader(
                            file,
                            appConfig.getLogCharset(),
                            lineParser,
                            contextParser,
                            quarantineWriter,
                            errorLogger,
                            appConfig.getMaxMessageBytes(),
                            appConfig.getMaxContinuationLines()
                    ));
                } catch (Exception e) {
                    errorLogger.logError("로그 파일 열기 실패: " + file, e);
                }
            }

            mergeReader = new KWayMergeReader(readers);

            ThreadTracePropagator propagator = new ThreadTracePropagator();
            TraceGroupBuilder groupBuilder = new TraceGroupBuilder();
            List<LogEvent> orderedEvents = new ArrayList<>();
            for (LogEvent event : mergeReader) {
                propagator.apply(event);
                orderedEvents.add(event);
            }
            long lineCount = mergeReader.getTotalLinesRead();
            closeQuietly(mergeReader, "KWayMergeReader", errorLogger);
            mergeReader = null;

            List<TraceGroup> groups = groupBuilder.build(orderedEvents);
            orderedEvents.clear();

            ContextRuleEngine ruleEngine = new ContextRuleEngine();
            MybatisPairer pairer = new MybatisPairer(new MybatisParameterParser(), new SqlBinder(typeConfig));
            LineageRecordFactory recordFactory = new LineageRecordFactory(new EventClassifier(classifyConfig));

            List<GroupBundle> allBundles = new ArrayList<>();
            long mainGroupCount = 0;
            long unresolvedGroupCount = 0;
            long inconsistentGroupCount = 0;

            for (TraceGroup group : groups) {
                ContextRuleEngine.Disposition disposition = ruleEngine.apply(group);
                MybatisPairer.PairingResult pairing = pairer.pair(group);
                String conflict = group.isConflicting() ? group.getConflictingValues() : null;
                List<LineageRecord> records = recordFactory.toRecords(group, pairing, conflict);
                allBundles.add(new GroupBundle(group, records, disposition));
                switch (disposition) {
                    case MAIN:
                        mainGroupCount++;
                        break;
                    case UNAUTHENTICATED:
                        unresolvedGroupCount++;
                        break;
                    case INCONSISTENT:
                        inconsistentGroupCount++;
                        break;
                    default:
                        unresolvedGroupCount++;
                        break;
                }
            }

            allBundles.sort(Comparator
                    .comparing((GroupBundle b) -> b.group.getFirstEventTime(),
                            Comparator.nullsLast(Comparator.naturalOrder()))
                    .thenComparing(b -> nullToEmpty(b.group.getTraceId())));

            long seq = 1;
            for (GroupBundle bundle : allBundles) {
                for (LineageRecord record : bundle.records) {
                    record.setSeq(seq++);
                    switch (bundle.disposition) {
                        case MAIN:
                            tsvWriter.writeMain(record);
                            break;
                        case UNAUTHENTICATED:
                            tsvWriter.writeUnresolved(record);
                            break;
                        case INCONSISTENT:
                            tsvWriter.writeInconsistent(record);
                            break;
                        default:
                            tsvWriter.writeUnresolved(record);
                            break;
                    }
                }
            }

            // close writers before summary so close 실패가 errorCount에 반영된다
            long quarantineCount = quarantineWriter.getCount();
            long lineageCount = tsvWriter.getLineageCount();
            long unresolvedCount = tsvWriter.getUnresolvedCount();
            long inconsistentCount = tsvWriter.getInconsistentCount();
            closeQuietly(tsvWriter, "TsvWriter", errorLogger);
            tsvWriter = null;
            closeQuietly(quarantineWriter, "QuarantineWriter", errorLogger);
            quarantineWriter = null;

            List<String> fileNames = new ArrayList<>();
            for (Path f : files) {
                fileNames.add(f.getFileName().toString());
            }

            Duration elapsed = Duration.between(started, Instant.now());
            new RunSummaryWriter().write(
                    outDir,
                    runId,
                    appConfig.getOutputCharset(),
                    fileNames,
                    lineCount,
                    quarantineCount,
                    groups.size(),
                    mainGroupCount,
                    unresolvedGroupCount,
                    inconsistentGroupCount,
                    lineageCount,
                    unresolvedCount,
                    inconsistentCount,
                    errorLogger.getErrorCount(),
                    elapsed,
                    permissionHardener.getFailures(),
                    permissionHardener
            );

            System.out.println("완료: 출력=" + outDir.toAbsolutePath() + " (runId=" + runId + ")");
            System.out.println("파일=" + files.size()
                    + ", 라인=" + lineCount
                    + ", quarantine=" + quarantineCount
                    + ", 소요ms=" + elapsed.toMillis());
            return 0;
        } catch (Exception e) {
            if (errorLogger != null) {
                errorLogger.logError("치명적 오류로 중단", e);
                System.err.println("실패: " + e.getMessage());
                System.err.println("상세 로그: " + errorLogger.getErrorFile().toAbsolutePath());
            } else {
                Path bootstrapLog = writeBootstrapErrorLog(outDir, runId, e, permissionHardener);
                System.err.println("실패: " + e.getMessage());
                if (bootstrapLog != null) {
                    System.err.println("상세 로그: " + bootstrapLog.toAbsolutePath());
                }
            }
            return 2;
        } finally {
            closeQuietly(mergeReader, "KWayMergeReader", errorLogger);
            closeQuietly(tsvWriter, "TsvWriter", errorLogger);
            closeQuietly(quarantineWriter, "QuarantineWriter", errorLogger);
            closeQuietly(errorLogger, "ExecutionErrorLogger", null);
        }
    }

    /**
     * errorLogger 생성 전 실패 시 가능하면 파일에 스택을 남기고 경로를 반환한다.
     */
    private static Path writeBootstrapErrorLog(Path outDir, String runId, Exception e,
                                               OutputFilePermissionHardener hardener) {
        Path logPath = outDir.resolve(runId + "-execution-error.log");
        try {
            Files.createDirectories(outDir);
            StringWriter sw = new StringWriter();
            sw.write("==== " + LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME) + " ====\n");
            sw.write("기동/초기화 오류 (errorLogger 생성 전)\n");
            e.printStackTrace(new PrintWriter(sw));
            Files.write(logPath, sw.toString().getBytes(StandardCharsets.UTF_8),
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);
            if (hardener != null) {
                hardener.harden(logPath);
            }
            return logPath;
        } catch (Exception writeFail) {
            System.err.println("오류 로그 파일 기록 실패: " + writeFail.getMessage());
            System.err.println("원인: " + e.getMessage());
            return null;
        }
    }

    private static AppConfig loadAppConfig(Path configDir) throws Exception {
        Path file = resolveConfigFile(configDir, "app.properties");
        if (file != null) {
            return AppConfig.load(file);
        }
        return AppConfig.loadDefault();
    }

    private static ClassifyConfig loadClassifyConfig(Path configDir) throws Exception {
        Path file = resolveConfigFile(configDir, "classify.properties");
        if (file != null) {
            return ClassifyConfig.load(file);
        }
        return ClassifyConfig.loadDefault();
    }

    private static MybatisTypeConfig loadMybatisTypeConfig(Path configDir) throws Exception {
        Path file = resolveConfigFile(configDir, "mybatis-type.properties");
        if (file != null) {
            return MybatisTypeConfig.load(file);
        }
        return MybatisTypeConfig.loadDefault();
    }

    private static Path resolveConfigFile(Path configDir, String name) {
        if (configDir == null) {
            return null;
        }
        if (Files.isDirectory(configDir)) {
            Path candidate = configDir.resolve(name);
            return Files.isRegularFile(candidate) ? candidate : null;
        }
        if (Files.isRegularFile(configDir)) {
            Path sibling = configDir.getParent() == null
                    ? Paths.get(name)
                    : configDir.getParent().resolve(name);
            return Files.isRegularFile(sibling) ? sibling : null;
        }
        return null;
    }

    private static String nullToEmpty(String v) {
        return v == null ? "" : v;
    }

    /**
     * close 예외를 swallow하지 않고 errorLogger(또는 stderr 한 줄)에 남긴다. 배치 자체는 중단하지 않는다.
     */
    private static void closeQuietly(AutoCloseable closeable, String name, ExecutionErrorLogger errorLogger) {
        if (closeable == null) {
            return;
        }
        try {
            closeable.close();
        } catch (Exception e) {
            if (errorLogger != null) {
                errorLogger.logError("리소스 닫기 실패(비치명): " + name, e);
            } else {
                System.err.println("리소스 닫기 실패(비치명): " + name + " — " + e.getMessage());
            }
        }
    }

    private static final class GroupBundle {
        private final TraceGroup group;
        private final List<LineageRecord> records;
        private final ContextRuleEngine.Disposition disposition;

        private GroupBundle(TraceGroup group,
                            List<LineageRecord> records,
                            ContextRuleEngine.Disposition disposition) {
            this.group = group;
            this.records = records;
            this.disposition = disposition;
        }
    }
}
