package com.loglineage.lineage;

import com.loglineage.model.LogEvent;

import java.util.HashMap;
import java.util.Map;

/**
 * 동일 스레드에서 직전에 관측된 traceId를, 컨텍스트 태그가 없는 후속 이벤트에 전파한다.
 * MyBatis Preparing/Parameters/Total 처럼 메시지에 컨텍스트가 없는 라인이
 * 동일 요청 그룹에 속하도록 하기 위함이다. (로그인 이벤트 특수 처리는 없음)
 */
public class ThreadTracePropagator {
    private final Map<String, String> lastTraceByThread = new HashMap<>();

    public void apply(LogEvent event) {
        if (event == null) {
            return;
        }
        String threadKey = event.getThread() == null ? "" : event.getThread();
        if (isPresent(event.getTraceId())) {
            lastTraceByThread.put(threadKey, event.getTraceId());
            return;
        }
        String inherited = lastTraceByThread.get(threadKey);
        if (isPresent(inherited)) {
            event.setTraceId(inherited);
        }
    }

    private static boolean isPresent(String value) {
        return value != null && !value.trim().isEmpty();
    }
}
