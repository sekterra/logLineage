package com.loglineage.lineage;

import com.loglineage.model.LogEvent;

import java.util.HashMap;
import java.util.Map;

/**
 * 동일 파일·동일 스레드에서 직전에 관측된 traceId를, 컨텍스트 태그가 없는 후속 이벤트에 전파한다.
 * MyBatis Preparing/Parameters/Total 처럼 메시지에 컨텍스트가 없는 라인이
 * 동일 요청 그룹에 속하도록 하기 위함이다.
 * 파일 키를 포함해 멀티 파일 merge 시 스레드명 충돌로 인한 오전파를 막는다.
 */
public class ThreadTracePropagator {
    private final Map<String, String> lastTraceByFileThread = new HashMap<>();

    public void apply(LogEvent event) {
        if (event == null) {
            return;
        }
        String key = fileThreadKey(event);
        if (isPresent(event.getTraceId())) {
            lastTraceByFileThread.put(key, event.getTraceId());
            return;
        }
        String inherited = lastTraceByFileThread.get(key);
        if (isPresent(inherited)) {
            event.setTraceId(inherited);
        }
    }

    private static String fileThreadKey(LogEvent event) {
        String file = event.getSourceFile() == null ? "" : event.getSourceFile();
        String thread = event.getThread() == null ? "" : event.getThread();
        return file + '\u0001' + thread;
    }

    private static boolean isPresent(String value) {
        return value != null && !value.trim().isEmpty();
    }
}
