package com.loglineage.lineage;

import com.loglineage.model.LogEvent;
import com.loglineage.model.TraceGroup;

import java.util.LinkedHashSet;
import java.util.Set;

/**
 * 컨텍스트 규칙 A/B/C.
 * A: 동일 traceId 내 빈 cmp/user backfill
 * B: 전부 없음 → 미인증/미해석
 * C: 충돌 → inconsistent
 */
public class ContextRuleEngine {

    public enum Disposition {
        MAIN,
        UNAUTHENTICATED,
        INCONSISTENT
    }

    public Disposition apply(TraceGroup group) {
        Set<String> cmpValues = new LinkedHashSet<>();
        Set<String> userValues = new LinkedHashSet<>();

        for (LogEvent event : group.getEvents()) {
            if (isPresent(event.getCmp())) {
                cmpValues.add(event.getCmp());
            }
            if (isPresent(event.getUser())) {
                userValues.add(event.getUser());
            }
        }

        boolean cmpConflict = cmpValues.size() > 1;
        boolean userConflict = userValues.size() > 1;
        if (cmpConflict || userConflict) {
            group.setConflicting(true);
            group.setConflictingValues(buildConflictValues(cmpValues, userValues));
            // 대표값은 첫 관측값 유지 (출력용)
            group.setResolvedCmp(firstOrNull(cmpValues));
            group.setResolvedUser(firstOrNull(userValues));
            return Disposition.INCONSISTENT;
        }

        String resolvedCmp = firstOrNull(cmpValues);
        String resolvedUser = firstOrNull(userValues);

        // Rule A: backfill
        for (LogEvent event : group.getEvents()) {
            if (!isPresent(event.getCmp()) && resolvedCmp != null) {
                event.setCmp(resolvedCmp);
            }
            if (!isPresent(event.getUser()) && resolvedUser != null) {
                event.setUser(resolvedUser);
            }
        }
        group.setResolvedCmp(resolvedCmp);
        group.setResolvedUser(resolvedUser);

        // Rule B: all missing
        if (!isPresent(resolvedCmp) && !isPresent(resolvedUser)) {
            return Disposition.UNAUTHENTICATED;
        }
        return Disposition.MAIN;
    }

    private static boolean isPresent(String value) {
        return value != null && !value.trim().isEmpty();
    }

    private static String firstOrNull(Set<String> values) {
        if (values.isEmpty()) {
            return null;
        }
        return values.iterator().next();
    }

    private static String buildConflictValues(Set<String> cmpValues, Set<String> userValues) {
        StringBuilder sb = new StringBuilder();
        sb.append("cmp=[");
        sb.append(String.join("|", cmpValues));
        sb.append("];user=[");
        sb.append(String.join("|", userValues));
        sb.append("]");
        return sb.toString();
    }
}
