package com.loglineage.lineage;

import com.loglineage.model.LogEvent;
import com.loglineage.model.SqlPair;
import com.loglineage.model.TraceGroup;
import com.loglineage.parse.MybatisParameterParser;
import com.loglineage.sql.SqlBinder;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

/**
 * 동일 thread + 동일 traceId 기준으로 Preparing / Parameters / Total 페어링.
 */
public class MybatisPairer {
    private final MybatisParameterParser parameterParser;
    private final SqlBinder sqlBinder;

    public MybatisPairer(MybatisParameterParser parameterParser, SqlBinder sqlBinder) {
        this.parameterParser = parameterParser;
        this.sqlBinder = sqlBinder;
    }

    /**
     * Preparing 이벤트 → SqlPair 매핑. Parameters/Total은 소비 대상으로 표시.
     */
    public PairingResult pair(TraceGroup group) {
        Map<LogEvent, SqlPair> preparingToSql = new HashMap<>();
        Set<LogEvent> consumed = new HashSet<>();
        List<LogEvent> events = group.getEvents();

        for (int i = 0; i < events.size(); i++) {
            LogEvent preparing = events.get(i);
            if (!preparing.isMybatisPreparing()) {
                continue;
            }
            LogEvent parameters = null;
            LogEvent total = null;
            for (int j = i + 1; j < events.size(); j++) {
                LogEvent candidate = events.get(j);
                if (!samePairKey(preparing, candidate)) {
                    continue;
                }
                if (parameters == null && candidate.isMybatisParameters()) {
                    parameters = candidate;
                    continue;
                }
                if (parameters != null && total == null && candidate.isMybatisTotal()) {
                    total = candidate;
                    break;
                }
                // 다음 Preparing이 같은 키로 오면 현재 페어 종료
                if (candidate.isMybatisPreparing()) {
                    break;
                }
            }

            String template = extractPreparingSql(preparing.getMessage());
            String executable = template;
            if (parameters != null) {
                List<MybatisParameterParser.Param> params = parameterParser.parse(parameters.getMessage());
                executable = sqlBinder.bind(template, params);
                consumed.add(parameters);
            }
            if (total != null) {
                consumed.add(total);
            }
            preparingToSql.put(preparing, new SqlPair(template, executable));
        }
        return new PairingResult(preparingToSql, consumed);
    }

    private static boolean samePairKey(LogEvent a, LogEvent b) {
        return Objects.equals(nullToEmpty(a.getThread()), nullToEmpty(b.getThread()))
                && Objects.equals(nullToEmpty(a.getTraceId()), nullToEmpty(b.getTraceId()));
    }

    private static String nullToEmpty(String v) {
        return v == null ? "" : v;
    }

    static String extractPreparingSql(String message) {
        if (message == null) {
            return "";
        }
        int idx = message.indexOf("Preparing:");
        if (idx < 0) {
            return message.trim();
        }
        return message.substring(idx + "Preparing:".length()).trim();
    }

    public static final class PairingResult {
        private final Map<LogEvent, SqlPair> preparingToSql;
        private final Set<LogEvent> consumed;

        public PairingResult(Map<LogEvent, SqlPair> preparingToSql, Set<LogEvent> consumed) {
            this.preparingToSql = preparingToSql;
            this.consumed = consumed;
        }

        public Map<LogEvent, SqlPair> getPreparingToSql() {
            return preparingToSql;
        }

        public Set<LogEvent> getConsumed() {
            return consumed;
        }
    }
}
