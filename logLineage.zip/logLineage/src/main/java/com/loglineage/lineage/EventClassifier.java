package com.loglineage.lineage;

import com.loglineage.config.ClassifyConfig;
import com.loglineage.model.EventType;
import com.loglineage.model.LogEvent;

/**
 * properties 기반 이벤트 분류.
 * MyBatis는 Preparing/Parameters/Total 존재로 식별.
 * 미매칭은 UNCLASSIFIED (quarantine 아님).
 */
public class EventClassifier {
    private final ClassifyConfig classifyConfig;

    public EventClassifier(ClassifyConfig classifyConfig) {
        this.classifyConfig = classifyConfig;
    }

    public EventType classify(LogEvent event) {
        if (event == null) {
            return EventType.UNCLASSIFIED;
        }
        if (event.isMybatisRelated()) {
            return EventType.MYBATIS;
        }
        String logger = event.getLogger();
        if (classifyConfig.matchesController(logger)) {
            return EventType.CONTROLLER;
        }
        if (classifyConfig.matchesService(logger)) {
            return EventType.SERVICE;
        }
        return EventType.UNCLASSIFIED;
    }
}
