package com.loglineage.lineage;

import com.loglineage.model.EventType;
import com.loglineage.model.LineageRecord;
import com.loglineage.model.LogEvent;
import com.loglineage.model.SqlPair;
import com.loglineage.model.TraceGroup;

import java.util.ArrayList;
import java.util.List;

/**
 * TraceGroup 이벤트를 RCA 타임라인 레코드로 변환.
 */
public class LineageRecordFactory {
    private final EventClassifier classifier;

    public LineageRecordFactory(EventClassifier classifier) {
        this.classifier = classifier;
    }

    public List<LineageRecord> toRecords(TraceGroup group,
                                         MybatisPairer.PairingResult pairing) {
        List<LineageRecord> records = new ArrayList<>();
        boolean conflicting = group.isConflicting();
        String conflictValues = conflicting ? group.getConflictingValues() : null;

        for (LogEvent event : group.getEvents()) {
            if (pairing.getConsumed().contains(event)) {
                continue;
            }
            LineageRecord record = new LineageRecord();
            // 충돌 그룹은 대표(resolved) 신원으로 묶어 타임라인에 남긴다
            if (conflicting) {
                record.setCompanyCode(group.getResolvedCmp());
                record.setEmployeeId(group.getResolvedUser());
            } else {
                record.setCompanyCode(firstNonBlank(event.getCmp(), group.getResolvedCmp()));
                record.setEmployeeId(firstNonBlank(event.getUser(), group.getResolvedUser()));
            }
            record.setEventTime(event.getTimestamp());
            record.setErrorEvent(event.isErrorEvent());
            record.setTraceId(event.getTraceId() != null ? event.getTraceId() : group.getTraceId());
            record.setLevel(event.getLevel());
            record.setLogger(event.getLogger());
            record.setUri(blankToNull(event.getUri()));
            record.setMessage(event.getMessage() == null ? "" : event.getMessage());
            record.setSystemId(event.getSystemId());
            record.setSourceFile(event.getSourceFile());
            record.setSourceLine(event.getSourceLine());
            record.setContextInconsistent(conflicting || event.isContextInconsistent());
            record.setConflictingValues(conflictValues);

            EventType type = classifier.classify(event);
            record.setEventType(type);

            SqlPair sql = pairing.getPreparingToSql().get(event);
            if (sql != null) {
                record.setSqlTemplate(sql.getSqlTemplate());
                record.setSqlExecutable(sql.getSqlExecutable());
                record.setEventType(EventType.MYBATIS);
            }

            records.add(record);
        }
        return records;
    }

    private static String firstNonBlank(String a, String b) {
        if (a != null && !a.trim().isEmpty()) {
            return a;
        }
        if (b != null && !b.trim().isEmpty()) {
            return b;
        }
        return null;
    }

    private static String blankToNull(String value) {
        if (value == null || value.trim().isEmpty()) {
            return null;
        }
        return value;
    }
}
