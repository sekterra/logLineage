package com.loglineage.lineage;

import com.loglineage.model.EventType;
import com.loglineage.model.LineageRecord;
import com.loglineage.model.LogEvent;
import com.loglineage.model.SqlPair;
import com.loglineage.model.TraceGroup;

import java.util.ArrayList;
import java.util.List;

/**
 * TraceGroup 이벤트를 LineageRecord로 변환.
 */
public class LineageRecordFactory {
    private final EventClassifier classifier;

    public LineageRecordFactory(EventClassifier classifier) {
        this.classifier = classifier;
    }

    public List<LineageRecord> toRecords(TraceGroup group,
                                         MybatisPairer.PairingResult pairing,
                                         String conflictingValues) {
        List<LineageRecord> records = new ArrayList<>();
        for (LogEvent event : group.getEvents()) {
            if (pairing.getConsumed().contains(event)) {
                // Parameters / Total 은 Preparing에 흡수
                continue;
            }
            LineageRecord record = new LineageRecord();
            record.setTraceId(group.getTraceId());
            record.setCompanyCode(firstNonBlank(event.getCmp(), group.getResolvedCmp()));
            record.setEmployeeId(firstNonBlank(event.getUser(), group.getResolvedUser()));
            record.setEventTime(event.getTimestamp());
            record.setThread(event.getThread());
            record.setLogger(event.getLogger());
            applyUri(record, event);
            record.setSourceFile(event.getSourceFile());
            record.setSourceLine(event.getSourceLine());
            record.setConflictingValues(conflictingValues);

            EventType type = classifier.classify(event);
            record.setEventType(type);

            SqlPair sql = pairing.getPreparingToSql().get(event);
            if (sql != null) {
                record.setSqlTemplate(sql.getSqlTemplate());
                record.setSqlExecutable(sql.getSqlExecutable());
                record.setEventType(EventType.MYBATIS);
            }

            records.add(record);
        }
        return records;
    }

    private static void applyUri(LineageRecord record, LogEvent event) {
        String uri = event.getUri();
        if (uri == null || uri.trim().isEmpty()) {
            record.setUri(event.getLogger());
            record.setUriSource("FALLBACK_LOGGER");
        } else {
            record.setUri(uri);
            record.setUriSource("ORIGINAL");
        }
    }

    private static String firstNonBlank(String a, String b) {
        if (a != null && !a.trim().isEmpty()) {
            return a;
        }
        if (b != null && !b.trim().isEmpty()) {
            return b;
        }
        return null;
    }
}
