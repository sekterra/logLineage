package com.loglineage.lineage;

import com.loglineage.model.LogEvent;
import com.loglineage.model.TraceGroup;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 시간 순서를 유지하며 (원본파일, traceId)로 그룹화.
 * 멀티 파일 병합 시 서로 다른 서버/파일이 동일 traceId 문자열을 재사용해도
 * backfill·충돌 판정이 섞이지 않도록 파일 단위로 분리한다.
 * traceId가 없으면 서로 backfill되지 않도록 싱글톤 그룹으로 분리.
 */
public class TraceGroupBuilder {
    public List<TraceGroup> build(Iterable<LogEvent> events) {
        Map<String, TraceGroup> keyed = new LinkedHashMap<>();
        List<TraceGroup> singletonNulls = new ArrayList<>();

        for (LogEvent event : events) {
            String traceId = event.getTraceId();
            if (traceId == null || traceId.isEmpty()) {
                TraceGroup group = new TraceGroup(null);
                group.addEvent(event);
                singletonNulls.add(group);
            } else {
                String key = groupKey(event.getSourceFile(), traceId);
                TraceGroup group = keyed.get(key);
                if (group == null) {
                    group = new TraceGroup(traceId);
                    keyed.put(key, group);
                }
                group.addEvent(event);
            }
        }

        List<TraceGroup> result = new ArrayList<>(keyed.values());
        result.addAll(singletonNulls);
        return result;
    }

    static String groupKey(String sourceFile, String traceId) {
        return nullToEmpty(sourceFile) + '\u0001' + traceId;
    }

    private static String nullToEmpty(String value) {
        return value == null ? "" : value;
    }
}
