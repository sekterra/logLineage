package com.loglineage.lineage;

import com.loglineage.model.LogEvent;
import com.loglineage.model.TraceGroup;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 시간 순서를 유지하며 traceId로 그룹화.
 * traceId가 없으면 서로 backfill되지 않도록 싱글톤 그룹으로 분리.
 */
public class TraceGroupBuilder {
    public List<TraceGroup> build(Iterable<LogEvent> events) {
        Map<String, TraceGroup> keyed = new LinkedHashMap<>();
        List<TraceGroup> singletonNulls = new ArrayList<>();

        for (LogEvent event : events) {
            String traceId = event.getTraceId();
            if (traceId == null || traceId.isEmpty()) {
                TraceGroup group = new TraceGroup(null);
                group.addEvent(event);
                singletonNulls.add(group);
            } else {
                TraceGroup group = keyed.get(traceId);
                if (group == null) {
                    group = new TraceGroup(traceId);
                    keyed.put(traceId, group);
                }
                group.addEvent(event);
            }
        }

        List<TraceGroup> result = new ArrayList<>(keyed.values());
        result.addAll(singletonNulls);
        return result;
    }
}
