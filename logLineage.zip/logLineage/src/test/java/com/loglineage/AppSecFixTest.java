package com.loglineage;

import com.loglineage.config.AppConfig;
import com.loglineage.config.ClassifyConfig;
import com.loglineage.io.LogFileReader;
import com.loglineage.model.LogEvent;
import com.loglineage.output.ExecutionErrorLogger;
import com.loglineage.output.OutputFilePermissionHardener;
import com.loglineage.output.QuarantineWriter;
import com.loglineage.output.TsvWriter;
import com.loglineage.parse.ContextTagParser;
import com.loglineage.parse.LogLineParser;
import com.loglineage.parse.MybatisParameterParser;
import com.loglineage.util.TsvUtil;

import java.io.BufferedWriter;
import java.io.IOException;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * AppSec 관련 JDK-only 검증 (JUnit 없음).
 */
public final class AppSecFixTest {
    private static int passed;
    private static int failed;

    private AppSecFixTest() {
    }

    public static void main(String[] args) throws Exception {
        testTsvFormulaInjectionNeutralized();
        testTsvTabsNewlinesStillNormalized();
        testMybatisLinearParseWithCommasInValue();
        testMybatisLinearParseMultipleParams();
        testClassifyInvalidPatternDisablesRule();
        testClassifyOverlongPatternDisablesRule();
        testEventMessageByteLimitTruncatesAndQuarantines();
        testContinuationLineLimitQuarantines();
        testTsvWriterCloseContinuesAfterFirstFailure();
        testAppConfigMessageLimitDefaults();

        System.out.println();
        System.out.println("passed=" + passed + " failed=" + failed);
        if (failed > 0) {
            System.exit(1);
        }
    }

    private static void testTsvFormulaInjectionNeutralized() {
        assertEquals("'=1+1", TsvUtil.escape("=1+1"));
        assertEquals("'+cmd", TsvUtil.escape("+cmd"));
        assertEquals("'-1", TsvUtil.escape("-1"));
        assertEquals("'@sum", TsvUtil.escape("@sum"));
        assertEquals("ok", TsvUtil.escape("ok"));
        pass("tsvFormulaInjectionNeutralized");
    }

    private static void testTsvTabsNewlinesStillNormalized() {
        assertEquals("a b c", TsvUtil.escape("a\tb\nc"));
        assertEquals("'=a b", TsvUtil.escape("=a\tb"));
        pass("tsvTabsNewlinesStillNormalized");
    }

    private static void testMybatisLinearParseWithCommasInValue() {
        MybatisParameterParser parser = new MybatisParameterParser();
        List<MybatisParameterParser.Param> params =
                parser.parse("Parameters: a,b,c(String), 42(Integer)");
        assertEquals(2, params.size());
        assertEquals("a,b,c", params.get(0).getValue());
        assertEquals("String", params.get(0).getTypeName());
        assertEquals("42", params.get(1).getValue());
        assertEquals("Integer", params.get(1).getTypeName());
        pass("mybatisLinearParseWithCommasInValue");
    }

    private static void testMybatisLinearParseMultipleParams() {
        MybatisParameterParser parser = new MybatisParameterParser();
        List<MybatisParameterParser.Param> params =
                parser.parse("==> Parameters: OPEN(String), null(Timestamp), x.y(java.lang.Long)");
        assertEquals(3, params.size());
        assertEquals("OPEN", params.get(0).getValue());
        assertEquals("null", params.get(1).getValue());
        assertEquals("x.y", params.get(2).getValue());
        assertEquals("java.lang.Long", params.get(2).getTypeName());
        pass("mybatisLinearParseMultipleParams");
    }

    private static void testClassifyInvalidPatternDisablesRule() throws Exception {
        Path dir = Files.createTempDirectory("ll-classify-bad");
        Path file = dir.resolve("classify.properties");
        Files.writeString(file,
                "classify.controller.logger.pattern=[unclosed\n"
                        + "classify.service.logger.pattern=\n",
                StandardCharsets.UTF_8);
        ClassifyConfig cfg = ClassifyConfig.load(file);
        assertTrue("invalid pattern must disable controller", !cfg.matchesController("com.example.controller.X"));
        assertTrue("warning recorded", !cfg.getLoadWarnings().isEmpty());
        assertTrue("warning mentions key",
                cfg.getLoadWarnings().get(0).contains("classify.controller.logger.pattern"));
        pass("classifyInvalidPatternDisablesRule");
    }

    private static void testClassifyOverlongPatternDisablesRule() throws Exception {
        Path dir = Files.createTempDirectory("ll-classify-long");
        Path file = dir.resolve("classify.properties");
        StringBuilder longPat = new StringBuilder();
        for (int i = 0; i < ClassifyConfig.MAX_PATTERN_LENGTH + 10; i++) {
            longPat.append('a');
        }
        Files.writeString(file,
                "classify.controller.logger.pattern=" + longPat + "\n"
                        + "classify.service.logger.pattern=\n",
                StandardCharsets.UTF_8);
        ClassifyConfig cfg = ClassifyConfig.load(file);
        assertTrue(!cfg.matchesController("aaa"));
        assertTrue(cfg.getLoadWarnings().get(0).contains("길이 초과"));
        pass("classifyOverlongPatternDisablesRule");
    }

    private static void testEventMessageByteLimitTruncatesAndQuarantines() throws Exception {
        Path dir = Files.createTempDirectory("ll-msg-limit");
        Path log = dir.resolve("t.log");
        String big = repeat('X', 80);
        Files.writeString(log,
                "2026-08-08 10:00:00.001 {t} INFO com.example.A - [trace:T1][cmp:C][user:U][uri:/x] " + big + "\n",
                StandardCharsets.UTF_8);

        OutputFilePermissionHardener hardener = new OutputFilePermissionHardener();
        try (ExecutionErrorLogger err = new ExecutionErrorLogger(dir, "r", StandardCharsets.UTF_8, hardener);
             QuarantineWriter q = new QuarantineWriter(dir, "r", StandardCharsets.UTF_8, hardener);
             LogFileReader reader = new LogFileReader(
                     log, StandardCharsets.UTF_8, new LogLineParser(), new ContextTagParser(),
                     q, err, 40, 100)) {
            Optional<LogEvent> event = reader.readNext();
            assertTrue(event.isPresent());
            assertTrue("header truncated", event.get().isMessageTruncated());
            assertTrue(event.get().getMessageUtf8Bytes() <= 40);
            assertTrue(q.getCount() >= 1);
            assertTrue(err.getErrorCount() >= 1);
        }
        pass("eventMessageByteLimitTruncatesAndQuarantines");
    }

    private static void testContinuationLineLimitQuarantines() throws Exception {
        Path dir = Files.createTempDirectory("ll-cont-limit");
        Path log = dir.resolve("t.log");
        Files.writeString(log,
                "2026-08-08 10:00:00.001 {t} INFO com.example.A - [trace:T1][cmp:C][user:U][uri:/x] head\n"
                        + "cont1\n"
                        + "cont2\n"
                        + "cont3\n",
                StandardCharsets.UTF_8);

        OutputFilePermissionHardener hardener = new OutputFilePermissionHardener();
        try (ExecutionErrorLogger err = new ExecutionErrorLogger(dir, "r", StandardCharsets.UTF_8, hardener);
             QuarantineWriter q = new QuarantineWriter(dir, "r", StandardCharsets.UTF_8, hardener);
             LogFileReader reader = new LogFileReader(
                     log, StandardCharsets.UTF_8, new LogLineParser(), new ContextTagParser(),
                     q, err, 1_000_000, 1)) {
            Optional<LogEvent> event = reader.readNext();
            assertTrue(event.isPresent());
            assertEquals(1, event.get().getContinuationLineCount());
            assertTrue(event.get().getMessage().contains("cont1"));
            assertTrue(!event.get().getMessage().contains("cont2"));
            assertTrue(q.getCount() >= 2);
        }
        pass("continuationLineLimitQuarantines");
    }

    private static void testTsvWriterCloseContinuesAfterFirstFailure() throws Exception {
        Path dir = Files.createTempDirectory("ll-tsv-close");
        OutputFilePermissionHardener hardener = new OutputFilePermissionHardener();
        TsvWriter tsv = new TsvWriter(dir, "r", StandardCharsets.UTF_8, hardener);

        Field lineageField = TsvWriter.class.getDeclaredField("lineageWriter");
        lineageField.setAccessible(true);
        BufferedWriter original = (BufferedWriter) lineageField.get(tsv);
        AtomicInteger closeCount = new AtomicInteger();
        BufferedWriter failing = new BufferedWriter(original) {
            @Override
            public void close() throws IOException {
                closeCount.incrementAndGet();
                throw new IOException("simulated lineage close failure");
            }
        };
        lineageField.set(tsv, failing);

        IOException thrown = null;
        try {
            tsv.close();
        } catch (IOException e) {
            thrown = e;
        }
        assertTrue("first close failure should surface", thrown != null);
        assertTrue("failing writer close invoked", closeCount.get() >= 1);

        // unresolved / inconsistent files should still be closed (flushable / not locked forever)
        Path unresolved = dir.resolve("r-unauthenticated-or-unresolved.tsv");
        Path inconsistent = dir.resolve("r-context-inconsistent.tsv");
        assertTrue(Files.exists(unresolved));
        assertTrue(Files.exists(inconsistent));
        // reopen for append to prove handles were released on Windows
        try (BufferedWriter w = Files.newBufferedWriter(unresolved, StandardCharsets.UTF_8,
                java.nio.file.StandardOpenOption.APPEND)) {
            w.write("probe\n");
        }
        pass("tsvWriterCloseContinuesAfterFirstFailure");
    }

    private static void testAppConfigMessageLimitDefaults() throws Exception {
        AppConfig cfg = AppConfig.loadDefault();
        assertEquals(AppConfig.DEFAULT_MAX_MESSAGE_BYTES, cfg.getMaxMessageBytes());
        assertEquals(AppConfig.DEFAULT_MAX_CONTINUATION_LINES, cfg.getMaxContinuationLines());
        pass("appConfigMessageLimitDefaults");
    }

    private static String repeat(char c, int n) {
        StringBuilder sb = new StringBuilder(n);
        for (int i = 0; i < n; i++) {
            sb.append(c);
        }
        return sb.toString();
    }

    private static void assertEquals(Object expected, Object actual) {
        if (expected == null ? actual != null : !expected.equals(actual)) {
            failed++;
            String msg = "expected=" + expected + " actual=" + actual;
            System.err.println("FAIL: " + msg);
            throw new AssertionError(msg);
        }
    }

    private static void assertEquals(int expected, int actual) {
        if (expected != actual) {
            failed++;
            String msg = "expected=" + expected + " actual=" + actual;
            System.err.println("FAIL: " + msg);
            throw new AssertionError(msg);
        }
    }

    private static void assertTrue(String message, boolean condition) {
        if (!condition) {
            failed++;
            System.err.println("FAIL: " + message);
            throw new AssertionError(message);
        }
    }

    private static void assertTrue(boolean condition) {
        assertTrue("assertion failed", condition);
    }

    private static void pass(String name) {
        passed++;
        System.out.println("OK: " + name);
    }
}
