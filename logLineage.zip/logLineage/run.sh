#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ ! -f dist/loglineage.jar ]]; then
  ./build.sh
fi
java -jar dist/loglineage.jar "$@"
