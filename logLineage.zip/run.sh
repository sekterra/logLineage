#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ ! -f dist/loglineage.jar ]]; then
  ./build.sh
fi
# OOM 근본 대책은 2-Pass 스트리밍이다. -Xmx 는 여유분 확보용 임시 완화책일 뿐.
java -Xmx4g -jar dist/loglineage.jar "$@"
